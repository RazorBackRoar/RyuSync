"""Internal package entry point for RazorCore.

Allows execution via 'python -m razorcore'.
"""

from razorcore.cli.main import main


if __name__ == "__main__":
    # Redirect execution to the unified CLI main function
    main()
