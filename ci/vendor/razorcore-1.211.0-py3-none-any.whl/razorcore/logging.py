"""Unified logging setup for macOS applications.

Provides consistent logging configuration across all RazorBackRoar applications
with support for file logging, console output, and log rotation.
"""

from __future__ import annotations

import logging
import sys
from datetime import datetime
from logging.handlers import RotatingFileHandler
from pathlib import Path


class ColoredFormatter(logging.Formatter):
    """Formatter that adds colors to console output."""

    COLORS = {
        logging.DEBUG: "\033[36m",  # Cyan
        logging.INFO: "\033[32m",  # Green
        logging.WARNING: "\033[33m",  # Yellow
        logging.ERROR: "\033[31m",  # Red
        logging.CRITICAL: "\033[35m",  # Magenta
    }
    RESET = "\033[0m"

    def format(self, record: logging.LogRecord) -> str:
        color = self.COLORS.get(record.levelno, "")
        message = super().format(record)
        return f"{color}{message}{self.RESET}" if color else message


def get_log_directory(app_name: str, log_dir: Path | None = None) -> Path:
    """Get the appropriate log directory for the application.

    Uses macOS standard paths:
    - ~/Library/Application Support/{app_name}/logs/

    Args:
        app_name: Application name for the directory.
        log_dir: Optional explicit directory (tests / privacy overrides).

    Returns:
        Path to the log directory (created if needed).
    """
    if log_dir is not None:
        resolved = Path(log_dir)
        resolved.mkdir(parents=True, exist_ok=True)
        return resolved

    app_data: Path | None = None
    try:
        from PySide6.QtCore import QStandardPaths

        raw = QStandardPaths.writableLocation(
            QStandardPaths.StandardLocation.AppDataLocation
        )
        if raw and raw not in {".", ""}:
            app_data = Path(raw)
    except Exception:
        app_data = None

    if app_data is None:
        app_data = Path.home() / "Library" / "Application Support" / app_name

    resolved = app_data / "logs"
    resolved.mkdir(parents=True, exist_ok=True)
    return resolved


def setup_logging(
    app_name: str,
    level: int = logging.INFO,
    log_to_file: bool = True,
    log_to_console: bool = True,
    colored_console: bool = True,
    log_filename: str | None = None,
    max_log_files: int = 5,
    *,
    log_dir: Path | None = None,
    max_bytes: int | None = None,
    backup_count: int = 3,
    logger_name: str | None = None,
    configure_root: bool = False,
) -> logging.Logger:
    """Configure application logging with consistent formatting.

    Sets up logging with:
    - File handler (date retention cleanup, or size-based rotation when
      ``max_bytes`` is set)
    - Console handler (with optional colors)
    - Consistent timestamp format

    Args:
        app_name: Application name (log directory under Application Support).
        level: Logging level (default: INFO).
        log_to_file: Whether to log to a file.
        log_to_console: Whether to log to console.
        colored_console: Whether to use colored output in console.
        log_filename: Custom log filename (default: {app_name}.log).
        max_log_files: Maximum number of dated log files to keep (non-size mode).
        log_dir: Optional explicit log directory override.
        max_bytes: If set, use ``RotatingFileHandler`` with this size limit.
        backup_count: RotatingFileHandler backup count when ``max_bytes`` is set.
        logger_name: Logger name (default: ``app_name``).
        configure_root: Also attach the same handlers to the root logger
            (for apps that call ``logging.info`` directly).

    Returns:
        Configured logger instance.

    Example:
        from razorcore import setup_logging
        logger = setup_logging("4Charm", max_bytes=5 * 1024 * 1024)
        logger.info("Application started")
    """
    name = logger_name or app_name
    logger = logging.getLogger(name)
    logger.setLevel(level)
    logger.handlers.clear()
    logger.propagate = False

    file_format = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    console_format = "%(asctime)s - %(levelname)s - %(message)s"
    date_format = "%Y-%m-%d %H:%M:%S"
    handlers: list[logging.Handler] = []

    if log_to_file:
        resolved_dir = get_log_directory(app_name, log_dir=log_dir)
        filename = log_filename or f"{app_name.lower()}.log"
        log_path = resolved_dir / filename

        if max_bytes is not None and max_bytes > 0:
            file_handler: logging.Handler = RotatingFileHandler(
                log_path,
                maxBytes=max_bytes,
                backupCount=backup_count,
                encoding="utf-8",
            )
        else:
            _rotate_logs(resolved_dir, Path(filename).stem, max_log_files)
            file_handler = logging.FileHandler(log_path, encoding="utf-8")

        file_handler.setLevel(level)
        file_handler.setFormatter(logging.Formatter(file_format, date_format))
        handlers.append(file_handler)

    if log_to_console:
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(level)
        if colored_console and sys.stdout.isatty():
            console_handler.setFormatter(ColoredFormatter(console_format, date_format))
        else:
            console_handler.setFormatter(logging.Formatter(console_format, date_format))
        handlers.append(console_handler)

    for handler in handlers:
        logger.addHandler(handler)

    if configure_root:
        root = logging.getLogger()
        root.handlers.clear()
        root.setLevel(level)
        for handler in handlers:
            root.addHandler(handler)

    return logger


def get_logger(name: str) -> logging.Logger:
    """Get a child logger with the given name.

    This is a convenience function for modules to get a namespaced logger.

    Args:
        name: Logger name (usually __name__).

    Returns:
        Logger instance.

    Example:
        from razorcore import get_logger
        logger = get_logger(__name__)
    """
    return logging.getLogger(name)


def cleanup_logs(app_name: str, keep_days: int = 7, log_dir: Path | None = None) -> int:
    """Remove old log files to free up space.

    Args:
        app_name: Application name.
        keep_days: Number of days of logs to keep.
        log_dir: Optional explicit log directory override.

    Returns:
        Number of files removed.
    """
    resolved_dir = get_log_directory(app_name, log_dir=log_dir)
    removed = 0
    now = datetime.now()

    for log_file in resolved_dir.glob("*.log*"):
        try:
            mtime = datetime.fromtimestamp(log_file.stat().st_mtime)
            age_days = (now - mtime).days

            if age_days > keep_days:
                log_file.unlink()
                removed += 1
        except OSError:
            continue

    return removed


def _rotate_logs(log_dir: Path, prefix: str, max_files: int) -> None:
    """Rotate log files, keeping only the most recent ones."""
    log_files = sorted(
        log_dir.glob(f"{prefix}*.log*"),
        key=lambda p: p.stat().st_mtime if p.exists() else 0,
        reverse=True,
    )

    for old_file in log_files[max_files:]:
        try:
            old_file.unlink()
        except OSError:
            pass
