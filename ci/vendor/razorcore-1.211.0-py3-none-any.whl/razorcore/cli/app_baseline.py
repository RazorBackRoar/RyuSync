"""App baseline bootstrap and drift verification for Apps repositories."""

from __future__ import annotations

import re
from pathlib import Path

from razorcore.cli.app_kind import (
    AppKind,
    derive_module_name,
    derive_run_command,
    detect_app_kind,
    read_project_name,
    runtime_requirements_block,
)
from razorcore.cli.app_readme import (
    build_readme_context,
    readme_has_badge_style,
    readme_has_health_layer,
    render_readme,
)
from razorcore.cli.ci_vendor import verify_ci_vendor_wheels
from razorcore.cli.github_polish import apply_github_polish, disable_wiki
from razorcore.cli.registry import (
    CYAN,
    GREEN,
    NC,
    RED,
    resolve_project_name,
)


README_MARKER_START = "<!-- razorcore:runtime:start -->"
README_MARKER_END = "<!-- razorcore:runtime:end -->"


def _log_success(msg: str) -> None:
    print(f"{GREEN}✓{NC} {msg}")


def _log_error(msg: str) -> None:
    print(f"{RED}✗{NC} {msg}")


def _log_info(msg: str) -> None:
    print(f"{CYAN}→{NC} {msg}")


def _upsert_runtime_block(readme_path: Path, block: str) -> bool:
    current = readme_path.read_text(encoding="utf-8") if readme_path.exists() else ""

    if README_MARKER_START in current and README_MARKER_END in current:
        pattern = re.compile(
            rf"{re.escape(README_MARKER_START)}.*?{re.escape(README_MARKER_END)}\\n?",
            flags=re.DOTALL,
        )
        updated = pattern.sub(block, current, count=1)
    else:
        base = current.rstrip()
        if base:
            base += "\n\n"
        updated = base + block

    if updated == current:
        return False

    readme_path.write_text(updated, encoding="utf-8")
    return True


def _ensure_marker_file(proj_dir: Path) -> bool:
    marker = proj_dir / ".razorcore-enabled"
    if marker.exists():
        return False
    marker.write_text("", encoding="utf-8")
    return True


def _license_template_path() -> Path:
    return Path(__file__).resolve().parent.parent / "configs" / "github" / "LICENSE"


def _write_license(proj_dir: Path, force: bool) -> bool:
    license_path = proj_dir / "LICENSE"
    template_path = _license_template_path()
    if license_path.exists() and not force:
        return False
    if not template_path.exists():
        return False
    license_path.write_text(template_path.read_text(encoding="utf-8"), encoding="utf-8")
    return True


def _write_full_readme(
    proj_dir: Path,
    display_name: str,
    run_command: str,
    kind: AppKind,
    *,
    tagline: str | None = None,
    force: bool = False,
) -> bool:
    readme_path = proj_dir / "README.md"
    if readme_path.exists() and not force:
        return False

    ctx = build_readme_context(
        proj_dir,
        display_name,
        run_command=run_command,
        tagline=tagline,
        kind=kind,
    )
    runtime_block = runtime_requirements_block(kind, run_command)
    readme_path.write_text(
        render_readme(ctx, runtime_block=runtime_block),
        encoding="utf-8",
    )
    return True


def _project_bootstrap_context(
    workspace: Path,
    project: str,
    module_name: str | None,
) -> tuple[Path, str, AppKind, str]:
    resolved = resolve_project_name(project)
    proj_dir = workspace / resolved
    kind = detect_app_kind(proj_dir)
    pyproject_name = read_project_name(proj_dir)
    effective_module = module_name or derive_module_name(resolved, pyproject_name)
    run_command = derive_run_command(
        proj_dir,
        resolved,
        kind,
        module_name=effective_module,
    )
    return proj_dir, resolved, kind, run_command


def bootstrap_app_baseline(
    workspace: Path,
    project: str,
    module_name: str | None = None,
    *,
    dry_run: bool = False,
    force_readme: bool = False,
    skip_github: bool = False,
    tagline: str | None = None,
) -> int:
    """Bootstrap README badges, LICENSE, marker, and GitHub metadata for one app repo."""
    proj_dir, resolved, kind, run_command = _project_bootstrap_context(
        workspace, project, module_name
    )

    if not proj_dir.exists() or not proj_dir.is_dir():
        _log_error(f"Project not found: {project}")
        return 1

    _log_info(f"Bootstrapping polish for {resolved} ({kind.value})")

    if dry_run:
        marker = proj_dir / ".razorcore-enabled"
        if not marker.exists():
            _log_info(f"Would create marker: {marker}")

        readme_path = proj_dir / "README.md"
        if not readme_path.exists() or force_readme:
            _log_info(f"Would write RazorBackRoar README: {readme_path}")
        else:
            _log_info(f"Would keep existing README: {readme_path}")
        _log_info(f"Would set developer run command: {run_command}")
        _log_info(
            "CI workflow is not generated — copy from an existing app "
            "(4Charm/Nexus for Python, Libra/Swifter for Swift) or write your own."
        )
        if not skip_github:
            ctx = build_readme_context(
                proj_dir, resolved, run_command=run_command, tagline=tagline, kind=kind
            )
            ok, msg = apply_github_polish(
                resolved,
                ctx.description,
                proj_dir=proj_dir,
                dry_run=True,
            )
            _log_info(msg if ok else f"GitHub polish preview skipped: {msg}")
        return 0

    wrote_marker = _ensure_marker_file(proj_dir)
    if wrote_marker:
        _log_success("Created .razorcore-enabled marker")

    wrote_license = _write_license(proj_dir, force=force_readme)
    if wrote_license:
        _log_success("MIT LICENSE written")

    wrote_readme = _write_full_readme(
        proj_dir,
        resolved,
        run_command,
        kind,
        tagline=tagline,
        force=force_readme,
    )
    if wrote_readme:
        _log_success("RazorBackRoar README scaffold written")
    else:
        runtime_block = runtime_requirements_block(kind, run_command)
        readme_changed = _upsert_runtime_block(proj_dir / "README.md", runtime_block)
        if readme_changed:
            _log_success("Runtime README section updated")
        else:
            _log_info("Runtime README section already up to date")

    if not skip_github:
        ctx = build_readme_context(
            proj_dir, resolved, run_command=run_command, tagline=tagline, kind=kind
        )
        ok, msg = apply_github_polish(
            resolved,
            ctx.description,
            proj_dir=proj_dir,
        )
        if ok:
            _log_success(msg)
        else:
            _log_info(msg)
        wiki_ok, wiki_msg = disable_wiki(resolved)
        if wiki_ok:
            _log_success(wiki_msg)
        else:
            _log_info(wiki_msg)

    return 0


def polish_github_repo(
    workspace: Path,
    project: str,
    *,
    tagline: str | None = None,
    dry_run: bool = False,
) -> int:
    """Apply GitHub description, topics, homepage, and wiki settings to one app repo."""
    proj_dir, resolved, kind, run_command = _project_bootstrap_context(
        workspace, project, None
    )
    if not proj_dir.exists() or not proj_dir.is_dir():
        _log_error(f"Project not found: {project}")
        return 1

    ctx = build_readme_context(
        proj_dir,
        resolved,
        run_command=run_command,
        tagline=tagline,
        kind=kind,
    )

    ok, msg = apply_github_polish(
        resolved,
        ctx.description,
        proj_dir=proj_dir,
        dry_run=dry_run,
    )
    if ok:
        _log_success(msg)
    else:
        _log_error(msg)
        return 1

    wiki_ok, wiki_msg = disable_wiki(resolved, dry_run=dry_run)
    if wiki_ok:
        _log_success(wiki_msg)
    else:
        _log_info(wiki_msg)
    return 0


def _verify_repo_baseline(proj_dir: Path) -> list[str]:
    issues: list[str] = []

    marker = proj_dir / ".razorcore-enabled"
    if not marker.exists():
        issues.append("missing .razorcore-enabled marker")

    workflow_path = proj_dir / ".github" / "workflows" / "ci.yml"
    if not workflow_path.exists():
        issues.append("missing .github/workflows/ci.yml")

    readme_path = proj_dir / "README.md"
    if not readme_path.exists():
        issues.append("missing README.md")
    else:
        readme_text = readme_path.read_text(encoding="utf-8")
        if (
            README_MARKER_START not in readme_text
            or README_MARKER_END not in readme_text
        ):
            issues.append("README missing razorcore runtime requirements block")
        if "Download the macOS `.dmg` or `.app` release." not in readme_text:
            issues.append("README missing packaged-user runtime wording")
        if not readme_has_badge_style(readme_text):
            issues.append("README missing for-the-badge shield row")
        if not readme_has_health_layer(readme_text):
            issues.append("README missing Workspace Health Layer block")

    license_path = proj_dir / "LICENSE"
    if not license_path.exists():
        issues.append("missing LICENSE")

    return issues


def verify_app_baseline(workspace: Path, projects: list[str] | None = None) -> int:
    """Fail when app README/LICENSE/marker baseline drifts from policy."""
    if projects:
        targets = [workspace / resolve_project_name(name) for name in projects]
    else:
        targets = sorted(
            [
                path
                for path in workspace.iterdir()
                if path.is_dir() and (path / ".razorcore-enabled").exists()
            ],
            key=lambda path: path.name.lower(),
        )

    if not targets:
        _log_error("No app targets found for baseline verification")
        return 1

    errors = 0
    print(f"\n{'=' * 60}")
    print("  Razorcore App Baseline Check")
    print(f"{'=' * 60}\n")

    for proj_dir in targets:
        print(f"{CYAN}[{proj_dir.name}]{NC}")
        if not proj_dir.exists():
            _log_error("project directory not found")
            errors += 1
            continue

        issues = _verify_repo_baseline(proj_dir)
        if issues:
            errors += len(issues)
            for issue in issues:
                _log_error(issue)
        else:
            _log_success("baseline verified")

    vendor_issues = verify_ci_vendor_wheels(workspace)
    if vendor_issues:
        print(f"\n{CYAN}[ci/vendor]{NC}")
        for issue in vendor_issues:
            _log_error(issue)
            errors += 1

    print(f"\n{'=' * 60}")
    if errors == 0:
        print(f"  {GREEN}✓ App baseline verification passed{NC}")
    else:
        print(f"  {RED}✗ App baseline verification failed ({errors} issue(s)){NC}")
    print(f"{'=' * 60}\n")

    return 1 if errors > 0 else 0
