"""Lightweight stack hints for README/GitHub polish (not CI generation)."""

from __future__ import annotations

import json
import re
import tomllib
from enum import Enum
from pathlib import Path


class AppKind(Enum):
    PYTHON = "python"
    RUST = "rust"
    SWIFT = "swift"
    GENERIC = "generic"


def detect_app_kind(proj_dir: Path) -> AppKind:
    """Infer stack from a couple of obvious repo markers."""
    if (proj_dir / "Package.swift").exists() or (
        (proj_dir / "Sources").is_dir()
        and any((proj_dir / "Sources").glob("*/Resources/version.json"))
    ):
        return AppKind.SWIFT
    if any(proj_dir.glob("*.xcodeproj")):
        return AppKind.SWIFT
    if (proj_dir / "Cargo.toml").exists() or (proj_dir / "src-tauri").exists():
        return AppKind.RUST
    if (proj_dir / "pyproject.toml").exists():
        return AppKind.PYTHON
    return AppKind.GENERIC


def default_topics(kind: AppKind) -> tuple[str, ...]:
    shared = ("macos", "apple-silicon", "desktop-application")
    if kind is AppKind.RUST:
        return (*shared, "rust", "tauri")
    if kind is AppKind.PYTHON:
        return (*shared, "python", "pyside6", "gui-application")
    if kind is AppKind.SWIFT:
        return (*shared, "swift", "swiftui", "gui-application")
    return shared


def _read_pyproject_field(proj_dir: Path, *keys: str) -> str | None:
    pyproject_path = proj_dir / "pyproject.toml"
    if not pyproject_path.exists():
        return None
    try:
        with pyproject_path.open("rb") as pyproject_file:
            data = tomllib.load(pyproject_file)
    except OSError, tomllib.TOMLDecodeError:
        return None
    node: object = data
    for key in keys:
        if not isinstance(node, dict):
            return None
        node = node.get(key)
    return node if isinstance(node, str) and node.strip() else None


def _read_cargo_version(proj_dir: Path) -> str | None:
    cargo_path = proj_dir / "Cargo.toml"
    if not cargo_path.exists():
        return None
    text = cargo_path.read_text(encoding="utf-8")
    match = re.search(
        r"^\[workspace\.package\][\s\S]*?^version\s*=\s*\"([^\"]+)\"",
        text,
        flags=re.MULTILINE,
    )
    if match:
        return match.group(1)
    match = re.search(r'^version\s*=\s*"([^"]+)"', text, flags=re.MULTILINE)
    return match.group(1) if match else None


def _read_package_json_field(proj_dir: Path, key: str) -> str | None:
    package_json = proj_dir / "package.json"
    if not package_json.exists():
        return None
    try:
        data = json.loads(package_json.read_text(encoding="utf-8"))
    except OSError, json.JSONDecodeError:
        return None
    value = data.get(key)
    return value if isinstance(value, str) and value.strip() else None


def _read_xcode_marketing_version(proj_dir: Path) -> str | None:
    for pbx in sorted(proj_dir.glob("*.xcodeproj/project.pbxproj")):
        try:
            text = pbx.read_text(encoding="utf-8")
        except OSError:
            continue
        match = re.search(r"MARKETING_VERSION = ([0-9][0-9.]*)", text)
        if match:
            return match.group(1)
    return None


def _read_swift_version(proj_dir: Path) -> str | None:
    for path in sorted(proj_dir.glob("Sources/*/Resources/version.json")):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except OSError, json.JSONDecodeError:
            continue
        version = data.get("version")
        if isinstance(version, str) and version.strip():
            return version.strip()
    return _read_xcode_marketing_version(proj_dir)


def read_version_file(kind: AppKind, proj_dir: Path) -> tuple[str, str]:
    if kind is AppKind.RUST:
        return _read_cargo_version(proj_dir) or "0.1.0", "Cargo.toml"
    if kind is AppKind.PYTHON:
        return _read_pyproject_field(
            proj_dir, "project", "version"
        ) or "0.1.0", "pyproject.toml"
    if kind is AppKind.SWIFT:
        return (
            _read_swift_version(proj_dir) or "0.1.0",
            "Sources/*/Resources/version.json",
        )
    return _read_package_json_field(proj_dir, "version") or "0.1.0", "package.json"


def default_description(kind: AppKind, proj_dir: Path, tagline: str | None) -> str:
    if tagline:
        return tagline
    if kind is AppKind.PYTHON:
        return (
            _read_pyproject_field(proj_dir, "project", "description")
            or "Native macOS application built with Python and PySide6."
        )
    if kind is AppKind.RUST:
        return "Native macOS application built with Rust and Tauri."
    if kind is AppKind.SWIFT:
        return "Native macOS application built with Swift and SwiftUI."
    return "Native macOS desktop application for Apple Silicon."


def read_project_name(proj_dir: Path) -> str | None:
    return _read_pyproject_field(proj_dir, "project", "name")


def derive_module_name(project_name: str, pyproject_name: str | None) -> str:
    source = pyproject_name or project_name
    normalized = re.sub(r"[^A-Za-z0-9_]+", "_", source).strip("_").lower()
    if not normalized:
        normalized = "app"
    if normalized[0].isdigit():
        normalized = f"app_{normalized}"
    return normalized


def derive_run_command(
    proj_dir: Path,
    display_name: str,
    kind: AppKind,
    *,
    module_name: str | None = None,
) -> str:
    if kind is AppKind.RUST:
        return "cargo test --workspace"
    if kind is AppKind.SWIFT:
        return "swift build && swift run"
    if kind is AppKind.GENERIC:
        return "See README or project scripts for run instructions"
    pyproject_name = _read_pyproject_field(proj_dir, "project", "name")
    effective_module = module_name or derive_module_name(display_name, pyproject_name)
    module_dir = proj_dir / "src" / effective_module
    module_file = proj_dir / "src" / f"{effective_module}.py"
    if module_dir.exists() or module_file.exists():
        return f"uv run python -m {effective_module}"
    if (proj_dir / "src" / "main.py").exists():
        return "uv run python src/main.py"
    return f"uv run python -m {effective_module}"


def derive_build_command(display_name: str, kind: AppKind, proj_dir: Path) -> str:
    release_script = proj_dir / "scripts" / "release-build.zsh"
    if release_script.exists():
        return "scripts/release-build.zsh"
    if kind is AppKind.RUST:
        return "scripts/release-build.zsh"
    if kind is AppKind.SWIFT:
        return "scripts/build-mac.sh"
    if kind is AppKind.PYTHON:
        return f"razorbuild {display_name}"
    return "See project release scripts"


def runtime_requirements_block(kind: AppKind, run_command: str) -> str:
    marker_start = "<!-- razorcore:runtime:start -->"
    marker_end = "<!-- razorcore:runtime:end -->"
    user_line = "- Download the macOS `.dmg` or `.app` release."
    if kind is AppKind.PYTHON:
        dev_lines = [
            "- Primary development/build target: Python 3.14 with `uv`.",
            "- Source/build target: Python 3.14 only.",
            "- Setup: `uv sync`",
            f"- Run: `{run_command}`",
        ]
        user_line = (
            "- Download the macOS `.dmg` or `.app` release. "
            "Python does not need to be installed."
        )
    elif kind is AppKind.RUST:
        dev_lines = [
            "- Toolchain: Rust stable + Tauri 2 CLI.",
            "- Setup: `cargo fetch`",
            f"- Test: `{run_command}`",
            "- Release build: `scripts/release-build.zsh`",
        ]
        user_line += " Rust does not need to be installed."
    elif kind is AppKind.SWIFT:
        dev_lines = [
            "- Toolchain: Swift 5.9+ (Xcode or Swift toolchain) on Apple Silicon.",
            f"- Run: `{run_command}`",
            "- Package: `./scripts/build-mac.sh`",
        ]
        user_line += " Xcode/Swift do not need to be installed."
    else:
        dev_lines = [
            "- Toolchain: per the app's README and lockfiles.",
            f"- Run/build: `{run_command}`",
        ]
    return "\n".join(
        [
            marker_start,
            "## Runtime Requirements",
            "",
            "For users:",
            user_line,
            "",
            "For developers:",
            *dev_lines,
            marker_end,
            "",
        ]
    )
