"""Razorcore CLI Sync — config/doc syncing functions."""

from __future__ import annotations

import shutil
from pathlib import Path

from razorcore.cli.normalize_interpreters import (
    IDE_CANONICAL_PYTHON,
    IDE_CANONICAL_TY,
    normalize_project,
)
from razorcore.cli.profile_sync import sync_github_profile
from razorcore.cli.registry import (
    CYAN,
    GREEN,
    NC,
    RED,
    SANDBOX_ROOTS,
    get_projects,
    log_error,
    log_info,
    log_success,
    log_warning,
    workspace_root_from_apps,
)
from razorcore.cli.version import _collect_versions


def get_config_files(
    include_pyproject: bool = False,
    include_vscode_tasks: bool = False,
) -> dict[str, Path]:
    """Get paths to razorcore config files.

    Returns dict mapping destination path (relative to project) to source path.
    Destinations can include subdirectories like '.vscode/tasks.json'.
    """
    configs_dir = Path(__file__).parent.parent / "configs"
    config_files = {
        "pyrightconfig.json": configs_dir / "pyrightconfig.json",
        ".vscode/settings.json": configs_dir / "vscode" / "settings.json",
    }

    # VS Code tasks are centralized at workspace root (.vscode/tasks.json).
    # Keep per-project task syncing opt-in only.
    if include_vscode_tasks:
        config_files[".vscode/tasks.json"] = configs_dir / "vscode" / "tasks.json"

    # NOTE:
    # App pyproject.toml files contain app-specific metadata/version/dependencies.
    # Exclude by default to avoid clobbering versions during push workflows.
    if include_pyproject:
        config_files["pyproject.toml"] = configs_dir / "pyproject.toml"

    return config_files


def sync_configs(
    workspace: Path,
    projects: list[str] | None = None,
    dry_run: bool = False,
    include_pyproject: bool = False,
    include_vscode_tasks: bool = False,
) -> int:
    """Sync shared configuration files to projects."""
    print(f"\n{'=' * 60}")
    print("  Razorcore Config Sync")
    print(f"{'=' * 60}\n")

    config_files = get_config_files(
        include_pyproject=include_pyproject,
        include_vscode_tasks=include_vscode_tasks,
    )
    project_dirs = get_projects(workspace, projects)

    if not project_dirs:
        log_error("No projects found to sync")
        return 1

    errors = 0

    if include_pyproject:
        log_warning(
            "Including pyproject.toml in sync can overwrite app version metadata"
        )
    if include_vscode_tasks:
        log_warning("Including .vscode/tasks.json recreates per-project VS Code tasks")

    for proj_dir in project_dirs:
        proj_name = proj_dir.name
        print(f"\n{CYAN}[{proj_name}]{NC}")

        # Skip non-Python projects
        if not (proj_dir / "pyproject.toml").exists():
            log_info("Skipping (no pyproject.toml)")
            continue

        for dest_name, src_path in config_files.items():
            dest_path = proj_dir / dest_name

            # Remove symlink if exists
            if dest_path.is_symlink():
                if dry_run:
                    log_info(f"Would remove symlink: {dest_name}")
                else:
                    dest_path.unlink()
                    log_success(f"Removed symlink: {dest_name}")

            # Copy config file
            if src_path.exists():
                if dry_run:
                    log_info(f"Would copy: {dest_name}")
                else:
                    # Create parent directories if needed (e.g., .vscode/)
                    dest_path.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(src_path, dest_path)
                    log_success(f"Copied: {dest_name}")
            else:
                log_error(f"Source not found: {src_path}")
                errors += 1

        # After syncing static config, normalize any per-project interpreter refs
        # in newly created or existing Python files and .vscode settings.
        try:
            changed = normalize_project(proj_dir, dry_run=dry_run)
            if changed["shebangs"] or changed["editor_configs"]:
                for kind, paths in changed.items():
                    for p in paths:
                        log_success(f"Normalized {kind}: {p}")
        except Exception as exc:
            log_error(f"Interpreter normalization failed for {proj_name}: {exc}")
            errors += 1

    print(f"\n{'=' * 60}")
    if dry_run:
        print("  Dry run complete - no changes made")
    elif errors == 0:
        print(f"  {GREEN}✓ All configs synced successfully{NC}")
    else:
        print(f"  {RED}✗ Completed with {errors} errors{NC}")
    print(f"{'=' * 60}\n")

    return 1 if errors > 0 else 0


def sync_all(workspace: Path) -> int:
    """Sync toolchain configs to all locations: App projects + sandbox roots.

    App projects (managed by razorcore):
        4Charm, Nexus, RyuSync, .razorcore

    Sandbox roots (local-only git, under IDE/):
        IDE/Codex, IDE/Devin, IDE/Antigravity, IDE/OpenCode, IDE/Cursor
    """
    print(f"\n{'=' * 60}")
    print("  Razorcore Sync All")
    print(f"{'=' * 60}\n")

    errors = 0

    # ── App projects (existing sync-configs behaviour) ─────────────────────
    errors += sync_configs(workspace)

    # ── Sandbox workspace roots ─────────────────────────────────────────────
    configs_dir = Path(__file__).parent.parent / "configs" / "vscode"
    pyright_src = Path(__file__).parent.parent / "configs" / "pyrightconfig-ide.json"
    workspace_parent = workspace.parent  # e.g. /Users/home/Workspace/

    # Per-IDE .vscode sources; any unmatched root falls back to the shared app
    # settings.json (ty + ruff, no IDE-specific language server).
    ide_settings_sources = {
        "IDE/Cursor": configs_dir / "settings-ide-cursor.json",
        "IDE/Devin": configs_dir / "settings-ide-devin.json",
        "IDE/Antigravity": configs_dir / "settings-ide-antigravity.json",
    }

    print(f"\n{'─' * 60}")
    print("  Sandbox Roots")
    print(f"{'─' * 60}")

    for root_name in SANDBOX_ROOTS:
        root_dir = workspace_parent / root_name
        if not root_dir.exists():
            print(f"\n{CYAN}[{root_name}]{NC}")
            log_info("Directory not found — skipping")
            continue

        print(f"\n{CYAN}[{root_name}]{NC}")

        settings_src = ide_settings_sources.get(
            root_name, configs_dir / "settings.json"
        )

        for dest_name, src in (
            (".vscode/settings.json", settings_src),
            ("pyrightconfig.json", pyright_src),
        ):
            dest = root_dir / dest_name
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dest)
            log_success(f"Copied: {dest_name}")

        # Normalize any interpreter drift in sandbox root source files.
        try:
            changed = normalize_project(
                root_dir,
                dry_run=False,
                canonical_python=IDE_CANONICAL_PYTHON,
                canonical_ty=IDE_CANONICAL_TY,
            )
            if changed["shebangs"] or changed["editor_configs"]:
                for kind, paths in changed.items():
                    for p in paths:
                        log_success(f"Normalized {kind}: {p}")
        except Exception as exc:
            log_error(f"Interpreter normalization failed for {root_name}: {exc}")
            errors += 1

    print(f"\n{'=' * 60}")
    if errors == 0:
        print(f"  {GREEN}✓ Sync complete{NC}")
    else:
        print(f"  {RED}✗ Completed with {errors} errors{NC}")
    print(f"{'=' * 60}\n")

    return errors


def _resolve_master_context_prompt(workspace: Path) -> Path | None:
    candidates = [
        workspace / "CONTEXT.md",
        workspace / "Apps" / "CONTEXT.md",
        workspace.parent / "Apps" / "CONTEXT.md",
        workspace.parent,
    ]
    for candidate in candidates:
        if candidate.is_dir():
            guide = candidate / "CONTEXT.md"
        else:
            guide = candidate
        if guide.exists():
            return guide
    return None


# Canonical agent / IDE rule files stored in Workspace/.razorcore/docs/agents.
# They are one-way synced to the workspace root where Cursor, Devin, Warp, etc. read them.
_AGENT_RULE_FILES = [
    "AGENTS.md",
    "Apps/AGENTS.md",
    "Apps/Docs/WARP.md",
    "Apps/Docs/razorcore-api-spec.md",
    "Apps/.cursor/rules/razorbackroar-codebase.mdc",
]


def sync_agent_rules(workspace: Path, dry_run: bool = False) -> int:
    """Sync canonical AGENTS, docs, and IDE rule files to workspace root."""
    print(f"\n{'=' * 60}")
    print("  Razorcore Sync Agent Rules")
    print(f"{'=' * 60}\n")

    root = workspace_root_from_apps(workspace)
    source_base = root / ".razorcore" / "docs" / "agents"
    if not source_base.exists():
        log_warning(f"Agent rules source not found: {source_base}")
        return 0

    errors = 0
    copied = 0
    for rel_path in _AGENT_RULE_FILES:
        src = source_base / rel_path
        dst = root / rel_path

        if not src.exists():
            log_warning(f"Source not found: {rel_path}")
            errors += 1
            continue

        if dst.exists():
            try:
                if src.read_bytes() == dst.read_bytes():
                    continue
            except OSError as exc:
                log_warning(f"Could not compare {rel_path}: {exc}")
                errors += 1
                continue

        if dry_run:
            log_info(f"Would copy: {rel_path}")
            copied += 1
            continue

        dst.parent.mkdir(parents=True, exist_ok=True)
        try:
            shutil.copy2(src, dst)
            log_success(f"Copied: {rel_path}")
            copied += 1
        except OSError as exc:
            log_error(f"Failed to copy {rel_path}: {exc}")
            errors += 1

    print(f"\n{'=' * 60}")
    if dry_run:
        if copied:
            log_info(f"Dry run - would copy {copied} agent rule file(s)")
        else:
            log_info("Agent rules already up to date")
    elif errors:
        print(f"  {RED}✗ Completed with {errors} errors{NC}")
    else:
        if copied:
            print(f"  {GREEN}✓ Copied {copied} agent rule file(s){NC}")
        else:
            print(f"  {GREEN}✓ Agent rules already up to date{NC}")
    print(f"{'=' * 60}\n")

    return 1 if errors > 0 else 0


def sync_project_agent_versions(workspace: Path, dry_run: bool = False) -> int:
    """Sync per-project AGENTS.md version headers from pyproject.toml."""
    import re

    versions = _collect_versions(workspace)
    if not versions:
        log_error("No versions found to sync project AGENTS.md files")
        return 1

    project_agent_files = {
        "4Charm": workspace / "4Charm" / "AGENTS.md",
        "Nexus": workspace / "Nexus" / "AGENTS.md",
        "RyuSync": workspace / "RyuSync" / "AGENTS.md",
        ".razorcore": workspace / ".razorcore" / "AGENTS.md",
    }

    updates_made = 0
    header_pattern = r"(\*\*Version:\*\*\s*)[\d.]+"

    for project, agent_path in project_agent_files.items():
        version = versions.get(project)
        if not version:
            log_warning(f"Version not found for {project}")
            continue
        if not agent_path.exists():
            log_warning(f"{project} AGENTS.md not found: {agent_path}")
            continue

        content = agent_path.read_text(encoding="utf-8")
        updated, count = re.subn(
            header_pattern,
            rf"\g<1>{version}",
            content,
            count=1,
        )
        if count == 0:
            log_warning(f"No '**Version:**' header found in {agent_path}")
            continue
        if updated == content:
            continue

        if dry_run:
            log_info(f"Would update {project} AGENTS.md to v{version}")
        else:
            agent_path.write_text(updated, encoding="utf-8")
            log_success(f"Updated {project} AGENTS.md to v{version}")
        updates_made += 1

    if updates_made == 0:
        log_info("Project AGENTS.md versions already match")
        return 0

    if dry_run:
        log_info(f"Dry run - would update {updates_made} project AGENTS.md files")
        return 0

    log_success(f"Updated {updates_made} project AGENTS.md file(s)")
    return 0


def sync_ssot_versions(workspace: Path, dry_run: bool = False) -> int:
    """Sync the Versions (SSOT) section in CONTEXT.md from pyproject.toml."""
    import re

    print(f"\n{'=' * 60}")
    print("  Razorcore Sync SSOT Versions")
    print(f"{'=' * 60}\n")

    guide_path = _resolve_master_context_prompt(workspace)
    if not guide_path:
        log_warning("CONTEXT.md not found")
        return 0

    versions = _collect_versions(workspace)
    if not versions:
        log_error("No versions found to sync")
        return 1

    ordered_projects = [
        "4Charm",
        "Nexus",
        "RyuSync",
        "Swifter",
        "SwiftTemp",
        "Libra",
        "Looper",
        "MetaBurn",
        ".razorcore",
    ]
    missing = [name for name in ordered_projects if name not in versions]
    if missing:
        log_warning(f"Missing versions for: {', '.join(missing)}")

    new_body = "".join(
        f"- {name}: {versions[name]}\n" for name in ordered_projects if name in versions
    )

    content = guide_path.read_text(encoding="utf-8")
    pattern = r"(## (?:[\d.]+\s*)?Versions \(SSOT\)(?:\s+{#.*?})?\n)(.*?)(?=\n## )"
    match = re.search(pattern, content, flags=re.DOTALL)
    if not match:
        log_error("Versions (SSOT) section not found in CONTEXT.md")
        return 1

    updated = re.sub(pattern, r"\1" + new_body, content, flags=re.DOTALL)
    if updated == content:
        log_info("SSOT versions already match")
        return 0

    if dry_run:
        log_info("Dry run - SSOT versions would be updated")
        return 0

    guide_path.write_text(updated, encoding="utf-8")
    log_success("Updated Versions (SSOT) section")
    return 0


def _sync_version_docs(workspace: Path) -> None:
    """Sync project AGENTS headers, local SSOT versions, and the GitHub profile."""
    sync_project_agent_versions(workspace)
    sync_ssot_versions(workspace)
    sync_github_profile(workspace)


def sync_docs(workspace: Path, dry_run: bool = False) -> int:
    """Sync AGENTS.md Quick Reference table with current versions from pyproject.toml."""
    import re

    print(f"\n{'=' * 60}")
    print("  Razorcore Sync Docs")
    print(f"{'=' * 60}\n")

    agents_md = workspace / "AGENTS.md"
    if not agents_md.exists():
        log_error("AGENTS.md not found in workspace")
        return 1

    # Collect current versions from pyproject.toml files
    versions = _collect_versions(workspace)

    if not versions:
        log_error("No versions found to sync")
        return 1

    # Read AGENTS.md
    content = agents_md.read_text(encoding="utf-8")
    original_content = content

    # Update version numbers in the Quick Reference table
    # Pattern matches table rows like: | 4Charm | `four_charm` | 6.1.7 | ... |
    updates_made = 0

    # Map project names to their patterns
    project_patterns = {
        "4Charm": (r"(\| 4Charm \| `four_charm` \| )[\d.]+( \|)", "4Charm"),
        "Nexus": (r"(\| Nexus \| `nexus` \| )[\d.]+( \|)", "Nexus"),
        "RyuSync": (r"(\| RyuSync \| `ryusync` \| )[\d.]+( \|)", "RyuSync"),
        ".razorcore": (
            r"(\| \*\*\.razorcore\*\* \| `razorcore` \| )[\d.]+( \|)",
            ".razorcore",
        ),
    }

    for name, version in versions.items():
        if name in project_patterns:
            pattern, _ = project_patterns[name]
            replacement = f"\\g<1>{version}\\g<2>"

            new_content, count = re.subn(pattern, replacement, content)
            if count > 0:
                content = new_content
                updates_made += count
                log_success(f"Updated {name} to v{version}")

    if updates_made == 0:
        log_info("No updates needed - versions already match")
        return 0

    if dry_run:
        print(f"\n{'=' * 60}")
        log_info(f"Dry run - would update {updates_made} version(s)")
        print(f"{'=' * 60}\n")
        return 0

    # Write updated content
    if content != original_content:
        agents_md.write_text(content, encoding="utf-8")
        log_success(f"Updated AGENTS.md with {updates_made} version(s)")

    print(f"\n{'=' * 60}")
    print(f"  {GREEN}✓ Sync complete{NC}")
    print(f"{'=' * 60}\n")

    return 0
