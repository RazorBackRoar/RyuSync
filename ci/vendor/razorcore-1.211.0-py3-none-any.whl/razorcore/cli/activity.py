"""Append-only activity logging for workspace operations."""

from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any


def _to_jsonable(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dict):
        return {str(k): _to_jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_to_jsonable(item) for item in value]
    return value


def append_activity_event(
    workspace: Path,
    *,
    event: str,
    app: str | None = None,
    details: dict[str, Any] | None = None,
) -> Path:
    """Append a single JSON line event into .razorcore/activity.jsonl."""
    log_path = workspace / ".razorcore" / "activity.jsonl"
    log_path.parent.mkdir(parents=True, exist_ok=True)

    payload: dict[str, Any] = {
        "timestamp_utc": datetime.now(UTC).isoformat(),
        "event": event,
    }
    if app is not None:
        payload["app"] = app
    if details:
        payload["details"] = _to_jsonable(details)

    with log_path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(payload, ensure_ascii=True, separators=(",", ":")) + "\n")

    return log_path
