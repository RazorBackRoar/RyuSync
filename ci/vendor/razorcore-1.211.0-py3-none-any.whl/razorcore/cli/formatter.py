"""Markdown formatter module for Razorcore.

Consolidates logic from previous maintenance scripts to fix common Markdown issues.
"""

from __future__ import annotations

import re
from pathlib import Path


# ANSI colors
GREEN = "\033[0;32m"
YELLOW = "\033[1;33m"
RED = "\033[0;31m"
CYAN = "\033[0;36m"
NC = "\033[0m"  # No Color


def log_success(msg: str) -> None:
    print(f"{GREEN}✓{NC} {msg}")


def log_warning(msg: str) -> None:
    print(f"{YELLOW}⚠{NC} {msg}")


def log_error(msg: str) -> None:
    print(f"{RED}✗{NC} {msg}")


def log_info(msg: str) -> None:
    print(f"{CYAN}→{NC} {msg}")


EXCLUDE_DIRS = {
    ".git",
    ".archive",
    ".logs",
    ".pytest_cache",
    "node_modules",
    "build",
    "dist",
    "__pycache__",
    ".venv",
    ".gemini",
}


# Compiled Regexes
INDENTED_CODE_RE = re.compile(r"^(\s{4,})(.+)$")
BARE_URL_RE = re.compile(r"(?<![\[\(])https?://[^\s\)]+(?![\]\)])")
HEADING_RE = re.compile(r"^(#{1,6})\s+\S")
LIST_RE = re.compile(r"^(\s*)([-*]|\d+\.)\s+(.*)")
TABLE_RE = re.compile(r"^\s*\|.*\|\s*$")
TABLE_SEP_RE = re.compile(r"^\s*\|?\s*[-: ]+\|[-|: ]*\s*$")
FENCE_RE = re.compile(r"^\s*```")
BOLD_HEADING_RE = re.compile(r"^\*\*([^*].*?)\*\*$")


def _collect_markdown_files(
    workspace: Path, file_path: Path | None = None
) -> list[Path]:
    """Collect markdown files to process."""
    files_to_process: list[Path] = []

    if file_path:
        path = Path(file_path).resolve()
        if not path.exists():
            log_error(f"File not found: {path}")
            return []
        if path.is_file() and path.suffix.lower() == ".md":
            files_to_process.append(path)
        elif path.is_dir():
            for p in path.rglob("*.md"):
                if not any(part in EXCLUDE_DIRS for part in p.parts):
                    files_to_process.append(p)
    else:
        for path in workspace.rglob("*.md"):
            if any(part in EXCLUDE_DIRS for part in path.parts):
                continue
            files_to_process.append(path)

    return files_to_process


def _process_files(files_to_process: list[Path], dry_run: bool) -> int:
    """Process markdown files and return count of changed files."""
    files_changed = 0
    for md_file in files_to_process:
        try:
            changed = _process_file(md_file, dry_run)
            if changed:
                files_changed += 1
        except Exception as e:
            log_error(f"Error processing {md_file.name}: {e}")
    return files_changed


def format_markdown_files(
    workspace: Path, file_path: Path | None = None, dry_run: bool = False
) -> int:
    """Format markdown files in the workspace.

    Args:
        workspace: Path to the workspace root.
        file_path: Optional path to a specific file to format. If None, scans workspace.
        dry_run: If True, only show what would be formatted without making changes.

    Returns:
        0 on success (even if changes were made), 1 on error.
    """
    print(f"\n{'=' * 60}")
    print("  Razorcore Markdown Formatter")
    print(f"{'=' * 60}\n")

    files_to_process = _collect_markdown_files(workspace, file_path)

    if not files_to_process:
        log_info("No markdown files found to process.")
        return 0

    files_changed = _process_files(files_to_process, dry_run)

    print(f"\n{'=' * 60}")
    if files_changed == 0:
        print(f"  {GREEN}✓ No formatting needed{NC}")
    else:
        action = "would be modified" if dry_run else "modified"
        print(f"  {GREEN}✓ Formatted: {files_changed} files {action}{NC}")
    print(f"{'=' * 60}\n")

    return 0


def _process_file(path: Path, dry_run: bool) -> bool:
    """Process a single markdown file. Returns True if changes were made/detected."""
    try:
        content = path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        log_warning(f"Skipping binary or non-utf8 file: {path.name}")
        return False

    lines = content.splitlines(keepends=True)

    # Chain the formatting operations
    # 1. Basic Line Fixes (headings, spacing)
    lines = _fix_general_lines(lines)

    # 2. Indented Code Blocks -> Fenced
    lines = _fix_indented_code_blocks(lines)

    # 3. Fence Normalization (add language, ensure closure)
    lines = _normalize_code_fences(lines)

    # 4. Table Normalization
    lines = _normalize_tables(lines)

    # 5. Bare URLs (run last as it processes text content)
    lines = _fix_bare_urls(lines)

    updated = "".join(lines)

    # Ensure single newline at EOF
    updated = updated.rstrip() + "\n"

    if updated != content:
        if dry_run:
            print(
                f"  {CYAN}[DRY RUN] Would format: {path.relative_to(path.parents[len(path.parts) - 2])}{NC}"
            )
        else:
            path.write_text(updated, encoding="utf-8")
            log_success(f"Formatted: {path.name}")
        return True

    return False


def _fix_general_lines(lines: list[str]) -> list[str]:
    """Fix common line-based issues: disable comments, bold headings, spacing."""
    out: list[str] = []
    i = 0
    in_fence = False

    while i < len(lines):
        line = lines[i]
        stripped = line.rstrip("\n")

        # Track if we are inside a code fence to avoid formatting code content
        if FENCE_RE.match(stripped):
            in_fence = not in_fence
            out.append(line)
            i += 1
            continue

        if in_fence:
            out.append(line)
            i += 1
            continue

        # Skip markdownlint-disable comments
        if "markdownlint-disable" in line:
            i += 1
            continue

        # Fix MD050: __strong__ -> **strong**
        if "__" in stripped:
            line = line.replace("__", "**")
            stripped = stripped.replace("__", "**")

        # Fix Bold Headings: **Heading** -> ### Heading
        # Only does this for lines that look like a heading (entire line is bold)
        bold_match = BOLD_HEADING_RE.match(stripped)
        if bold_match:
            # Avoid converting items that might be lists or quotes
            if not (
                stripped.startswith("-")
                or stripped.startswith("*")
                or stripped.startswith(">")
            ):
                text = bold_match.group(1).strip()
                out.append(f"### {text}\n")
                i += 1
                continue

        # Fix MD025: H1 -> H2 (if not the first H1)
        # We'll skip complex H1 logic for now to avoid breaking intentional H1s in sub-files,
        # but commonly H1s should be H2s if there's already a title.
        # Keeping it safe: Do nothing for H1s for now.

        out.append(line)
        i += 1

    return out


def _fix_indented_code_blocks(lines: list[str]) -> list[str]:
    """Convert indented code blocks to fenced code blocks."""
    out: list[str] = []
    in_fence = False
    i = 0

    while i < len(lines):
        line = lines[i]
        stripped = line.rstrip("\n")

        # Track existing fenced code block state — never touch content
        # inside fences.
        if FENCE_RE.match(stripped):
            in_fence = not in_fence
            out.append(line)
            i += 1
            continue

        if in_fence:
            out.append(line)
            i += 1
            continue

        # Check for indented code block (4 spaces)
        if INDENTED_CODE_RE.match(stripped):
            # Start of indented code block
            # Ensure blank line before
            if out and out[-1].strip():
                out.append("\n")
            out.append("```text\n")

            # Consume all consecutive indented lines
            while i < len(lines) and INDENTED_CODE_RE.match(lines[i].rstrip("\n")):
                content = lines[i].rstrip("\n")
                # Remove indentation
                content = INDENTED_CODE_RE.sub(r"\2", content)
                out.append(content + "\n")
                i += 1

            out.append("```\n")
            # Ensure blank line after
            if i < len(lines) and lines[i].strip():
                out.append("\n")
            continue

        out.append(line)
        i += 1

    return out


def _normalize_code_fences(lines: list[str]) -> list[str]:
    """Ensure code fences have languages and are properly spaced."""
    out: list[str] = []
    in_fence = False

    for line in lines:
        stripped = line.rstrip("\n")

        if stripped.strip().startswith("```"):
            fence = stripped.strip()

            if not in_fence:
                # Opening fence
                if fence == "```":
                    fence = "```text"  # Default to text

                # Ensure blank line before fence if needed
                if out and out[-1].strip() and not out[-1].strip().startswith("```"):
                    out.append("\n")

                out.append(fence + "\n")
                in_fence = True
            else:
                # Closing fence
                out.append("```\n")
                in_fence = False
        else:
            out.append(line)

    return out


def _normalize_tables(lines: list[str]) -> list[str]:
    """Normalize table formatting (pipes and spacing)."""
    out: list[str] = []
    i = 0

    while i < len(lines):
        line = lines[i]

        # Detect start of table: Line has | AND next line is separator line like |---|
        if (
            "|" in line
            and i + 1 < len(lines)
            and re.match(r"^\s*\|?\s*[-:| ]+\s*$", lines[i + 1])
        ):
            table_lines = [line, lines[i + 1]]
            i += 2

            # Collect rest of table
            while i < len(lines) and "|" in lines[i] and lines[i].strip():
                table_lines.append(lines[i])
                i += 1

            # Normalize collected table
            normalized = []
            for tline in table_lines:
                # Split by pipe, stripping whitespace from cells
                cells = [c.strip() for c in tline.strip().strip("|").split("|")]

                # Check if it's the separator row
                if re.match(r"^[-: ]+$", "".join(cells)):
                    cells = ["---" for _ in cells]

                # Reconstruct with nice spacing
                normalized.append("| " + " | ".join(cells) + " |\n")

            out.extend(normalized)

            # Ensure blank line after table
            if i < len(lines) and lines[i].strip():
                out.append("\n")
        else:
            out.append(line)
            i += 1

    return out


def _fix_bare_urls(lines: list[str]) -> list[str]:
    """Wrap bare URLs in angle brackets: https://example.com -> <https://example.com>.

    Tracks fenced code block state so URLs inside code blocks are never
    touched.  Previous versions only checked for ``` on the same line,
    which missed multi-line code blocks entirely.
    """
    out: list[str] = []
    in_fence = False

    for line in lines:
        stripped = line.rstrip("\n").strip()

        # Track fenced code block state
        if FENCE_RE.match(stripped):
            in_fence = not in_fence
            out.append(line)
            continue

        # Never modify content inside fenced blocks or markdown links
        if in_fence or ("[" in line and "](" in line):
            out.append(line)
            continue

        # Wrap bare urls outside fences
        fixed = BARE_URL_RE.sub(r"<\g<0>>", line)
        out.append(fixed)

    return out
