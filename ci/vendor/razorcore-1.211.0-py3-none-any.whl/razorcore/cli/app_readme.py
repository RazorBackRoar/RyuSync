"""RazorBackRoar-standard README generation for new app repositories."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from razorcore.cli.app_kind import (
    AppKind,
    default_description,
    derive_build_command,
    detect_app_kind,
    read_version_file,
)


GITHUB_ORG = "RazorBackRoar"
BADGE_GREEN = "2ea44f"
BADGE_ORANGE = "e8710a"
BADGE_RED = "d32f2f"
BADGE_YELLOW = "f5c518"
BADGE_BLUE = "3178C6"


@dataclass(frozen=True)
class AppReadmeContext:
    display_name: str
    version: str
    description: str
    run_command: str
    build_command: str
    version_file: str
    kind: AppKind


def build_readme_context(
    proj_dir: Path,
    display_name: str,
    *,
    run_command: str,
    tagline: str | None = None,
    kind: AppKind | None = None,
) -> AppReadmeContext:
    resolved_kind = kind or detect_app_kind(proj_dir)
    version, version_file = read_version_file(resolved_kind, proj_dir)
    return AppReadmeContext(
        display_name=display_name,
        version=version,
        description=default_description(resolved_kind, proj_dir, tagline),
        run_command=run_command,
        build_command=derive_build_command(display_name, resolved_kind, proj_dir),
        version_file=version_file,
        kind=resolved_kind,
    )


def _health_layer(kind: AppKind) -> str:
    lines = [
        "<!-- Workspace Health Layer -->",
        f"![Status](https://img.shields.io/badge/status-active-{BADGE_GREEN}?style=for-the-badge)",
        f"![Tests](https://img.shields.io/badge/tests-present-{BADGE_GREEN}?style=for-the-badge)",
    ]
    if kind is AppKind.PYTHON:
        lines.append(
            f"![Lint](https://img.shields.io/badge/lint-ruff-{BADGE_GREEN}?style=for-the-badge)"
        )
    elif kind is AppKind.SWIFT:
        lines.append(
            "![Build](https://img.shields.io/badge/build-swift-F05138?style=for-the-badge)"
        )
    lines.append("")
    return "\n".join(lines)


def _badge_header(ctx: AppReadmeContext) -> str:
    repo = ctx.display_name
    org = GITHUB_ORG
    common = [
        f"[![CI](https://img.shields.io/github/actions/workflow/status/{org}/{repo}/ci.yml?branch=main&style=for-the-badge&label=CI)](https://github.com/{org}/{repo}/actions/workflows/ci.yml)",
        f"[![Version](https://img.shields.io/badge/version-{ctx.version}-blue?style=for-the-badge)]({ctx.version_file})",
        "[![License: MIT](https://img.shields.io/badge/license-MIT-blueviolet?style=for-the-badge)](LICENSE)",
    ]
    if ctx.kind is AppKind.RUST:
        stack = [
            f"[![Rust](https://img.shields.io/badge/rust-2021-{BADGE_ORANGE}?style=for-the-badge&logo=rust&logoColor=white)](https://www.rust-lang.org/)",
            f"[![Tauri](https://img.shields.io/badge/Tauri-2-{BADGE_YELLOW}?style=for-the-badge&logo=tauri&logoColor=white&labelColor={BADGE_YELLOW})](https://tauri.app/)",
        ]
    elif ctx.kind is AppKind.SWIFT:
        stack = [
            "[![Swift](https://img.shields.io/badge/Swift-F05138?style=for-the-badge&logo=swift&logoColor=white)](https://swift.org/)",
            "[![SwiftUI](https://img.shields.io/badge/SwiftUI-000000?style=for-the-badge&logo=swift&logoColor=white)](https://developer.apple.com/xcode/swiftui/)",
        ]
    elif ctx.kind is AppKind.GENERIC:
        stack = []
    else:
        stack = [
            f"[![Python](https://img.shields.io/badge/python-3.14-{BADGE_GREEN}?style=for-the-badge&logo=python&logoColor=white)](https://www.python.org/)",
            "[![PySide6](https://img.shields.io/badge/PySide6-Qt6-41cd52?style=for-the-badge&logo=qt&logoColor=white)](https://doc.qt.io/qtforpython/)",
        ]
    stack.append(
        f"[![macOS](https://img.shields.io/badge/mac%20os-Apple%20Silicon-{BADGE_RED}?style=for-the-badge&logo=apple&logoColor=white)](https://support.apple.com/en-us/HT211814)"
    )
    return "\n".join([*common, *stack, ""])


def _dev_setup(ctx: AppReadmeContext) -> str:
    org = GITHUB_ORG
    name = ctx.display_name
    if ctx.kind is AppKind.RUST:
        commands = [
            f"git clone https://github.com/{org}/{name}.git",
            f"cd {name}",
            "cargo test --workspace",
        ]
    elif ctx.kind is AppKind.SWIFT:
        commands = [
            f"git clone https://github.com/{org}/{name}.git",
            f"cd {name}",
            "swift build",
            "swift run",
        ]
    elif ctx.kind is AppKind.GENERIC:
        commands = [
            f"git clone https://github.com/{org}/{name}.git",
            f"cd {name}",
            "# Follow stack-specific setup in this README",
            ctx.run_command,
        ]
    else:
        commands = [
            f"git clone https://github.com/{org}/{name}.git",
            f"cd {name}",
            "uv sync",
            ctx.run_command,
        ]
    return "```bash\n" + "\n".join(commands) + "\n```"


def render_readme(
    ctx: AppReadmeContext,
    *,
    runtime_block: str,
) -> str:
    org = GITHUB_ORG
    name = ctx.display_name
    return "\n".join(
        [
            f"# {name}",
            "",
            _badge_header(ctx),
            _health_layer(ctx.kind),
            f"> **TL;DR:** {ctx.description}",
            "",
            "---",
            "",
            "## Features",
            "",
            "- _Describe your app's headline features here._",
            "- **Apple Silicon native** — arm64 build optimized for M-series Macs",
            "",
            "---",
            "",
            "## Installation",
            "",
            f"1. Download the latest `{name}.dmg` from [Releases](https://github.com/{org}/{name}/releases)",
            f"2. Open the DMG and drag `{name}.app` to `/Applications`",
            "3. First launch — right-click the app → **Open** to bypass Gatekeeper on the ad-hoc signed build",
            "",
            "---",
            "",
            "## Development",
            "",
            _dev_setup(ctx),
            "",
            "### Build",
            "",
            "```bash",
            ctx.build_command,
            f"# Output: dist/{name}.dmg",
            "```",
            "",
            "---",
            "",
            "## License",
            "",
            "MIT License — see [LICENSE](LICENSE) for details.",
            "Copyright © 2026 RazorBackRoar",
            "",
            runtime_block.rstrip(),
            "",
        ]
    )


def readme_has_badge_style(readme_text: str) -> bool:
    return "style=for-the-badge" in readme_text


def readme_has_health_layer(readme_text: str) -> bool:
    return "<!-- Workspace Health Layer -->" in readme_text
