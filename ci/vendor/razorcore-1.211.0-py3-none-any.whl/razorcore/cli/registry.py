"""Razorcore CLI Registry — constants, logging helpers, and project discovery."""

from __future__ import annotations

import subprocess
from pathlib import Path


# Locked Python version for this workspace.
# Update here only when intentionally changing the workspace baseline.
PYTHON_VERSION = "3.14"
PYTHON_VERSION_TUPLE = (3, 14)

# ANSI colors
GREEN = "\033[0;32m"
YELLOW = "\033[1;33m"
RED = "\033[0;31m"
CYAN = "\033[0;36m"
NC = "\033[0m"  # No Color

# Managed app repositories (Apps/* only; excludes .razorcore tooling layer)
# Legacy Python save/pushapps/razorpushapp scope. Product-wide loops use
# PUBLIC_APP_PROJECTS instead.
MANAGED_APP_PROJECTS = [
    "4Charm",
    "Nexus",
    "RyuSync",
]

# Public product apps (GitHub Releases storefront). Not razorcore tooling.
PUBLIC_APP_PROJECTS = [
    "4Charm",
    "Nexus",
    "RyuSync",
    "Swifter",
    "SwiftTemp",
    "Libra",
    "Looper",
    "MetaBurn",
]

# Managed projects used by legacy commands.
# Keep .razorcore here for backwards compatibility in old workflows.
MANAGED_PROJECTS = [
    *MANAGED_APP_PROJECTS,
    ".razorcore",
]

# Projects that can be built into apps (excludes documentation and library projects)
BUILDABLE_PROJECTS = [
    "4Charm",
    "Nexus",
    "RyuSync",
]

PROJECT_BUILD_SCRIPTS = {
    "Libra": "scripts/build-mac.sh",
    "Looper": "scripts/build-mac.sh",
    "MetaBurn": "scripts/build-mac.sh",
    "Swifter": "scripts/build-mac.sh",
    "SwiftTemp": "scripts/build-mac.sh",
}

ALL_BUILDABLE_PROJECTS = [
    *BUILDABLE_PROJECTS,
    *PROJECT_BUILD_SCRIPTS,
]

DOC_ONLY_PROJECTS: set[str] = set()

# Sandbox workspace roots — under IDE/, local git only, no remote.
# These are quick-build project folders that live outside the Apps managed scope
# but still benefit from shared toolchain config syncing.
SANDBOX_ROOTS = [
    "IDE/Codex",
    "IDE/Devin",
    "IDE/Antigravity",
    "IDE/OpenCode",
    "IDE/Cursor",
]

PROJECT_NAME_ALIASES = {
    "4charm": "4Charm",
    "nexus": "Nexus",
    "ryusync": "RyuSync",
    "libra": "Libra",
    "l!bra": "Libra",
    "looper": "Looper",
    "metaburn": "MetaBurn",
    "swifter": "Swifter",
    "swifttemp": "SwiftTemp",
    ".razorcore": ".razorcore",
    "razorcore": ".razorcore",
}


def resolve_project_name(project: str) -> str:
    """Resolve user-provided project names/aliases to canonical workspace names."""
    candidate = project.strip()
    if not candidate:
        return project

    if candidate in MANAGED_PROJECTS or candidate in ALL_BUILDABLE_PROJECTS:
        return candidate

    alias_target = PROJECT_NAME_ALIASES.get(candidate.lower())
    if alias_target:
        return alias_target

    for canonical in MANAGED_PROJECTS:
        if canonical.lower() == candidate.lower():
            return canonical

    return candidate


def workspace_root_from_apps(workspace: Path) -> Path:
    """Resolve the parent workspace root from an Apps workspace."""
    if workspace.name == "Apps":
        return workspace.parent
    return workspace


def resolve_project_path(workspace: Path, project: str) -> Path:
    """Resolve a project name to its filesystem path."""
    resolved = resolve_project_name(project)
    return workspace / resolved


def log_success(msg: str) -> None:
    print(f"{GREEN}✓{NC} {msg}")


def log_warning(msg: str) -> None:
    print(f"{YELLOW}⚠{NC} {msg}")


def log_error(msg: str) -> None:
    print(f"{RED}✗{NC} {msg}")


def log_info(msg: str) -> None:
    print(f"{CYAN}→{NC} {msg}")


def discover_projects(workspace_path: Path) -> list[str]:
    """Auto-discover razorcore-enabled projects in workspace.

    Projects are identified by .razorcore-enabled marker file.
    Falls back to MANAGED_PROJECTS if discovery fails.
    """
    projects = []

    if not workspace_path.exists() or not workspace_path.is_dir():
        return list(MANAGED_PROJECTS)

    for item in workspace_path.iterdir():
        if item.is_dir() and not item.name.startswith("."):
            if (item / ".razorcore-enabled").exists():
                projects.append(item.name)

    # Always include .razorcore and hardcoded projects
    for proj in MANAGED_PROJECTS:
        if proj not in projects:
            projects.append(proj)

    return sorted(projects)


def get_projects(workspace: Path, specified: list[str] | None = None) -> list[Path]:
    """Get list of project directories to operate on."""
    if specified:
        projects = []
        for name in specified:
            resolved_name = resolve_project_name(name)
            proj_path = workspace / resolved_name
            if proj_path.exists():
                projects.append(proj_path)
            else:
                log_warning(f"Project not found: {name}")
        return projects

    discovered = set(discover_projects(workspace))
    ordered = [name for name in MANAGED_PROJECTS if name in discovered]
    extras = sorted(discovered - set(MANAGED_PROJECTS))
    ordered.extend(extras)

    return [workspace / name for name in ordered if (workspace / name).exists()]


def _project_has_changes(proj_dir: Path) -> bool:
    """Return True when git reports pending changes for the project directory."""
    status_result = subprocess.run(
        ["git", "status", "--porcelain"],
        cwd=proj_dir,
        capture_output=True,
        text=True,
        check=False,
    )
    return bool(status_result.stdout.strip())
