"""Refresh and verify vendored razorcore wheels for public app CI."""

from __future__ import annotations

import re
import shutil
import subprocess
from pathlib import Path

from razorcore.cli.registry import (
    MANAGED_APP_PROJECTS,
    log_error,
    log_info,
    log_success,
    log_warning,
)


CI_VENDOR_DIR = Path("ci/vendor")
WHEEL_FILENAME_RE = re.compile(
    r"^razorcore-(?P<version>\d+\.\d+\.\d+)-py3-none-any\.whl$"
)

VENDOR_README = """\
# CI vendor directory

Standalone GitHub Actions for this public repo cannot read the private
`RazorBackRoar/razorcore` repository. CI installs razorcore from the pinned
wheel in this directory via `UV_FIND_LINKS`.

Local development still uses the editable sibling at `../.razorcore`.

## Automatic refresh

From the Apps workspace root, after saving or bumping `.razorcore`:

```bash
razorvendor
```

`save .razorcore` and razorcore version bumps run this automatically when
they change the library.

## Manual refresh

```bash
cd ../.razorcore
uv build
razorvendor
```
"""


def _razorcore_dir(workspace: Path) -> Path:
    return workspace / ".razorcore"


def read_razorcore_version(razorcore_dir: Path) -> str | None:
    """Read the distribution version from razorcore's pyproject.toml."""
    pyproject = razorcore_dir / "pyproject.toml"
    if not pyproject.exists():
        return None
    try:
        import tomllib

        with open(pyproject, "rb") as handle:
            data = tomllib.load(handle)
        version = data.get("project", {}).get("version")
        return version if isinstance(version, str) and version else None
    except OSError, ValueError:
        return None


def wheel_filename(version: str) -> str:
    return f"razorcore-{version}-py3-none-any.whl"


def parse_wheel_version(path: Path) -> str | None:
    match = WHEEL_FILENAME_RE.match(path.name)
    if match is None:
        return None
    return match.group("version")


def app_uses_ci_vendor(app_dir: Path) -> bool:
    """Return True when an app repo uses the vendored-wheel CI layout."""
    workflow = app_dir / ".github/workflows/ci.yml"
    if not workflow.exists():
        return False
    try:
        workflow_text = workflow.read_text(encoding="utf-8")
    except OSError:
        return False
    return "UV_FIND_LINKS: ci/vendor" in workflow_text


def list_vendor_wheels(vendor_dir: Path) -> list[Path]:
    if not vendor_dir.is_dir():
        return []
    return sorted(vendor_dir.glob("razorcore-*-py3-none-any.whl"))


def build_razorcore_wheel(razorcore_dir: Path) -> Path:
    """Build razorcore and return the wheel path for the current version."""
    version = read_razorcore_version(razorcore_dir)
    if version is None:
        raise RuntimeError(f"Could not read razorcore version in {razorcore_dir}")

    build = subprocess.run(
        ["uv", "build", "--wheel"],
        cwd=razorcore_dir,
        capture_output=True,
        text=True,
        check=False,
    )
    if build.returncode != 0:
        detail = (build.stderr or build.stdout or "").strip()
        raise RuntimeError(f"uv build failed for razorcore: {detail}")

    dist_dir = razorcore_dir / "dist"
    expected = dist_dir / wheel_filename(version)
    if expected.exists():
        return expected

    wheels = list(dist_dir.glob(f"razorcore-{version}-*.whl"))
    if not wheels:
        raise RuntimeError(
            f"Expected wheel {expected.name} was not produced under {dist_dir}"
        )
    return wheels[0]


def _write_vendor_readme(vendor_dir: Path) -> None:
    vendor_dir.mkdir(parents=True, exist_ok=True)
    readme = vendor_dir / "README.md"
    current = readme.read_text(encoding="utf-8") if readme.exists() else ""
    if current != VENDOR_README:
        readme.write_text(VENDOR_README, encoding="utf-8")


def _install_wheel_for_app(app_dir: Path, wheel_path: Path, dry_run: bool) -> bool:
    vendor_dir = app_dir / CI_VENDOR_DIR
    target = vendor_dir / wheel_path.name
    changed = False

    for existing in list_vendor_wheels(vendor_dir):
        if existing.name == wheel_path.name:
            continue
        changed = True
        if dry_run:
            log_info(f"[{app_dir.name}] Would remove stale wheel {existing.name}")
        else:
            existing.unlink()
            log_info(f"[{app_dir.name}] Removed stale wheel {existing.name}")

    if target.exists():
        if target.read_bytes() == wheel_path.read_bytes():
            if dry_run:
                log_info(f"[{app_dir.name}] Wheel already up to date ({target.name})")
            return changed
        changed = True
        if dry_run:
            log_info(f"[{app_dir.name}] Would replace {target.name}")
            return True

    changed = True
    if dry_run:
        log_info(f"[{app_dir.name}] Would install {wheel_path.name}")
        return True

    vendor_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(wheel_path, target)
    _write_vendor_readme(vendor_dir)
    log_success(f"[{app_dir.name}] Installed {target.name}")
    return True


def refresh_ci_vendor_wheels(workspace: Path, *, dry_run: bool = False) -> int:
    """Build razorcore once and refresh ci/vendor wheels in all Python apps."""
    razorcore_dir = _razorcore_dir(workspace)
    if not razorcore_dir.is_dir():
        log_error("Missing .razorcore directory in workspace")
        return 1

    targets = [
        workspace / name
        for name in MANAGED_APP_PROJECTS
        if app_uses_ci_vendor(workspace / name)
    ]
    if not targets:
        log_warning("No app repos use ci/vendor; nothing to refresh")
        return 0

    version = read_razorcore_version(razorcore_dir)
    if version is None:
        log_error("Could not determine razorcore version")
        return 1

    log_info(f"Refreshing ci/vendor wheels for razorcore {version}")
    if dry_run:
        log_info("Dry run — no files will be written")
        for app_dir in targets:
            vendor_dir = app_dir / CI_VENDOR_DIR
            expected = vendor_dir / wheel_filename(version)
            if expected.exists():
                log_info(f"[{app_dir.name}] Would keep {expected.name}")
            else:
                log_info(f"[{app_dir.name}] Would install {expected.name}")
        return 0

    try:
        wheel_path = build_razorcore_wheel(razorcore_dir)
    except RuntimeError as exc:
        log_error(str(exc))
        return 1

    updates = 0
    for app_dir in targets:
        if _install_wheel_for_app(app_dir, wheel_path, dry_run=False):
            updates += 1

    if updates:
        log_success(f"Updated ci/vendor in {updates} app repo(s)")
    else:
        log_info("All ci/vendor wheels already matched razorcore")
    return 0


def verify_ci_vendor_wheels(workspace: Path) -> list[str]:
    """Return human-readable baseline issues for vendored CI wheels."""
    razorcore_dir = _razorcore_dir(workspace)
    expected_version = read_razorcore_version(razorcore_dir)
    if expected_version is None:
        return ["could not read .razorcore version"]

    issues: list[str] = []
    expected_name = wheel_filename(expected_version)

    for name in MANAGED_APP_PROJECTS:
        app_dir = workspace / name
        if not app_uses_ci_vendor(app_dir):
            continue

        vendor_dir = app_dir / CI_VENDOR_DIR
        wheels = list_vendor_wheels(vendor_dir)
        if not wheels:
            issues.append(f"{name}: missing ci/vendor razorcore wheel")
            continue
        if len(wheels) != 1:
            issues.append(f"{name}: expected one ci/vendor wheel, found {len(wheels)}")
            continue

        wheel = wheels[0]
        if wheel.name != expected_name:
            found_version = parse_wheel_version(wheel) or wheel.name
            issues.append(
                f"{name}: ci/vendor has {found_version}, expected {expected_version}"
            )

        readme = vendor_dir / "README.md"
        if not readme.exists():
            issues.append(f"{name}: missing ci/vendor/README.md")

    return issues


def maybe_refresh_ci_vendor_wheels(workspace: Path, *, dry_run: bool = False) -> int:
    """Refresh vendored wheels after razorcore changes; non-fatal on build errors."""
    try:
        return refresh_ci_vendor_wheels(workspace, dry_run=dry_run)
    except OSError as exc:
        log_warning(f"ci/vendor refresh skipped: {exc}")
        return 0
