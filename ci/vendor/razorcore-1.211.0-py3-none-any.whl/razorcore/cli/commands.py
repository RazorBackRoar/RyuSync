"""Razorcore CLI Commands — thin re-export shim.

All implementations live in the focused submodules:
  registry.py  — constants, logging, project discovery
  version.py   — version bumping
  sync.py      — config/doc syncing
  build.py     — build pipeline
  verify.py    — project verification
  save.py      — save/commit/push workflow and misc commands

This module re-exports every public symbol so that existing imports of the form
    from razorcore.cli import commands as cmd
    cmd.save_project(...)
continue to work without modification.
"""

from __future__ import annotations

# stdlib modules re-exported so tests can monkeypatch commands.subprocess, etc.
import shutil  # noqa: F401
import subprocess  # noqa: F401

# ---------------------------------------------------------------------------
# app_baseline
# ---------------------------------------------------------------------------
from razorcore.cli.app_baseline import (
    bootstrap_app_baseline,
    polish_github_repo,
    verify_app_baseline,
)

# ---------------------------------------------------------------------------
# build
# ---------------------------------------------------------------------------
from razorcore.cli.build import (
    _run_project_push_preflight,
    build_project,
)

# ---------------------------------------------------------------------------
# ci_vendor
# ---------------------------------------------------------------------------
from razorcore.cli.ci_vendor import (
    maybe_refresh_ci_vendor_wheels,
    refresh_ci_vendor_wheels,
    verify_ci_vendor_wheels,
)

# ---------------------------------------------------------------------------
# registry
# ---------------------------------------------------------------------------
from razorcore.cli.registry import (
    ALL_BUILDABLE_PROJECTS,
    BUILDABLE_PROJECTS,
    CYAN,
    DOC_ONLY_PROJECTS,
    GREEN,
    MANAGED_APP_PROJECTS,
    MANAGED_PROJECTS,
    NC,
    PROJECT_BUILD_SCRIPTS,
    PROJECT_NAME_ALIASES,
    PYTHON_VERSION,
    PYTHON_VERSION_TUPLE,
    RED,
    SANDBOX_ROOTS,
    YELLOW,
    _project_has_changes,
    discover_projects,
    get_projects,
    log_error,
    log_info,
    log_success,
    log_warning,
    resolve_project_name,
    resolve_project_path,
    workspace_root_from_apps,
)

# ---------------------------------------------------------------------------
# save
# ---------------------------------------------------------------------------
from razorcore.cli.save import (
    _build_commit_message,
    _categorize_changed_files,
    _commit_project_changes,
    _compare_metrics,
    _current_branch_name,
    _detect_default_branch,
    _display_metrics,
    _extract_mcp_env_refs,
    _find_open_pr_url,
    _format_size,
    _get_directory_size,
    _get_project_status,
    _handle_no_changes,
    _has_provider_marker,
    _infer_commit_type,
    _infer_scope,
    _looks_sensitive_name,
    _mask_secret,
    _maybe_auto_save_razorcore,
    _maybe_create_pull_request,
    _measure_all_projects,
    _measure_import_time,
    _origin_default_branch,
    _parse_zshrc_credentials,
    _print_save_summary,
    _push_changes,
    _remove_project_egg_info_dirs,
    _resolve_git_context,
    _run_markdown_autoformatter,
    _run_save_loop,
    _warn_outside_changes,
    baseline_command,
    bolt_command,
    commit_all,
    format_markdown,
    install_hooks,
    journal_command,
    list_projects,
    prune_all,
    prune_worktrees,
    push_all,
    razormax,
    razorstatus,
    save_all,
    save_all_safe,
    save_apps,
    save_project,
    test_all,
)

# ---------------------------------------------------------------------------
# sync
# ---------------------------------------------------------------------------
from razorcore.cli.sync import (
    _resolve_master_context_prompt,
    _sync_version_docs,
    get_config_files,
    sync_all,
    sync_configs,
    sync_docs,
    sync_project_agent_versions,
    sync_ssot_versions,
)

# ---------------------------------------------------------------------------
# verify
# ---------------------------------------------------------------------------
from razorcore.cli.verify import (
    _verify_build_tooling,
    _verify_gitignore,
    _verify_portfolio_link,
    _verify_project_configs,
    _verify_required_files,
    check,
    check_all_repos_quality,
    check_repo_quality,
    verify,
)

# ---------------------------------------------------------------------------
# version
# ---------------------------------------------------------------------------
from razorcore.cli.version import (
    _bump_version_number,
    _collect_versions,
    _commit_version_bump,
    _determine_bump_type,
    _get_commit_messages,
    _get_project_version,
    _get_repo_info,
    _tag_prefix,
    _update_version_files,
    auto_bump_version,
    bump_version,
    update_version_by_selector,
)


__all__ = [
    # app baseline
    "bootstrap_app_baseline",
    "polish_github_repo",
    "verify_app_baseline",
    # ci vendor
    "maybe_refresh_ci_vendor_wheels",
    "refresh_ci_vendor_wheels",
    "verify_ci_vendor_wheels",
    # registry
    "ALL_BUILDABLE_PROJECTS",
    "BUILDABLE_PROJECTS",
    "CYAN",
    "DOC_ONLY_PROJECTS",
    "GREEN",
    "MANAGED_APP_PROJECTS",
    "MANAGED_PROJECTS",
    "NC",
    "PROJECT_NAME_ALIASES",
    "PROJECT_BUILD_SCRIPTS",
    "PYTHON_VERSION",
    "PYTHON_VERSION_TUPLE",
    "RED",
    "SANDBOX_ROOTS",
    "YELLOW",
    "_project_has_changes",
    "discover_projects",
    "get_projects",
    "log_error",
    "log_info",
    "log_success",
    "log_warning",
    "resolve_project_name",
    "resolve_project_path",
    "workspace_root_from_apps",
    # version
    "_bump_version_number",
    "_collect_versions",
    "_commit_version_bump",
    "_determine_bump_type",
    "_get_commit_messages",
    "_get_project_version",
    "_get_repo_info",
    "_tag_prefix",
    "_update_version_files",
    "auto_bump_version",
    "bump_version",
    "update_version_by_selector",
    # sync
    "_resolve_master_context_prompt",
    "_sync_version_docs",
    "get_config_files",
    "sync_all",
    "sync_configs",
    "sync_docs",
    "sync_project_agent_versions",
    "sync_ssot_versions",
    # build
    "_run_project_push_preflight",
    "build_project",
    # verify
    "_verify_build_tooling",
    "_verify_gitignore",
    "_verify_portfolio_link",
    "_verify_project_configs",
    "_verify_required_files",
    "check_all_repos_quality",
    "check_repo_quality",
    "check",
    "verify",
    # save
    "_build_commit_message",
    "_categorize_changed_files",
    "_commit_project_changes",
    "_compare_metrics",
    "_current_branch_name",
    "_detect_default_branch",
    "_display_metrics",
    "_extract_mcp_env_refs",
    "_find_open_pr_url",
    "_format_size",
    "_get_directory_size",
    "_get_project_status",
    "_handle_no_changes",
    "_has_provider_marker",
    "_infer_commit_type",
    "_infer_scope",
    "_looks_sensitive_name",
    "_mask_secret",
    "_maybe_auto_save_razorcore",
    "_maybe_create_pull_request",
    "_measure_all_projects",
    "_measure_import_time",
    "_origin_default_branch",
    "_parse_zshrc_credentials",
    "_print_save_summary",
    "_push_changes",
    "_remove_project_egg_info_dirs",
    "_resolve_git_context",
    "_run_markdown_autoformatter",
    "_run_save_loop",
    "_warn_outside_changes",
    "baseline_command",
    "bolt_command",
    "commit_all",
    "format_markdown",
    "install_hooks",
    "journal_command",
    "list_projects",
    "prune_all",
    "prune_worktrees",
    "push_all",
    "razormax",
    "razorstatus",
    "save_all",
    "save_all_safe",
    "save_apps",
    "save_project",
    "test_all",
]
