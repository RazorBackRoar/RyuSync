"""Daily rebuild + GitHub Release orchestrator for product apps.

This is the `razorapps` command. It is not config sync (`razorsync`) and it is
not git-only publish (`razorpush`). It *calls* razorpush, then `razorbuild`,
then `release`.
"""

from __future__ import annotations

import json
import os
import subprocess
from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from razorcore.cli.app_kind import detect_app_kind, read_version_file
from razorcore.cli.build import build_project, find_ship_dmg
from razorcore.cli.git_safety import require_git_mutation_allowed
from razorcore.cli.registry import (
    PUBLIC_APP_PROJECTS,
    log_error,
    log_info,
    log_success,
    log_warning,
    resolve_project_name,
    workspace_root_from_apps,
)
from razorcore.cli.release import file_sha256, publish_release, release_exists


COMMANDS = ("status", "daily", "build", "push", "ship")
AUTOSYNC_SCRIPT = "scripts/razor-autosync.zsh"
STAMP_ENV = "RAZORCORE_DAILY_STAMP_DIR"

PushRunner = Callable[[bool], int]
BuildRunner = Callable[[Path, str], int]
ShipRunner = Callable[[Path, str, bool, bool], int]


def _stamp_dir() -> Path:
    override = os.environ.get(STAMP_ENV, "").strip()
    if override:
        return Path(override)
    return (
        Path.home()
        / "Library"
        / "Application Support"
        / "razorcore"
        / "daily-apps"
    )


def _stamp_path(app: str) -> Path:
    return _stamp_dir() / f"{app}.json"


def _load_stamp(app: str) -> dict[str, Any]:
    path = _stamp_path(app)
    if not path.is_file():
        return {}
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return payload if isinstance(payload, dict) else {}


def _write_stamp(app: str, payload: dict[str, Any]) -> None:
    path = _stamp_path(app)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


def _git(args: list[str], cwd: Path) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        args,
        cwd=cwd,
        check=False,
        capture_output=True,
        text=True,
    )


def _head_sha(repo_dir: Path) -> str:
    proc = _git(["git", "rev-parse", "HEAD"], repo_dir)
    return proc.stdout.strip() if proc.returncode == 0 else ""


def _is_dirty(repo_dir: Path) -> bool:
    proc = _git(["git", "status", "--porcelain"], repo_dir)
    return bool(proc.stdout.strip())


def _origin_repo(repo_dir: Path) -> str:
    proc = _git(["git", "remote", "get-url", "origin"], repo_dir)
    if proc.returncode != 0:
        return ""
    remote = proc.stdout.strip()
    prefix = "https://github.com/"
    ssh = "git@github.com:"
    if remote.startswith(prefix):
        return remote.removeprefix(prefix).removesuffix(".git")
    if remote.startswith(ssh):
        return remote.removeprefix(ssh).removesuffix(".git")
    return ""


def _autosync_script(workspace: Path) -> Path:
    return workspace_root_from_apps(workspace) / ".razorcore" / AUTOSYNC_SCRIPT


def default_push_runner(workspace: Path) -> PushRunner:
    script = _autosync_script(workspace)

    def _run(dry_run: bool) -> int:
        if not script.is_file():
            log_error(f"razorpush script not found: {script}")
            return 1
        env = os.environ.copy()
        env["RAZORCORE_AUTO_PUSH"] = "1"
        args = ["/bin/zsh", str(script)]
        if dry_run:
            args.append("--dry-run")
        log_info("razorpush (autosync with GitHub push)")
        result = subprocess.run(args, env=env, check=False)
        return result.returncode or 0

    return _run


def _target_apps(workspace: Path, app: str | None) -> list[str] | int:
    if app:
        resolved = resolve_project_name(app)
        if resolved not in PUBLIC_APP_PROJECTS:
            log_error(f"Unknown product app: {app}")
            return 1
        if not (workspace / resolved).is_dir():
            log_error(f"App directory not found: {workspace / resolved}")
            return 1
        return [resolved]
    found = [name for name in PUBLIC_APP_PROJECTS if (workspace / name).is_dir()]
    missing = [name for name in PUBLIC_APP_PROJECTS if name not in found]
    for name in missing:
        log_warning(f"{name}: directory not found, skipped")
    return found


def _app_version(repo_dir: Path) -> str:
    kind = detect_app_kind(repo_dir)
    version, _source = read_version_file(kind, repo_dir)
    return version.strip() if version else ""


def _github_tag(repo_dir: Path, version: str) -> str:
    origin = _origin_repo(repo_dir)
    if not origin or not version:
        return ""
    tag = f"v{version}"
    return tag if release_exists(origin, tag, repo_dir) else ""


def _should_skip_rebuild(
    app: str,
    repo_dir: Path,
    *,
    force: bool,
) -> tuple[bool, str]:
    if force:
        return False, "forced"
    head = _head_sha(repo_dir)
    dmg = find_ship_dmg(repo_dir, app)
    if not head or dmg is None:
        return False, "missing local dmg or HEAD"
    stamp = _load_stamp(app)
    checksum = file_sha256(dmg)
    if stamp.get("head") != head or stamp.get("sha256") != checksum:
        return False, "source or dmg changed"
    version = _app_version(repo_dir)
    tag = f"v{version}" if version else ""
    origin = _origin_repo(repo_dir)
    if not origin or not tag or not release_exists(origin, tag, repo_dir):
        return False, "GitHub release missing"
    return True, f"HEAD {head[:7]} already shipped"


def run_status(workspace: Path, *, app: str | None) -> int:
    targets = _target_apps(workspace, app)
    if isinstance(targets, int):
        return targets

    print(f"{'App':<12} {'Ver':<8} {'HEAD':<8} {'Local DMG':<22} GitHub")
    print("-" * 72)
    for name in targets:
        repo = workspace / name
        version = _app_version(repo) or "?"
        head = _head_sha(repo)
        short = head[:7] if head else "?"
        dmg = find_ship_dmg(repo, name)
        dmg_label = dmg.name if dmg is not None else "missing"
        gh_tag = _github_tag(repo, version) or "—"
        print(f"{name:<12} {version:<8} {short:<8} {dmg_label:<22} {gh_tag}")
    print()
    print("Commands: razorapps status | daily | build | push | ship")
    print("razorsync = config sync (not this). razorpush = git publish (called by daily).")
    return 0


def run_push(
    workspace: Path,
    *,
    dry_run: bool,
    push_runner: PushRunner | None = None,
) -> int:
    if not dry_run and push_runner is None and not require_git_mutation_allowed("push repositories via razorapps", log_error):
        return 1
    runner = push_runner or default_push_runner(workspace)
    code = runner(dry_run)
    if code != 0:
        log_error("razorpush failed")
        return code
    log_success("Source repos published via razorpush")
    return 0


def run_build(
    workspace: Path,
    *,
    app: str | None,
    force: bool,
    dry_run: bool,
    build_runner: BuildRunner | None = None,
) -> int:
    targets = _target_apps(workspace, app)
    if isinstance(targets, int):
        return targets
    runner = build_runner or build_project
    status = 0
    for name in targets:
        repo = workspace / name
        skip, reason = _should_skip_rebuild(name, repo, force=force)
        if skip:
            log_info(f"{name}: skip rebuild ({reason})")
            continue
        if dry_run:
            log_info(f"{name}: dry-run would razorbuild ({reason})")
            continue
        log_info(f"{name}: razorbuild ({reason})")
        code = runner(workspace, name)
        if code != 0:
            log_error(f"{name}: razorbuild failed")
            status = code
    return status


def run_ship(
    workspace: Path,
    *,
    app: str | None,
    force: bool,
    dry_run: bool,
    allow_dirty: bool,
    delete_old: bool = False,
    ship_runner: ShipRunner | None = None,
) -> int:
    targets = _target_apps(workspace, app)
    if isinstance(targets, int):
        return targets
    runner = ship_runner or (
        lambda ws, name, dirty, dry: publish_release(
            ws, name, allow_dirty=dirty, dry_run=dry, delete_old=delete_old
        )
    )
    status = 0
    for name in targets:
        repo = workspace / name
        skip, reason = _should_skip_rebuild(name, repo, force=force)
        if skip:
            log_info(f"{name}: skip ship ({reason})")
            continue
        if _is_dirty(repo) and not allow_dirty and not dry_run:
            log_warning(f"{name}: dirty tree, not shipping (build may still be local)")
            continue
        dmg = find_ship_dmg(repo, name)
        if dmg is None:
            if dry_run:
                log_info(f"{name}: dry-run would ship after rebuild (no local DMG yet)")
                continue
            log_error(f"{name}: no DMG to ship; run razorapps build first")
            status = 1
            continue
        log_info(f"{name}: publish GitHub Release")
        code = runner(workspace, name, allow_dirty, dry_run)
        if code != 0:
            log_error(f"{name}: release failed")
            status = code
            continue
        if dry_run:
            continue
        dmg = find_ship_dmg(repo, name)
        if dmg is None:
            continue
        version = _app_version(repo)
        _write_stamp(
            name,
            {
                "head": _head_sha(repo),
                "version": version,
                "tag": f"v{version}" if version else "",
                "dmg": str(dmg),
                "sha256": file_sha256(dmg),
                "shipped_at": datetime.now(UTC).isoformat(),
            },
        )
        log_success(f"{name}: shipped")
    return status


def run_daily(
    workspace: Path,
    *,
    app: str | None,
    force: bool,
    dry_run: bool,
    allow_dirty: bool,
    push_runner: PushRunner | None = None,
    build_runner: BuildRunner | None = None,
    ship_runner: ShipRunner | None = None,
) -> int:
    """Policy B: razorpush → rebuild → ship GitHub Releases."""
    print(f"\n{'=' * 60}")
    print("  razorapps daily")
    print(f"{'=' * 60}\n")
    push_code = run_push(
        workspace, dry_run=dry_run, push_runner=push_runner
    )
    build_code = run_build(
        workspace,
        app=app,
        force=force,
        dry_run=dry_run,
        build_runner=build_runner,
    )
    ship_code = run_ship(
        workspace,
        app=app,
        force=force,
        dry_run=dry_run,
        allow_dirty=allow_dirty,
        ship_runner=ship_runner,
    )
    status = push_code or build_code or ship_code
    if status == 0:
        log_success("Daily rebuild/ship complete")
    else:
        log_error("Daily rebuild/ship finished with errors")
    return status


def run_razorapps(
    workspace: Path,
    *,
    command: str = "status",
    app: str | None = None,
    dry_run: bool = False,
    force: bool = False,
    allow_dirty: bool = False,
    push_runner: PushRunner | None = None,
    build_runner: BuildRunner | None = None,
    ship_runner: ShipRunner | None = None,
) -> int:
    if command not in COMMANDS:
        log_error(f"Unknown razorapps command: {command}")
        return 1
    if command == "status":
        return run_status(workspace, app=app)
    if command == "push":
        return run_push(workspace, dry_run=dry_run, push_runner=push_runner)
    if command == "build":
        return run_build(
            workspace,
            app=app,
            force=force,
            dry_run=dry_run,
            build_runner=build_runner,
        )
    if command == "ship":
        return run_ship(
            workspace,
            app=app,
            force=force,
            dry_run=dry_run,
            allow_dirty=allow_dirty,
            ship_runner=ship_runner,
        )
    return run_daily(
        workspace,
        app=app,
        force=force,
        dry_run=dry_run,
        allow_dirty=allow_dirty,
        push_runner=push_runner,
        build_runner=build_runner,
        ship_runner=ship_runner,
    )
