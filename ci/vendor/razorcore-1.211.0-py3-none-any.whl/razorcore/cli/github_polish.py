"""Apply RazorBackRoar GitHub repository metadata via the gh CLI."""

from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

from razorcore.cli.app_kind import AppKind, default_topics, detect_app_kind
from razorcore.cli.app_readme import GITHUB_ORG


def _gh_available() -> bool:
    return shutil.which("gh") is not None


def apply_github_polish(
    display_name: str,
    description: str,
    *,
    proj_dir: Path | None = None,
    org: str = GITHUB_ORG,
    dry_run: bool = False,
) -> tuple[bool, str]:
    """Set description, homepage, and topics on a GitHub repo. Returns (ok, message)."""
    if not _gh_available():
        return False, "gh CLI not found — skipped GitHub metadata"

    repo = f"{org}/{display_name}"
    homepage = f"https://github.com/{org}/{display_name}/releases"
    topics = (
        default_topics(detect_app_kind(proj_dir))
        if proj_dir is not None
        else default_topics(AppKind.PYTHON)
    )

    cmd = [
        "gh",
        "repo",
        "edit",
        repo,
        "--description",
        description,
        "--homepage",
        homepage,
    ]
    for topic in topics:
        cmd.extend(["--add-topic", topic])

    if dry_run:
        return True, f"Would run: {' '.join(cmd)}"

    result = subprocess.run(cmd, capture_output=True, text=True, check=False)
    if result.returncode == 0:
        return True, f"GitHub metadata updated for {repo}"

    stderr = (result.stderr or result.stdout or "").strip()
    if "Could not resolve to a Repository" in stderr or "Not Found" in stderr:
        return (
            False,
            f"GitHub repo {repo} not found — create it on GitHub, then re-run razornewapp",
        )
    return False, f"gh repo edit failed: {stderr or 'unknown error'}"


def disable_wiki(display_name: str, *, org: str = GITHUB_ORG, dry_run: bool = False) -> tuple[bool, str]:
    if not _gh_available():
        return False, "gh CLI not found — skipped wiki setting"

    if dry_run:
        return True, f"Would disable wiki on {org}/{display_name}"

    result = subprocess.run(
        [
            "gh",
            "api",
            "-X",
            "PATCH",
            f"repos/{org}/{display_name}",
            "-f",
            "has_wiki=false",
        ],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode == 0:
        return True, f"Disabled wiki on {org}/{display_name}"
    stderr = (result.stderr or result.stdout or "").strip()
    return False, f"Failed to disable wiki: {stderr or 'unknown error'}"
