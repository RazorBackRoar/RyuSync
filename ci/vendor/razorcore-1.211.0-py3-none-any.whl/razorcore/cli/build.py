"""Razorcore CLI Build — build pipeline functions."""

from __future__ import annotations

import json
import subprocess
from pathlib import Path

from razorcore.cli.activity import append_activity_event
from razorcore.cli.registry import (
    ALL_BUILDABLE_PROJECTS,
    GREEN,
    NC,
    PROJECT_BUILD_SCRIPTS,
    PYTHON_VERSION,
    log_error,
    log_info,
    log_success,
    resolve_project_name,
)


def _run_project_preflight(proj_dir: Path, project: str) -> int:
    for label, args in (
        ("uv sync", ["uv", "sync"]),
        (
            "ty check",
            ["uv", "run", "ty", "check", "src", "--python-version", PYTHON_VERSION],
        ),
    ):
        log_info(f"{project}: running {label}...")
        result = subprocess.run(
            args,
            cwd=proj_dir,
            capture_output=True,
            text=True,
            check=False,
        )
        if result.returncode == 0:
            continue
        log_error(f"{project}: {label} failed")
        if result.stdout.strip():
            print(result.stdout)
        if result.stderr.strip():
            print(result.stderr)
        return result.returncode or 1
    return 0


def _run_project_push_preflight(proj_dir: Path, project: str) -> int:
    """Backward-compatible alias for callers not yet migrated."""
    return _run_project_preflight(proj_dir, project)


def build_project(workspace: Path, project: str, _create_dmg: bool = True) -> int:
    """Build a project through its registered artifact-only build path."""
    project = resolve_project_name(project)

    print(f"\n{'=' * 60}")
    print(f"  Razorcore Build: {project}")
    print(f"{'=' * 60}\n")

    # Check if project is buildable
    if project not in ALL_BUILDABLE_PROJECTS:
        log_error(
            f"{project} is not a buildable app (documentation or library project)"
        )
        log_info(f"Buildable projects: {', '.join(ALL_BUILDABLE_PROJECTS)}")
        return 1

    proj_dir = workspace / project
    if not proj_dir.exists():
        log_error(f"Project not found: {project}")
        return 1

    razorcore_dir = workspace / ".razorcore"
    registered_script = PROJECT_BUILD_SCRIPTS.get(project)
    if registered_script:
        build_script = proj_dir / registered_script
        build_command = ["/bin/zsh", str(build_script)]
        build_cwd = proj_dir
    else:
        build_script = razorcore_dir / "universal-build.sh"
        build_command = [str(build_script), project]
        build_cwd = razorcore_dir

    if not build_script.exists():
        log_error(f"Build script not found: {build_script}")
        return 1

    pyproject = proj_dir / "pyproject.toml"
    version = "0.0.0"
    if pyproject.exists():
        try:
            import tomllib

            with open(pyproject, "rb") as f:
                data = tomllib.load(f)
            version = data.get("project", {}).get("version", "0.0.0")
        except (OSError, ValueError, ImportError):
            pass
    elif (tauri_config := proj_dir / "src-tauri" / "tauri.conf.json").exists():
        try:
            data = json.loads(tauri_config.read_text(encoding="utf-8"))
            version = data.get("version", "0.0.0")
        except (OSError, ValueError):
            pass

    log_info(f"Building {project} v{version}...")

    result = subprocess.run(build_command, cwd=build_cwd, check=False)

    if result.returncode != 0:
        log_error("Build failed")
        append_activity_event(
            workspace,
            event="build",
            app=project,
            details={"version": version, "status": "failed"},
        )
        return result.returncode

    log_success("Build completed without creating tags or pushing to Git")
    append_activity_event(
        workspace,
        event="build",
        app=project,
        details={"version": version, "status": "success"},
    )

    print(f"\n{'=' * 60}")
    print(f"  {GREEN}✓ Build complete: {project} v{version}{NC}")
    print(f"{'=' * 60}\n")

    return 0
