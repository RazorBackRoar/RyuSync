"""Razorcore CLI Build — build pipeline functions."""

from __future__ import annotations

import subprocess
from pathlib import Path

from razorcore.cli.activity import append_activity_event
from razorcore.cli.app_kind import detect_app_kind, read_version_file
from razorcore.cli.registry import (
    ALL_BUILDABLE_PROJECTS,
    BUILDABLE_PROJECTS,
    GREEN,
    NC,
    PROJECT_BUILD_SCRIPTS,
    PUBLIC_APP_PROJECTS,
    PYTHON_VERSION,
    log_error,
    log_info,
    log_success,
    log_warning,
    resolve_project_name,
)


def _run_project_preflight(proj_dir: Path, project: str) -> int:
    for label, args in (
        ("uv sync", ["uv", "sync"]),
        (
            "ty check",
            ["uv", "run", "ty", "check", "src", "--python-version", PYTHON_VERSION],
        ),
    ):
        log_info(f"{project}: running {label}...")
        result = subprocess.run(
            args,
            cwd=proj_dir,
            capture_output=True,
            text=True,
            check=False,
        )
        if result.returncode == 0:
            continue
        log_error(f"{project}: {label} failed")
        if result.stdout.strip():
            print(result.stdout)
        if result.stderr.strip():
            print(result.stderr)
        return result.returncode or 1
    return 0


def _run_project_push_preflight(proj_dir: Path, project: str) -> int:
    """Backward-compatible alias for callers not yet migrated."""
    return _run_project_preflight(proj_dir, project)


def resolve_project_build(
    workspace: Path, project: str
) -> tuple[Path, list[str], Path] | None:
    """Resolve the artifact build command for a project.

    Discovery order (so future apps inherit branding/DMG lock without a registry
    edit):
    1. Explicit ``PROJECT_BUILD_SCRIPTS`` entry
    2. ``scripts/release-build.zsh`` (Rust/Tauri)
    3. ``scripts/build-mac.sh`` (Swift)
    4. ``<Project>.spec`` → shared ``universal-build.sh`` (Python)
    """
    proj_dir = workspace / project
    if not proj_dir.exists():
        return None

    razorcore_dir = workspace / ".razorcore"
    registered = PROJECT_BUILD_SCRIPTS.get(project)
    if registered:
        script = proj_dir / registered
        return script, ["/bin/zsh", str(script)], proj_dir

    release_script = proj_dir / "scripts" / "release-build.zsh"
    if release_script.exists():
        return release_script, ["/bin/zsh", str(release_script)], proj_dir

    swift_script = proj_dir / "scripts" / "build-mac.sh"
    if swift_script.exists():
        return swift_script, ["/bin/bash", str(swift_script)], proj_dir

    spec = proj_dir / f"{project}.spec"
    if spec.exists():
        script = razorcore_dir / "universal-build.sh"
        return script, [str(script), project], razorcore_dir

    # Known Python managed apps may not have a local .spec in unit-test stubs;
    # still route them through universal-build.sh.
    if project in BUILDABLE_PROJECTS:
        script = razorcore_dir / "universal-build.sh"
        return script, [str(script), project], razorcore_dir

    return None


def build_project(workspace: Path, project: str, _create_dmg: bool = True) -> int:
    """Build a project through its registered artifact-only build path."""
    project = resolve_project_name(project)

    print(f"\n{'=' * 60}")
    print(f"  Razorcore Build: {project}")
    print(f"{'=' * 60}\n")

    proj_dir = workspace / project
    if not proj_dir.exists():
        log_error(f"Project not found: {project}")
        return 1

    resolved = resolve_project_build(workspace, project)
    if resolved is None:
        if project not in ALL_BUILDABLE_PROJECTS:
            log_error(
                f"{project} is not a buildable app (no .spec, build-mac.sh, "
                "or release-build.zsh)"
            )
            log_info(f"Known buildable projects: {', '.join(ALL_BUILDABLE_PROJECTS)}")
            return 1
        log_error(f"Build script not found for {project}")
        return 1

    build_script, build_command, build_cwd = resolved
    if not build_script.exists():
        log_error(f"Build script not found: {build_script}")
        return 1

    kind = detect_app_kind(proj_dir)
    version, _source = read_version_file(kind, proj_dir)
    if not version:
        version = "0.0.0"

    log_info(f"Building {project} v{version}...")

    result = subprocess.run(build_command, cwd=build_cwd, check=False)

    if result.returncode != 0:
        log_error("Build failed")
        append_activity_event(
            workspace,
            event="build",
            app=project,
            details={"version": version, "status": "failed"},
        )
        return result.returncode

    log_success("Build completed without creating tags or pushing to Git")
    append_activity_event(
        workspace,
        event="build",
        app=project,
        details={"version": version, "status": "success"},
    )

    print(f"\n{'=' * 60}")
    print(f"  {GREEN}✓ Build complete: {project} v{version}{NC}")
    print(f"{'=' * 60}\n")

    return 0


def find_ship_dmg(repo_dir: Path, app: str) -> Path | None:
    """Return the in-repo ship DMG (Python dist/ or Swift build/Release/)."""
    candidates = [
        repo_dir / "dist" / f"{app}.dmg",
        repo_dir / "build" / "Release" / f"{app}.dmg",
    ]
    existing = [path for path in candidates if path.is_file()]
    if not existing:
        return None
    return max(existing, key=lambda path: path.stat().st_mtime)


def build_all(
    workspace: Path,
    *,
    apps: list[str] | None = None,
) -> int:
    """Build every public product app. Continues after a failure."""
    targets = apps if apps is not None else list(PUBLIC_APP_PROJECTS)
    status = 0
    results: list[tuple[str, int]] = []

    for name in targets:
        resolved = resolve_project_name(name)
        proj_dir = workspace / resolved
        if not proj_dir.is_dir():
            log_warning(f"{resolved}: directory not found, skipped")
            results.append((resolved, 1))
            status = 1
            continue
        code = build_project(workspace, resolved)
        results.append((resolved, code))
        if code != 0:
            status = code

    print(f"\n{'=' * 60}")
    print("  Razorcore Build All")
    print(f"{'=' * 60}")
    for name, code in results:
        mark = f"{GREEN}✓{NC}" if code == 0 else "✗"
        print(f"  {mark} {name}")
    print()
    return status
