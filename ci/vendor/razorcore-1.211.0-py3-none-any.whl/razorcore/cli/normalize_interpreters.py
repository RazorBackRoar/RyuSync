"""Normalize interpreter references in a project or workspace tree.

Scans Python shebangs and VS Code settings for references to stale/ambiguous
interpreters and rewrites them to the canonical Python 3 command, which is
pinned to the 3.14 series (`requires-python ==3.14.*`, `.python-version`,
uv pin, Homebrew `python@3.14`):

- shebangs: `#!/usr/bin/env python3`
- app editor configs: `/Users/home/.local/bin/python3`
- IDE editor configs: `/Users/home/Workspace/IDE/.venv/bin/python3`

Used as a safety step during `razorsync` and `razor-autosync` so that new
Python source files do not slip in with `python3.14` shebangs or with a
full/fragile uv install path.
"""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path


CANONICAL_PYTHON = "/Users/home/.local/bin/python3"
CANONICAL_SHEBANG = "#!/usr/bin/env python3"
CANONICAL_TY = "/Users/home/.local/bin/ty"
IDE_CANONICAL_PYTHON = "/Users/home/Workspace/IDE/.venv/bin/python3"
IDE_CANONICAL_TY = "/Users/home/Workspace/IDE/.venv/bin/ty"

# Directories that should be skipped entirely.
EXCLUDE_DIRS = frozenset(
    {
        ".venv",
        "venv",
        ".git",
        ".github",
        "build",
        "dist",
        "target",
        "node_modules",
        "__pycache__",
        ".pytest_cache",
        ".ruff_cache",
        ".ty",
        "GitHub",
        "Icon",
        "dependabot",
    }
)

# Any shebang that resolves to a python interpreter.
SHEBANG_RE = re.compile(
    r"^#![ \t]*/usr/bin/env\s+python(3(?:\.\d+)?)?\s*$", re.IGNORECASE
)
SHEBANG_RE_LONG = re.compile(
    r"^#![ \t]*/Users/home/\.local/(?:bin/python3(?:\.14)?|share/uv/python/[^/]+/bin/python3(?:\.14)?)\s*$",
    re.IGNORECASE,
)

# Settings keys we want to keep pinned to the canonical interpreter/ty path.
# This regex captures the prefix (key + colon), the value (string or array),
# and any trailing text on the same line (comma, comment, whitespace).
SETTINGS_LINE_RE = re.compile(
    r'^(\s*"(?:python\.defaultInterpreterPath|ruff\.interpreter|ty\.interpreter|ty\.path)"\s*:\s*)'
    r'(?:"([^"]*)"|\[([^\]]*)\])'
    r"(.*)$",
    re.MULTILINE,
)

# Substrings we never want to see inside an interpreter setting.
BAD_PYTHON_REFS = re.compile(
    r"/Users/home/\.venv/bin/python3|"
    r"/Users/home/\.local/bin/python3\.14|"
    r"/Users/home/\.local/share/uv/python/[^/]+/bin/python3(?:\.14)?|"
    r"/opt/homebrew/bin/python3(?:\.14)?|"
    r"\$\{workspaceFolder\}/\.venv/bin/python|"
    r"/usr/bin/env python(?:3(?:\.\d+)?)?",
    re.IGNORECASE,
)


def _is_excluded(path: Path) -> bool:
    return any(part in EXCLUDE_DIRS for part in path.parts)


def _build_settings_replacement(
    match: re.Match,
    canonical_python: str = CANONICAL_PYTHON,
    canonical_ty: str = CANONICAL_TY,
) -> str:
    """Return the replacement text for one matched settings line."""
    prefix = match.group(1)
    string_value = match.group(2)
    array_body = match.group(3)
    suffix = match.group(4)

    key = ""
    key_match = re.match(r'\s*"([^"]+)"', prefix)
    if key_match:
        key = key_match.group(1)

    is_array = array_body is not None
    existing_text = array_body if is_array else string_value

    # Determine the canonical value shape for this key.
    if key == "ty.path":
        canonical_str = canonical_ty
    else:
        canonical_str = canonical_python

    if key == "python.defaultInterpreterPath":
        canonical_value = f'"{canonical_str}"'
    else:
        canonical_value = f'["{canonical_str}"]'

    # Decide whether the existing value is already correct.
    already_correct = False
    has_bad_ref = bool(BAD_PYTHON_REFS.search(existing_text))

    if key == "python.defaultInterpreterPath":
        # This key is a string, not an array.
        already_correct = (
            not has_bad_ref and not is_array and string_value == canonical_str
        )
    else:
        # ruff.interpreter, ty.interpreter, and ty.path are all arrays.
        if not has_bad_ref and is_array:
            array_items = [p.strip().strip('"') for p in array_body.split(",")]
            array_items = [p for p in array_items if p]
            already_correct = array_items == [canonical_str]

    if already_correct:
        return match.group(0)

    return f"{prefix}{canonical_value}{suffix}"


def _is_vscode_or_workspace_file(path: Path) -> bool:
    if path.name == "settings.json" and ".vscode" in path.parts:
        return True
    if path.suffix == ".code-workspace":
        return True
    return False


def normalize_shebangs(root: Path, dry_run: bool = False) -> list[str]:
    """Fix Python shebangs under `root`.  Returns the list of changed paths."""
    changed: list[str] = []

    for path in root.rglob("*.py"):
        if _is_excluded(path):
            continue

        try:
            stat = path.stat()
        except OSError, FileNotFoundError:
            continue
        if stat.st_size == 0:
            continue

        try:
            with path.open("r", encoding="utf-8", errors="ignore") as fh:
                lines = fh.readlines()
        except OSError, FileNotFoundError:
            continue

        if not lines:
            continue

        first = lines[0].rstrip("\n")
        if not (SHEBANG_RE.match(first) or SHEBANG_RE_LONG.match(first)):
            continue

        canonical = CANONICAL_SHEBANG
        if first == canonical:
            continue

        if dry_run:
            changed.append(str(path))
            continue

        eol = lines[0][len(lines[0].rstrip("\n")) :]
        lines[0] = canonical + eol
        with path.open("w", encoding="utf-8") as fh:
            fh.writelines(lines)
        changed.append(str(path))

    return changed


def normalize_editor_configs(
    root: Path,
    dry_run: bool = False,
    canonical_python: str = CANONICAL_PYTHON,
    canonical_ty: str = CANONICAL_TY,
) -> list[str]:
    """Fix interpreter paths in .vscode/settings.json and *.code-workspace."""
    changed: list[str] = []

    candidates = list(root.rglob(".vscode/settings.json"))
    candidates.extend(root.rglob("*.code-workspace"))

    for path in candidates:
        if _is_excluded(path):
            continue
        if not _is_vscode_or_workspace_file(path):
            continue

        try:
            with path.open("r", encoding="utf-8", errors="ignore") as fh:
                text = fh.read()
        except OSError, FileNotFoundError:
            continue

        new_text = SETTINGS_LINE_RE.sub(
            lambda match: _build_settings_replacement(
                match,
                canonical_python=canonical_python,
                canonical_ty=canonical_ty,
            ),
            text,
        )
        if new_text == text:
            continue

        if dry_run:
            changed.append(str(path))
            continue

        with path.open("w", encoding="utf-8") as fh:
            fh.write(new_text)
        changed.append(str(path))

    return changed


def normalize_project(
    root: Path,
    dry_run: bool = False,
    canonical_python: str = CANONICAL_PYTHON,
    canonical_ty: str = CANONICAL_TY,
) -> dict[str, list[str]]:
    """Run all normalizations under a single project root."""
    if not root.is_dir():
        return {"shebangs": [], "editor_configs": []}
    return {
        "shebangs": normalize_shebangs(root, dry_run=dry_run),
        "editor_configs": normalize_editor_configs(
            root,
            dry_run=dry_run,
            canonical_python=canonical_python,
            canonical_ty=canonical_ty,
        ),
    }


def _report(changed: dict[str, list[str]]) -> bool:
    any_changed = False
    for label, paths in changed.items():
        if paths:
            any_changed = True
            print(f"  {label}:")
            for p in paths:
                print(f"    - {p}")
    return any_changed


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Normalize Python interpreter references in a directory tree."
    )
    parser.add_argument("root", type=Path, help="root directory to scan")
    parser.add_argument(
        "--dry-run", action="store_true", help="print changes, do not write"
    )
    parser.add_argument(
        "--only",
        choices=["shebangs", "editor_configs", "all"],
        default="all",
        help="what to normalize",
    )
    args = parser.parse_args(argv)

    root = args.root.expanduser().resolve()

    if args.only == "shebangs":
        changed = {"shebangs": normalize_shebangs(root, dry_run=args.dry_run)}
    elif args.only == "editor_configs":
        changed = {
            "editor_configs": normalize_editor_configs(root, dry_run=args.dry_run)
        }
    else:
        changed = normalize_project(root, dry_run=args.dry_run)

    if not _report(changed):
        print("No stale interpreter references found.")
        return 0

    if args.dry_run:
        print("\nDry run: no files were modified.")
    else:
        print("\nInterpreter references normalized.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
