"""Razorcore CLI Version — all version-bumping functions."""

from __future__ import annotations

import json
import os
import re
import subprocess
import tempfile
from pathlib import Path

from razorcore.cli.activity import append_activity_event
from razorcore.cli.git_safety import require_git_mutation_allowed
from razorcore.cli.registry import (
    BUILDABLE_PROJECTS,
    MANAGED_APP_PROJECTS,
    log_error,
    log_info,
    log_success,
    log_warning,
)


def _tag_prefix(project: str) -> str:
    return project.lstrip(".")


def _collect_versions(workspace: Path) -> dict[str, str]:
    versions: dict[str, str] = {}
    for name in BUILDABLE_PROJECTS + [".razorcore"]:
        proj_dir = workspace / name
        pyproject = proj_dir / "pyproject.toml"

        if pyproject.exists():
            try:
                import tomllib

                with open(pyproject, "rb") as f:
                    data = tomllib.load(f)
                    version = data.get("project", {}).get("version", None)
                    if version:
                        versions[name] = version
                        log_info(f"{name}: v{version}")
            except (OSError, ValueError, ImportError) as e:
                log_warning(f"Could not read {name}/pyproject.toml: {e}")
        else:
            log_warning(f"{name}/pyproject.toml not found")

    return versions


def _get_repo_info(proj_dir: Path) -> tuple[Path, Path, bool, str]:
    """Get repo root, resolved proj dir, and project relative path."""
    git_root_result = subprocess.run(
        ["git", "rev-parse", "--show-toplevel"],
        cwd=proj_dir,
        capture_output=True,
        text=True,
        check=False,
    )
    if git_root_result.returncode != 0 or not git_root_result.stdout.strip():
        return proj_dir, proj_dir.resolve(), False, ""

    repo_root = Path(git_root_result.stdout.strip()).resolve()
    proj_dir_resolved = proj_dir.resolve()
    is_nested = repo_root != proj_dir_resolved
    project_rel = ""
    if is_nested:
        try:
            project_rel = proj_dir_resolved.relative_to(repo_root).as_posix()
        except ValueError:
            return proj_dir, proj_dir_resolved, False, ""
    return repo_root, proj_dir_resolved, is_nested, project_rel


def _get_commit_messages(proj_dir: Path, tag_prefix: str, is_nested: bool) -> list[str]:
    """Get commit messages since last tag."""
    tag_match = f"{tag_prefix}-v*" if is_nested else "v*"
    result = subprocess.run(
        ["git", "describe", "--tags", "--abbrev=0", "--match", tag_match],
        cwd=proj_dir,
        capture_output=True,
        text=True,
        check=False,
    )
    commit_range = f"{result.stdout.strip()}..HEAD" if result.returncode == 0 else "-1"

    if commit_range == "-1":
        result = subprocess.run(
            ["git", "log", "-1", "--pretty=format:%s"],
            cwd=proj_dir,
            capture_output=True,
            text=True,
            check=False,
        )
    else:
        result = subprocess.run(
            ["git", "log", commit_range, "--pretty=format:%s"],
            cwd=proj_dir,
            capture_output=True,
            text=True,
            check=False,
        )
    return result.stdout.strip().split("\n") if result.stdout.strip() else []


def _determine_bump_type(commits: list[str]) -> str:
    """Determine semver bump type from commit messages."""
    bump_type = "patch"
    for commit in commits:
        commit_lower = commit.lower()
        if "breaking change" in commit_lower or commit.startswith("!"):
            return "major"
        elif commit.startswith("feat:") or commit.startswith("feat("):
            if bump_type != "major":
                bump_type = "minor"
    return bump_type


def _bump_version_number(version: str, bump_type: str) -> str:
    """Apply version bump to version string."""
    parts = version.split(".")
    if len(parts) != 3:
        return version
    major, minor, patch = int(parts[0]), int(parts[1]), int(parts[2])
    if bump_type == "major":
        major += 1
        minor = 0
        patch = 0
    elif bump_type == "minor":
        minor += 1
        patch = 0
    else:
        patch += 1
    return f"{major}.{minor}.{patch}"


def _is_semver(version: str) -> bool:
    return re.fullmatch(r"\d+\.\d+\.\d+", version) is not None


def _replace_file_pattern(path: Path, pattern: str, replacement: str) -> bool:
    if not path.exists():
        return False
    original = path.read_text(encoding="utf-8")
    updated, count = re.subn(pattern, replacement, original, flags=re.MULTILINE)
    if count == 0 or updated == original:
        return False
    path.write_text(updated, encoding="utf-8")
    return True


def _replace_all(path: Path, replacements: list[tuple[str, str]]) -> bool:
    if not path.exists():
        return False
    original = path.read_text(encoding="utf-8")
    updated = original
    changed = False
    for pattern, replacement in replacements:
        updated, count = re.subn(pattern, replacement, updated, flags=re.MULTILINE)
        if count:
            changed = True
    if changed and updated != original:
        path.write_text(updated, encoding="utf-8")
        return True
    return False


def _apply_version_to_repo_sources(proj_dir: Path, new_version: str) -> list[str]:
    """Update version-bearing files used by app repos."""
    changed: list[str] = []

    if _replace_file_pattern(
        proj_dir / "pyproject.toml",
        r'^version\s*=\s*"\d+\.\d+\.\d+"',
        f'version = "{new_version}"',
    ):
        changed.append("pyproject.toml")

    readme = proj_dir / "README.md"
    if _replace_file_pattern(
        readme,
        r"version-\d+\.\d+\.\d+-blue\.svg",
        f"version-{new_version}-blue.svg",
    ):
        changed.append("README.md")

    for init_file in proj_dir.glob("src/*/__init__.py"):
        if _replace_file_pattern(
            init_file,
            r'^__version__\s*=\s*"\d+\.\d+\.\d+"',
            f'__version__ = "{new_version}"',
        ):
            changed.append(init_file.relative_to(proj_dir).as_posix())

    for spec_file in proj_dir.glob("*.spec"):
        if _replace_all(
            spec_file,
            [
                (
                    r"""(CFBundleShortVersionString['"]?\s*:\s*['"])\d+\.\d+\.\d+(['"])""",
                    rf"\g<1>{new_version}\g<2>",
                ),
                (
                    r"""(CFBundleVersion['"]?\s*:\s*['"])\d+\.\d+\.\d+(['"])""",
                    rf"\g<1>{new_version}\g<2>",
                ),
                (
                    r"""(CFBundleGetInfoString['"]?\s*:\s*['"][^'"]*?)\d+\.\d+\.\d+([^'"]*['"])""",
                    rf"\g<1>{new_version}\g<2>",
                ),
            ],
        ):
            changed.append(spec_file.relative_to(proj_dir).as_posix())

    return sorted(set(changed))


def _detect_managed_app(repo_root: Path) -> str | None:
    for project in MANAGED_APP_PROJECTS:
        if project.lower() == repo_root.name.lower():
            return project
    return None


def _resolve_workspace_from_repo(repo_root: Path) -> Path | None:
    apps_root = repo_root.parent
    if (apps_root / ".razorcore").is_dir():
        return apps_root
    return None


def _latest_version_update_event(workspace: Path, app: str) -> dict | None:
    log_path = workspace / ".razorcore" / "activity.jsonl"
    if not log_path.exists():
        return None
    try:
        lines = log_path.read_text(encoding="utf-8").splitlines()
    except OSError:
        return None

    for raw in reversed(lines):
        if not raw.strip():
            continue
        try:
            payload = json.loads(raw)
        except ValueError:
            continue
        if payload.get("event") != "version_update":
            continue
        if payload.get("app") != app:
            continue
        if isinstance(payload.get("details"), dict):
            return payload
    return None


def _require_clean_repo(repo_root: Path, allow_dirty: bool) -> bool:
    status = subprocess.run(
        ["git", "status", "--porcelain"],
        cwd=repo_root,
        capture_output=True,
        text=True,
        check=False,
    )
    dirty = bool(status.stdout.strip())
    if dirty and not allow_dirty:
        log_error(
            "Refusing version update on a dirty repository. "
            "Re-run with --allow-dirty to override."
        )
        return False
    return True


def _resolve_repo_root(cwd: Path) -> Path | None:
    result = subprocess.run(
        ["git", "rev-parse", "--show-toplevel"],
        cwd=cwd,
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0 or not result.stdout.strip():
        return None
    return Path(result.stdout.strip()).resolve()


def update_version_by_selector(
    cwd: Path,
    selector: str,
    allow_dirty: bool = False,
    allow_repeat: bool = False,
) -> int:
    """Manual semantic version command for app repos: update one|two|three."""
    selector_to_bump = {"one": "major", "two": "minor", "three": "patch"}
    bump_type = selector_to_bump.get(selector.strip().lower())
    if bump_type is None:
        log_error("Invalid update selector. Use one, two, or three.")
        return 1

    repo_root = _resolve_repo_root(cwd)
    if repo_root is None:
        log_error("Current directory is not inside a git repository.")
        return 1

    project = _detect_managed_app(repo_root)
    if project is None:
        log_error(
            f"Current repository is not a managed app: {repo_root.name}. "
            "Run this inside 4Charm, Nexus, or RyuSync."
        )
        return 1

    if not _require_clean_repo(repo_root, allow_dirty=allow_dirty):
        return 1

    current_version = _get_project_version(repo_root)
    if current_version is None:
        log_error("No pyproject.toml project version found.")
        return 1
    if not _is_semver(current_version):
        log_error(f"Invalid semantic version in pyproject.toml: {current_version}")
        return 1

    workspace = _resolve_workspace_from_repo(repo_root)
    if workspace is not None and not allow_repeat:
        latest = _latest_version_update_event(workspace, project)
        if latest is not None:
            details = latest.get("details", {})
            if (
                details.get("selector") == selector.strip().lower()
                and details.get("after") == current_version
            ):
                log_error(
                    "Refusing repeated version update for this app/selector on the current "
                    "version. Re-run with --allow-repeat to override."
                )
                return 1

    new_version = _bump_version_number(current_version, bump_type)
    if not _is_semver(new_version):
        log_error(f"Computed invalid semantic version: {new_version}")
        return 1

    changed_files = _apply_version_to_repo_sources(repo_root, new_version)
    if not changed_files:
        log_warning("No version-bearing files were changed.")
        return 1

    print(f"App: {project}")
    print(f"Update: {selector} ({bump_type})")
    print(f"Version: {current_version} -> {new_version}")
    print("Updated files:")
    for rel in changed_files:
        print(f"- {rel}")

    if workspace is not None:
        append_activity_event(
            workspace,
            event="version_update",
            app=project,
            details={
                "selector": selector.strip().lower(),
                "bump_type": bump_type,
                "before": current_version,
                "after": new_version,
                "files": changed_files,
                "allow_dirty": allow_dirty,
                "allow_repeat": allow_repeat,
            },
        )

    return 0


def _update_version_files(proj_dir: Path, current_version: str, new_version: str):
    """Update version in pyproject.toml, __init__.py, and dmg-config.json."""
    import json

    pyproject = proj_dir / "pyproject.toml"
    content = pyproject.read_text(encoding="utf-8")
    updated = content.replace(
        f'version = "{current_version}"', f'version = "{new_version}"'
    )
    pyproject.write_text(updated, encoding="utf-8")

    for init_file in proj_dir.glob("src/*/__init__.py"):
        init_content = init_file.read_text(encoding="utf-8")
        if "__version__" in init_content:
            updated_init = init_content.replace(
                f'__version__ = "{current_version}"', f'__version__ = "{new_version}"'
            )
            init_file.write_text(updated_init, encoding="utf-8")

    dmg_config = proj_dir / "build" / "dmg-config.json"
    if dmg_config.exists():
        try:
            with open(dmg_config, encoding="utf-8") as f:
                dmg_data = json.load(f)
            dmg_data["version"] = new_version
            with open(dmg_config, "w", encoding="utf-8") as f:
                json.dump(dmg_data, f, indent=2)
        except (OSError, ValueError):
            pass


def _push_changes_for_version(push_cwd: Path) -> int:
    """Push the current branch to remote (version module internal helper)."""
    if not require_git_mutation_allowed("push version bump changes", log_error):
        return 1

    log_info("Pushing to remote...")
    push_result = subprocess.run(
        ["git", "push"], cwd=push_cwd, capture_output=True, text=True, check=False
    )
    if push_result.returncode == 0:
        log_success("Pushed to GitHub")
        return 0
    log_error(f"Push failed: {push_result.stderr}")
    return 1


def _commit_version_bump(
    repo_root: Path, proj_dir: Path, is_nested: bool, project_rel: str, new_version: str
):
    """Commit and push version bump."""
    if not require_git_mutation_allowed("commit version bump changes", log_error):
        return

    if is_nested:
        with tempfile.NamedTemporaryFile(
            prefix="razorcore_index_", delete=False
        ) as tmp:
            temp_index = tmp.name
        env = os.environ.copy()
        env["GIT_INDEX_FILE"] = temp_index
        try:
            subprocess.run(
                ["git", "read-tree", "HEAD"],
                cwd=repo_root,
                env=env,
                capture_output=True,
                text=True,
                check=False,
            )
            subprocess.run(
                ["git", "add", "-A", "--", project_rel],
                cwd=repo_root,
                env=env,
                capture_output=True,
                text=True,
                check=False,
            )
            subprocess.run(
                ["git", "commit", "-m", f"chore: bump version to {new_version}"],
                cwd=repo_root,
                env=env,
                capture_output=True,
                text=True,
                check=False,
            )
            subprocess.run(
                ["git", "reset", "HEAD", "--", project_rel],
                cwd=repo_root,
                capture_output=True,
                text=True,
                check=False,
            )
        finally:
            try:
                os.remove(temp_index)
            except OSError:
                pass
    else:
        subprocess.run(["git", "add", "-A"], cwd=proj_dir, check=False)
        subprocess.run(
            ["git", "commit", "-m", f"chore: bump version to {new_version}"],
            cwd=proj_dir,
            capture_output=True,
            text=True,
            check=False,
        )

    push_cwd = repo_root if is_nested else proj_dir
    _push_changes_for_version(push_cwd)


def _get_project_version(proj_dir: Path) -> str | None:
    """Read current version from pyproject.toml."""
    pyproject = proj_dir / "pyproject.toml"
    if not pyproject.exists():
        return None
    try:
        import tomllib

        with open(pyproject, "rb") as f:
            data = tomllib.load(f)
            return data.get("project", {}).get("version")
    except (OSError, ValueError, ImportError):
        return None


def auto_bump_version(workspace: Path, project: str) -> int:
    """Automatically bump version based on commit messages (silent version).

    Called by save_project after a successful commit.
    Returns 0 on success, 1 if no bump needed or error.
    """
    proj_dir = workspace / project

    if not require_git_mutation_allowed("auto-bump and commit version changes", log_error):
        return 1

    current_version = _get_project_version(proj_dir)
    if not current_version:
        return 1

    repo_root, proj_dir_resolved, is_nested, project_rel = _get_repo_info(proj_dir)
    if not repo_root:
        return 1

    tag_prefix = _tag_prefix(project)
    commits = _get_commit_messages(proj_dir, tag_prefix, is_nested)

    if not commits or commits == [""]:
        return 1

    bump_type = _determine_bump_type(commits)
    new_version = _bump_version_number(current_version, bump_type)

    log_info(f"Version: {current_version} → {new_version} ({bump_type})")

    _update_version_files(proj_dir, current_version, new_version)
    _commit_version_bump(repo_root, proj_dir, is_nested, project_rel, new_version)
    if project == ".razorcore":
        from razorcore.cli.ci_vendor import maybe_refresh_ci_vendor_wheels

        maybe_refresh_ci_vendor_wheels(workspace)
    log_success("Pushed version bump")

    return 0


def bump_version(workspace: Path, project: str, dry_run: bool = False) -> int:
    """Automatically bump version based on commit messages."""
    from razorcore.cli.registry import CYAN, GREEN, NC, resolve_project_name

    project = resolve_project_name(project)

    print(f"\n{'=' * 60}")
    print(f"  Razorcore Version Bump: {project}")
    print(f"{'=' * 60}\n")

    proj_dir = workspace / project
    if not proj_dir.exists():
        log_error(f"Project not found: {project}")
        return 1

    repo_root, proj_dir_resolved, is_nested, project_rel = _get_repo_info(proj_dir)
    if not repo_root:
        log_error("Not inside a git repository")
        return 1

    current_version = _get_project_version(proj_dir)
    if not current_version:
        log_error("No pyproject.toml found")
        return 1

    log_info(f"Current version: {current_version}")

    tag_prefix = _tag_prefix(project)
    commits = _get_commit_messages(proj_dir, tag_prefix, is_nested)

    if not commits or commits == [""]:
        log_info("No new commits since last tag")
        return 0

    log_info(f"Analyzing {len(commits)} commits...")

    bump_type = _determine_bump_type(commits)
    new_version = _bump_version_number(current_version, bump_type)

    print(f"\n  {CYAN}Bump type:{NC} {bump_type}")
    print(f"  {CYAN}New version:{NC} {current_version} → {new_version}")

    if dry_run:
        log_info("Dry run - no changes made")
        return 0

    if not require_git_mutation_allowed("bump and commit version changes", log_error):
        return 1

    _update_version_files(proj_dir, current_version, new_version)
    log_success(f"Updated pyproject.toml to {new_version}")

    _commit_version_bump(repo_root, proj_dir, is_nested, project_rel, new_version)
    if project == ".razorcore":
        from razorcore.cli.ci_vendor import maybe_refresh_ci_vendor_wheels

        maybe_refresh_ci_vendor_wheels(workspace)
    log_success("Version bump complete")

    print(f"\n{'=' * 60}")
    print(f"  {GREEN}✓ Version bumped to {new_version}!{NC}")
    print(f"  {CYAN}Run 'razorcore build {project}' to create a release tag{NC}")
    print(f"{'=' * 60}\n")

    return 0
