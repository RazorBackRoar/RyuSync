"""GitHub release publishing helpers for app DMG artifacts."""

from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

from razorcore.cli.activity import append_activity_event
from razorcore.cli.app_kind import detect_app_kind, read_version_file
from razorcore.cli.build import find_ship_dmg
from razorcore.cli.registry import (
    PUBLIC_APP_PROJECTS,
    log_error,
    log_info,
    log_success,
    log_warning,
    resolve_project_name,
)


def _run(args: list[str], cwd: Path) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        args,
        cwd=cwd,
        check=False,
        capture_output=True,
        text=True,
    )


def _parse_github_repo(remote_url: str) -> str | None:
    remote = remote_url.strip()
    https_match = re.match(r"^https://github\.com/([^/]+)/([^/]+?)(?:\.git)?$", remote)
    if https_match:
        return f"{https_match.group(1)}/{https_match.group(2)}"
    ssh_match = re.match(r"^git@github\.com:([^/]+)/([^/]+?)(?:\.git)?$", remote)
    if ssh_match:
        return f"{ssh_match.group(1)}/{ssh_match.group(2)}"
    return None


def file_sha256(path: Path) -> str:
    hasher = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            hasher.update(chunk)
    return hasher.hexdigest()


def _read_app_version(repo_dir: Path) -> str | None:
    kind = detect_app_kind(repo_dir)
    version, _source = read_version_file(kind, repo_dir)
    if isinstance(version, str) and version.strip():
        return version.strip()
    return None


def _commit_subject(repo_dir: Path) -> str:
    proc = _run(["git", "log", "-1", "--format=%s"], repo_dir)
    return proc.stdout.strip() if proc.returncode == 0 else ""


def _commit_sha(repo_dir: Path) -> str:
    proc = _run(["git", "rev-parse", "HEAD"], repo_dir)
    return proc.stdout.strip() if proc.returncode == 0 else ""


def _release_notes(
    app: str,
    version: str,
    checksum: str,
    subject: str,
    sha: str,
) -> str:
    whats_new = subject or f"Daily package of {app} {version}."
    short = sha[:7] if sha else ""
    commit_line = f" (`{short}`)" if short else ""
    return (
        "## Install\n"
        f"Download `{app}.dmg`, open it, and drag **{app}** into Applications. "
        "First launch: right-click → Open (ad-hoc signed).\n\n"
        "## What's new\n"
        f"{whats_new}{commit_line}\n\n"
        "## SHA-256\n"
        f"`{checksum}`\n"
    )


def _list_release_tags(github_repo: str, repo_dir: Path) -> list[str]:
    proc = _run(
        [
            "gh",
            "release",
            "list",
            "--repo",
            github_repo,
            "--limit",
            "50",
            "--json",
            "tagName",
        ],
        repo_dir,
    )
    if proc.returncode != 0 or not proc.stdout.strip():
        return []
    try:
        payload = json.loads(proc.stdout)
    except json.JSONDecodeError:
        return []
    tags: list[str] = []
    if not isinstance(payload, list):
        return tags
    for item in payload:
        if not isinstance(item, dict):
            continue
        tag = item.get("tagName")
        if isinstance(tag, str) and tag.strip():
            tags.append(tag.strip())
    return tags


def _delete_other_releases(
    github_repo: str,
    keep_tag: str,
    repo_dir: Path,
) -> int:
    """Leave one GitHub Release per app. Delete every other tag."""
    failed = 0
    for tag in _list_release_tags(github_repo, repo_dir):
        if tag == keep_tag:
            continue
        delete = _run(
            [
                "gh",
                "release",
                "delete",
                tag,
                "--repo",
                github_repo,
                "--cleanup-tag",
                "--yes",
            ],
            repo_dir,
        )
        if delete.returncode != 0:
            log_warning(
                delete.stderr.strip() or f"Failed to delete old release {tag}"
            )
            failed += 1
    return failed


def release_exists(github_repo: str, tag: str, repo_dir: Path) -> bool:
    view = _run(["gh", "release", "view", tag, "--repo", github_repo], repo_dir)
    return view.returncode == 0


def publish_release(
    workspace: Path,
    app: str,
    *,
    allow_dirty: bool = False,
    dry_run: bool = False,
    delete_old: bool = False,
) -> int:
    app = resolve_project_name(app)
    if app not in PUBLIC_APP_PROJECTS:
        log_error(f"Unknown product app: {app}")
        return 1

    repo_dir = workspace / app
    if not repo_dir.is_dir():
        log_error(f"App directory not found: {repo_dir}")
        return 1

    status = _run(["git", "status", "--porcelain"], repo_dir)
    if status.returncode != 0:
        log_error("Failed to inspect git status")
        return 1
    if status.stdout.strip() and not allow_dirty:
        log_error("Refusing release on dirty repository. Re-run with --allow-dirty.")
        return 1

    remote_proc = _run(["git", "remote", "get-url", "origin"], repo_dir)
    if remote_proc.returncode != 0 or not remote_proc.stdout.strip():
        log_error("Could not resolve git origin remote")
        return 1
    remote_url = remote_proc.stdout.strip()
    github_repo = _parse_github_repo(remote_url)
    if github_repo is None:
        log_error(f"Origin is not a GitHub remote: {remote_url}")
        return 1

    version = _read_app_version(repo_dir)
    if not version:
        log_error("Could not read project version")
        return 1

    tag = f"v{version}"
    title = f"{app} {version}"
    dmg = find_ship_dmg(repo_dir, app)
    if dmg is None:
        log_error(f"DMG not found for {app} (dist/ or build/Release/)")
        return 1

    checksum = file_sha256(dmg)
    sha = _commit_sha(repo_dir)
    notes = _release_notes(app, version, checksum, _commit_subject(repo_dir), sha)

    print(f"App: {app}")
    print(f"Repo: {github_repo}")
    print(f"Tag: {tag}")
    print(f"Artifact: {dmg}")
    print(f"SHA256: {checksum}")

    if dry_run:
        append_activity_event(
            workspace,
            event="release_publish",
            app=app,
            details={
                "status": "dry_run",
                "repo": github_repo,
                "tag": tag,
                "version": version,
                "artifact": dmg.name,
                "sha256": checksum,
                "head": sha,
            },
        )
        return 0

    view = _run(["gh", "release", "view", tag, "--repo", github_repo], repo_dir)
    if view.returncode == 0:
        upload = _run(
            [
                "gh",
                "release",
                "upload",
                tag,
                str(dmg),
                "--repo",
                github_repo,
                "--clobber",
            ],
            repo_dir,
        )
        if upload.returncode != 0:
            log_error(upload.stderr.strip() or "Failed to upload release artifact")
            return 1
        edit = _run(
            [
                "gh",
                "release",
                "edit",
                tag,
                "--repo",
                github_repo,
                "--title",
                title,
                "--notes",
                notes,
            ],
            repo_dir,
        )
        if edit.returncode != 0:
            log_error(edit.stderr.strip() or "Failed to edit release")
            return 1
        state = "updated"
    else:
        create = _run(
            [
                "gh",
                "release",
                "create",
                tag,
                str(dmg),
                "--repo",
                github_repo,
                "--title",
                title,
                "--notes",
                notes,
            ],
            repo_dir,
        )
        if create.returncode != 0:
            log_error(create.stderr.strip() or "Failed to create release")
            return 1
        state = "created"

    should_delete_old = delete_old or os.environ.get(
        "RAZORCORE_CONFIRM_DELETE_OLD_RELEASES", ""
    ).strip().lower() in ("1", "true", "yes")
    if should_delete_old:
        stale_failures = _delete_other_releases(github_repo, tag, repo_dir)
        if stale_failures:
            log_warning(f"{stale_failures} old release(s) could not be deleted")
    else:
        log_info(
            "Preserving prior releases (pass --delete-old or set "
            "RAZORCORE_CONFIRM_DELETE_OLD_RELEASES=1 to clean up older releases)"
        )

    url_proc = _run(
        [
            "gh",
            "release",
            "view",
            tag,
            "--repo",
            github_repo,
            "--json",
            "url",
            "--jq",
            ".url",
        ],
        repo_dir,
    )
    release_url = url_proc.stdout.strip() if url_proc.returncode == 0 else ""
    if not release_url:
        log_warning("Release published but URL could not be resolved")
    else:
        log_success(f"Release URL: {release_url}")

    append_activity_event(
        workspace,
        event="release_publish",
        app=app,
        details={
            "status": state,
            "repo": github_repo,
            "tag": tag,
            "version": version,
            "artifact": dmg.name,
            "sha256": checksum,
            "head": sha,
            "url": release_url,
        },
    )
    return 0
