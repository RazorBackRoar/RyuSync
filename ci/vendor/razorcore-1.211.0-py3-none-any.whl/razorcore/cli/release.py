"""GitHub release publishing helpers for app DMG artifacts."""

from __future__ import annotations

import hashlib
import re
import subprocess
from pathlib import Path

from razorcore.cli.activity import append_activity_event
from razorcore.cli.registry import (
    MANAGED_APP_PROJECTS,
    log_error,
    log_success,
    log_warning,
)


def _run(args: list[str], cwd: Path) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        args,
        cwd=cwd,
        check=False,
        capture_output=True,
        text=True,
    )


def _parse_github_repo(remote_url: str) -> str | None:
    remote = remote_url.strip()
    https_match = re.match(r"^https://github\.com/([^/]+)/([^/]+?)(?:\.git)?$", remote)
    if https_match:
        return f"{https_match.group(1)}/{https_match.group(2)}"
    ssh_match = re.match(r"^git@github\.com:([^/]+)/([^/]+?)(?:\.git)?$", remote)
    if ssh_match:
        return f"{ssh_match.group(1)}/{ssh_match.group(2)}"
    return None


def _dmg_name(app: str) -> str:
    return f"{app}.dmg"


def _read_version(pyproject: Path) -> str | None:
    if not pyproject.exists():
        return None
    try:
        import tomllib

        with pyproject.open("rb") as f:
            data = tomllib.load(f)
        version = data.get("project", {}).get("version")
        if isinstance(version, str):
            return version.strip()
        return None
    except (OSError, ValueError, ImportError):
        return None


def _sha256(path: Path) -> str:
    hasher = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            hasher.update(chunk)
    return hasher.hexdigest()


def publish_release(
    workspace: Path,
    app: str,
    *,
    allow_dirty: bool = False,
    dry_run: bool = False,
) -> int:
    if app not in MANAGED_APP_PROJECTS:
        log_error(f"Unknown managed app: {app}")
        return 1

    repo_dir = workspace / app
    if not repo_dir.is_dir():
        log_error(f"App directory not found: {repo_dir}")
        return 1

    status = _run(["git", "status", "--porcelain"], repo_dir)
    if status.returncode != 0:
        log_error("Failed to inspect git status")
        return 1
    if status.stdout.strip() and not allow_dirty:
        log_error("Refusing release on dirty repository. Re-run with --allow-dirty.")
        return 1

    remote_proc = _run(["git", "remote", "get-url", "origin"], repo_dir)
    if remote_proc.returncode != 0 or not remote_proc.stdout.strip():
        log_error("Could not resolve git origin remote")
        return 1
    remote_url = remote_proc.stdout.strip()
    github_repo = _parse_github_repo(remote_url)
    if github_repo is None:
        log_error(f"Origin is not a GitHub remote: {remote_url}")
        return 1

    version = _read_version(repo_dir / "pyproject.toml")
    if not version:
        log_error("Could not read project version from pyproject.toml")
        return 1

    tag = f"v{version}"
    title = f"{app} {version}"
    dmg = repo_dir / "dist" / _dmg_name(app)
    if not dmg.exists():
        log_error(f"DMG not found: {dmg}")
        return 1

    checksum = _sha256(dmg)
    notes = (
        f"Version: {version}\n"
        "Platform: macOS Apple Silicon\n"
        f"Artifact: {dmg.name}\n"
        f"SHA256: {checksum}"
    )

    print(f"App: {app}")
    print(f"Repo: {github_repo}")
    print(f"Tag: {tag}")
    print(f"Artifact: {dmg}")
    print(f"SHA256: {checksum}")

    if dry_run:
        append_activity_event(
            workspace,
            event="release_publish",
            app=app,
            details={
                "status": "dry_run",
                "repo": github_repo,
                "tag": tag,
                "version": version,
                "artifact": dmg.name,
                "sha256": checksum,
            },
        )
        return 0

    view = _run(["gh", "release", "view", tag, "--repo", github_repo], repo_dir)
    if view.returncode == 0:
        upload = _run(
            ["gh", "release", "upload", tag, str(dmg), "--repo", github_repo, "--clobber"],
            repo_dir,
        )
        if upload.returncode != 0:
            log_error(upload.stderr.strip() or "Failed to upload release artifact")
            return 1
        edit = _run(
            [
                "gh",
                "release",
                "edit",
                tag,
                "--repo",
                github_repo,
                "--title",
                title,
                "--notes",
                notes,
            ],
            repo_dir,
        )
        if edit.returncode != 0:
            log_error(edit.stderr.strip() or "Failed to edit release")
            return 1
        state = "updated"
    else:
        create = _run(
            [
                "gh",
                "release",
                "create",
                tag,
                str(dmg),
                "--repo",
                github_repo,
                "--title",
                title,
                "--notes",
                notes,
            ],
            repo_dir,
        )
        if create.returncode != 0:
            log_error(create.stderr.strip() or "Failed to create release")
            return 1
        state = "created"

    url_proc = _run(
        ["gh", "release", "view", tag, "--repo", github_repo, "--json", "url", "--jq", ".url"],
        repo_dir,
    )
    release_url = url_proc.stdout.strip() if url_proc.returncode == 0 else ""
    if not release_url:
        log_warning("Release published but URL could not be resolved")
    else:
        log_success(f"Release URL: {release_url}")

    append_activity_event(
        workspace,
        event="release_publish",
        app=app,
        details={
            "status": state,
            "repo": github_repo,
            "tag": tag,
            "version": version,
            "artifact": dmg.name,
            "sha256": checksum,
            "url": release_url,
        },
    )
    return 0
