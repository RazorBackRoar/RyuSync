"""Unified CLI for the RazorBackRoar ecosystem."""

from __future__ import annotations

import argparse
import subprocess
import sys
from collections.abc import Callable
from pathlib import Path

from razorcore import __version__
from razorcore.cli import commands as cmd
from razorcore.cli import workspace_git as wgit


def _resolve_workspace(explicit_workspace: Path | None = None) -> Path:
    """Resolve workspace root, preferring explicit --workspace overrides."""
    if explicit_workspace is not None:
        return explicit_workspace.expanduser().resolve()

    cwd = Path.cwd()
    if (cwd / ".razorcore").exists():
        return cwd

    for parent in cwd.parents:
        if (parent / ".razorcore").exists():
            return parent

    if (cwd / "Apps").exists():
        return cwd / "Apps"

    return cwd


def _build_parser() -> argparse.ArgumentParser:
    """Create the root CLI parser."""
    parser = argparse.ArgumentParser(
        description="RazorBackRoar Core CLI - Central Management Engine"
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"RazorCore v{__version__}",
        help="Show version and exit",
    )
    parser.add_argument(
        "--workspace",
        type=Path,
        help="Explicit workspace root path (defaults to autodetect)",
    )
    parser.add_argument(
        "-v", "--verbose", action="store_true", help="Enable debug logging"
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    save_parser = subparsers.add_parser("save", help="Save a single project")
    save_parser.add_argument("project", nargs="?", default=".razorcore")
    save_parser.add_argument(
        "--commit", action="store_true", help="Commit pending project changes"
    )
    save_parser.add_argument(
        "--push", action="store_true", help="Push after committing changes"
    )

    subparsers.add_parser(
        "save-all", aliases=["pushall"], help="Save and push all managed projects"
    )
    subparsers.add_parser("save-apps", help="Save and push app projects only")
    subparsers.add_parser(
        "save-safe",
        aliases=["pushsafe"],
        help="Save all projects without version bumping or release tags",
    )

    build_parser = subparsers.add_parser(
        "build", aliases=["razorbuild"], help="Build app artifacts"
    )
    build_parser.add_argument(
        "project",
        help="Buildable project name (or alias, e.g. nexus)",
    )

    verify_parser = subparsers.add_parser(
        "verify", help="Run workspace verification checks"
    )
    verify_parser.add_argument("--strict", action="store_true", help="Fail on warnings")

    check_parser = subparsers.add_parser(
        "check",
        help="Run local quality checks (ruff, ty, pytest) for current repo",
    )
    check_parser.add_argument(
        "--verify",
        action="store_true",
        help="Run full structural verification checks",
    )
    check_parser.add_argument("--strict", action="store_true", help="Fail on warnings")

    subparsers.add_parser(
        "check-all",
        aliases=["razorcheckall"],
        help="Run local quality checks across all managed repositories",
    )

    health_parser = subparsers.add_parser(
        "health", aliases=["razorhealth"], help="Run workspace health checks"
    )
    health_parser.add_argument(
        "--no-strict",
        action="store_true",
        help="Allow warnings without failing",
    )

    bootstrap_parser = subparsers.add_parser(
        "new-app-baseline",
        aliases=["razornewapp"],
        help="Bootstrap a new app repo (README badges, LICENSE, GitHub metadata)",
    )
    bootstrap_parser.add_argument("project", help="Project folder name under Apps/")
    bootstrap_parser.add_argument(
        "--module",
        help="Python module name for README run command (auto-derived by default)",
    )
    bootstrap_parser.add_argument(
        "--tagline",
        help="One-line README/GitHub description override",
    )
    bootstrap_parser.add_argument(
        "--dry-run", action="store_true", help="Preview planned baseline changes"
    )
    bootstrap_parser.add_argument(
        "--force-readme",
        action="store_true",
        help="Overwrite README.md with the RazorBackRoar scaffold",
    )
    bootstrap_parser.add_argument(
        "--skip-github",
        action="store_true",
        help="Skip gh repo edit (description, topics, homepage, wiki)",
    )

    github_polish_parser = subparsers.add_parser(
        "github-polish",
        aliases=["razorgithub"],
        help="Apply RazorBackRoar GitHub metadata to an existing app repo",
    )
    github_polish_parser.add_argument("project", help="Project folder name under Apps/")
    github_polish_parser.add_argument(
        "--tagline",
        help="One-line GitHub description override",
    )
    github_polish_parser.add_argument(
        "--dry-run", action="store_true", help="Preview gh commands only"
    )

    baseline_check_parser = subparsers.add_parser(
        "app-baseline-check",
        aliases=["razorappcheck"],
        help="Fail when app CI/README baseline drifts",
    )
    baseline_check_parser.add_argument(
        "projects",
        nargs="*",
        help="Optional project names (defaults to all .razorcore-enabled repos)",
    )

    sync_parser = subparsers.add_parser(
        "sync-configs",
        aliases=["razorconfig"],
        help="Sync shared config files to managed projects",
    )
    sync_parser.add_argument("--dry-run", action="store_true", help="Preview changes")
    sync_parser.add_argument(
        "--with-pyproject",
        action="store_true",
        help="Also sync pyproject.toml to projects",
    )
    sync_parser.add_argument(
        "--with-vscode-tasks",
        action="store_true",
        help="Also sync .vscode/tasks.json to projects",
    )

    repo_status_parser = subparsers.add_parser(
        "repo-status",
        aliases=["razorcheck"],
        help="Read-only status summary for one managed app or all apps.",
    )
    repo_status_parser.add_argument(
        "--app",
        help="Target one app by name (e.g. Nexus).",
    )
    repo_status_parser.add_argument(
        "--all",
        action="store_true",
        help="Force all managed app repos even when inside one app.",
    )

    repo_test_parser = subparsers.add_parser(
        "repo-test",
        aliases=["razortest"],
        help="Run uv/ruff/ty/pytest for one app or all managed apps.",
    )
    repo_test_parser.add_argument("--app", help="Target one app by name.")
    repo_test_parser.add_argument(
        "--all",
        action="store_true",
        help="Run checks across all managed app repos.",
    )

    subparsers.add_parser(
        "repo-test-all",
        aliases=["razortestall"],
        help="Run uv/ruff/ty/pytest across all managed app repos.",
    )

    repo_sync_parser = subparsers.add_parser(
        "repo-sync",
        aliases=["razorsync"],
        help="Sync one managed app repo only (git fetch/pull --rebase --autostash).",
    )
    repo_sync_parser.add_argument("--app", help="Target one app by name.")
    repo_sync_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Preview sync commands without mutating Git.",
    )

    repo_push_parser = subparsers.add_parser(
        "repo-push",
        aliases=["razorpush"],
        help="Push one managed app repo only after strict safety checks.",
    )
    repo_push_parser.add_argument("--app", help="Target one app by name.")
    repo_push_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Preview push commands without mutating Git.",
    )
    repo_push_parser.add_argument(
        "--set-upstream",
        action="store_true",
        help="Allow first push with --set-upstream when no upstream exists.",
    )

    git_sweep_parser = subparsers.add_parser(
        "git-sweep",
        aliases=["razorgit", "razorall"],
        help="Workspace Git sweeper (status/sync/push/sync-push).",
    )
    git_sweep_parser.add_argument(
        "mode",
        nargs="?",
        default="status",
        choices=["status", "sync", "push", "sync-push"],
        help="Operation mode (default: status).",
    )
    git_sweep_parser.add_argument(
        "--changed-only",
        action="store_true",
        help="Operate only on changed repos.",
    )
    git_sweep_parser.add_argument(
        "--all-repos",
        action="store_true",
        help="Disable changed-only filtering for mutating modes.",
    )
    git_sweep_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Preview mutating operations.",
    )
    git_sweep_parser.add_argument(
        "--confirm",
        action="store_true",
        help="Confirm mutating operations.",
    )

    git_status_parser = subparsers.add_parser(
        "git-status-sweep",
        aliases=["razorgitstatus"],
        help="Read-only workspace Git status sweep.",
    )
    git_status_parser.add_argument(
        "--changed-only",
        action="store_true",
        help="Limit output to repos with pending local/remote changes.",
    )
    git_status_parser.add_argument(
        "--all-repos",
        action="store_true",
        help="Reserved for symmetry with other one-word git commands.",
    )
    git_status_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Reserved for symmetry; status is already read-only.",
    )
    git_status_parser.add_argument(
        "--confirm",
        action="store_true",
        help="Reserved for symmetry; status is already read-only.",
    )

    for parser_name, alias_name, parser_help in (
        ("git-sync-sweep", "razorgitsync", "Workspace Git sync sweep."),
        ("git-push-sweep", "razorgitpush", "Workspace Git push sweep."),
        ("git-sync-push-sweep", "razorgitsyncpush", "Workspace Git sync+push sweep."),
        ("git-push-all-sweep", "razorpushall", "One-word alias for workspace push sweep."),
    ):
        mode_parser = subparsers.add_parser(
            parser_name,
            aliases=[alias_name],
            help=parser_help,
        )
        mode_parser.add_argument(
            "--changed-only",
            action="store_true",
            help="Operate only on repos with pending local/remote changes.",
        )
        mode_parser.add_argument(
            "--all-repos",
            action="store_true",
            help="Disable changed-only filtering for mutating modes.",
        )
        mode_parser.add_argument(
            "--dry-run",
            action="store_true",
            help="Preview mutating operations.",
        )
        mode_parser.add_argument(
            "--confirm",
            action="store_true",
            help="Confirm mutating operations.",
        )

    pushapps_parser = subparsers.add_parser(
        "push-apps",
        aliases=["pushapps"],
        help="Deprecated compatibility wrapper for razorgitpush.",
    )
    pushapps_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Preview push operations.",
    )
    pushapps_parser.add_argument(
        "--confirm",
        action="store_true",
        help="Confirm push operations.",
    )

    docs_parser = subparsers.add_parser(
        "sync-docs", aliases=["razoragents"], help="Sync AGENTS and MCP version docs"
    )
    docs_parser.add_argument("--dry-run", action="store_true", help="Preview changes")

    commit_parser = subparsers.add_parser(
        "commit", aliases=["razorcommit"], help="Commit changes in all projects"
    )
    commit_parser.add_argument("message", help="Commit message")

    bump_parser = subparsers.add_parser(
        "bump", aliases=["razorbump"], help="Bump a project's version"
    )
    bump_parser.add_argument("project", help="Project name")
    bump_parser.add_argument("--dry-run", action="store_true", help="Preview bump")

    hooks_parser = subparsers.add_parser(
        "install-hooks", aliases=["razorhooks"], help="Install git hooks"
    )
    hooks_parser.add_argument("projects", nargs="*", help="Optional project names")

    subparsers.add_parser(
        "list", aliases=["razorlist"], help="List managed projects and status"
    )
    subparsers.add_parser("bolt", help="Activate performance optimization agent")
    subparsers.add_parser("journal", help="Open performance journal")

    baseline_parser = subparsers.add_parser(
        "baseline", help="Measure performance baseline"
    )
    baseline_parser.add_argument(
        "--save", action="store_true", help="Save current baseline"
    )
    baseline_parser.add_argument(
        "--compare", action="store_true", help="Compare against saved baseline"
    )

    # Legacy informational subcommands preserved for compatibility.
    nexus_parser = subparsers.add_parser("nexus", help="Manage Nexus app operations")
    nexus_parser.add_argument(
        "--sync", action="store_true", help="Sync Safari bookmarks"
    )

    audit_parser = subparsers.add_parser(
        "audit", help="Run ecosystem consolidation audit"
    )
    audit_parser.add_argument(
        "--fix", action="store_true", help="Auto-fix supported issues"
    )

    subparsers.add_parser("charm", help="Manage 4Charm app operations")

    return parser


def _run_legacy_audit() -> int:
    """Keep legacy audit behavior for compatibility."""
    print("Starting Ecosystem Audit...")
    print("  └─ Scanning for duplicate config files...")
    result = subprocess.run(
        ["find", "Apps", "-name", "pyproject.toml"],
        capture_output=True,
        text=True,
        check=False,
    )
    duplicates = [line for line in result.stdout.strip().split("\n") if line]
    print(f"  └─ Found {len(duplicates)} pyproject.toml files:")
    for duplicate in duplicates:
        print(f"      • {duplicate}")
    return 0


def _sync_docs_bundle(workspace: Path, dry_run: bool) -> int:
    """Run all docs/version sync commands and return aggregate status."""
    statuses = (
        cmd.sync_docs(workspace, dry_run=dry_run),
        cmd.sync_project_agent_versions(workspace, dry_run=dry_run),
        cmd.sync_ssot_versions(workspace, dry_run=dry_run),
    )
    return 1 if any(status != 0 for status in statuses) else 0


def _run_legacy_nexus(sync_requested: bool) -> int:
    """Keep legacy Nexus subcommand behavior for compatibility."""
    print("Executing Nexus operations...")
    if sync_requested:
        print("  └─ Syncing Safari bookmarks...")
    return 0


def _run_legacy_audit_with_fix(auto_fix: bool) -> int:
    """Keep legacy audit behavior for compatibility."""
    status = _run_legacy_audit()
    if auto_fix:
        print("  └─ Auto-fix enabled (not yet implemented)")
    return status


def _build_command_handlers(
    workspace: Path, args: argparse.Namespace
) -> dict[str, Callable[[], int]]:
    """Build command dispatch table."""
    forced_mode_by_command: dict[str, str] = {
        "razorgitstatus": "status",
        "razorgitsync": "sync",
        "razorgitpush": "push",
        "razorgitsyncpush": "sync-push",
        "razorpushall": "push",
        "git-status-sweep": "status",
        "git-sync-sweep": "sync",
        "git-push-sweep": "push",
        "git-sync-push-sweep": "sync-push",
        "git-push-all-sweep": "push",
    }
    effective_mode = forced_mode_by_command.get(
        getattr(args, "command", ""),
        getattr(args, "mode", None),
    )
    changed_only = bool(
        getattr(args, "changed_only", False)
        or (
            effective_mode in {"sync", "push", "sync-push"}
            and not getattr(args, "all_repos", False)
        )
    )

    return {
        "save": lambda: cmd.save_project(
            workspace,
            args.project,
            commit=args.commit,
            push=args.push,
        ),
        "save-all": lambda: cmd.push_all(workspace),
        "pushall": lambda: cmd.push_all(workspace),
        "save-apps": lambda: cmd.save_apps(workspace),
        "save-safe": lambda: cmd.save_all_safe(workspace),
        "pushsafe": lambda: cmd.save_all_safe(workspace),
        "build": lambda: cmd.build_project(workspace, args.project),
        "razorbuild": lambda: cmd.build_project(workspace, args.project),
        "verify": lambda: cmd.verify(workspace, strict=args.strict),
        "check": lambda: cmd.check(
            workspace,
            verify_mode=args.verify,
            strict=args.strict,
        ),
        "repo-status": lambda: wgit.run_razorcheck(
            workspace,
            Path.cwd(),
            app=args.app,
            all_repos=args.all,
        ),
        "razorcheck": lambda: wgit.run_razorcheck(
            workspace,
            Path.cwd(),
            app=args.app,
            all_repos=args.all,
        ),
        "check-all": lambda: (
            1
            if (
                cmd.check_all_repos_quality(workspace) != 0
                or cmd.verify_app_baseline(workspace) != 0
            )
            else 0
        ),
        "razorcheckall": lambda: (
            1
            if (
                cmd.check_all_repos_quality(workspace) != 0
                or cmd.verify_app_baseline(workspace) != 0
            )
            else 0
        ),
        "health": lambda: cmd.verify(workspace, strict=not args.no_strict),
        "razorhealth": lambda: cmd.verify(workspace, strict=not args.no_strict),
        "new-app-baseline": lambda: cmd.bootstrap_app_baseline(
            workspace,
            args.project,
            module_name=args.module,
            dry_run=args.dry_run,
            force_readme=args.force_readme,
            skip_github=args.skip_github,
            tagline=args.tagline,
        ),
        "razornewapp": lambda: cmd.bootstrap_app_baseline(
            workspace,
            args.project,
            module_name=args.module,
            dry_run=args.dry_run,
            force_readme=args.force_readme,
            skip_github=args.skip_github,
            tagline=args.tagline,
        ),
        "github-polish": lambda: cmd.polish_github_repo(
            workspace,
            args.project,
            tagline=args.tagline,
            dry_run=args.dry_run,
        ),
        "razorgithub": lambda: cmd.polish_github_repo(
            workspace,
            args.project,
            tagline=args.tagline,
            dry_run=args.dry_run,
        ),
        "app-baseline-check": lambda: cmd.verify_app_baseline(
            workspace, projects=args.projects or None
        ),
        "razorappcheck": lambda: cmd.verify_app_baseline(
            workspace, projects=args.projects or None
        ),
        "sync-configs": lambda: cmd.sync_configs(
            workspace,
            dry_run=args.dry_run,
            include_pyproject=args.with_pyproject,
            include_vscode_tasks=args.with_vscode_tasks,
        ),
        "repo-sync": lambda: wgit.run_razorsync(
            workspace,
            Path.cwd(),
            app=args.app,
            dry_run=args.dry_run,
        ),
        "razorsync": lambda: wgit.run_razorsync(
            workspace,
            Path.cwd(),
            app=args.app,
            dry_run=args.dry_run,
        ),
        "repo-test": lambda: wgit.run_razortest(
            workspace,
            Path.cwd(),
            app=args.app,
            all_repos=args.all,
        ),
        "repo-test-all": lambda: wgit.run_razortest(
            workspace,
            Path.cwd(),
            app=None,
            all_repos=True,
        ),
        "razortest": lambda: wgit.run_razortest(
            workspace,
            Path.cwd(),
            app=args.app,
            all_repos=args.all,
        ),
        "razortestall": lambda: wgit.run_razortest(
            workspace,
            Path.cwd(),
            app=None,
            all_repos=True,
        ),
        "repo-push": lambda: wgit.run_razorpush(
            workspace,
            Path.cwd(),
            app=args.app,
            dry_run=args.dry_run,
            set_upstream=args.set_upstream,
        ),
        "razorpush": lambda: wgit.run_razorpush(
            workspace,
            Path.cwd(),
            app=args.app,
            dry_run=args.dry_run,
            set_upstream=args.set_upstream,
        ),
        "git-sweep": lambda: wgit.run_razorgit(
            workspace,
            mode=effective_mode or "status",
            changed_only=changed_only,
            dry_run=args.dry_run,
            confirm=args.confirm,
        ),
        "razorgit": lambda: wgit.run_razorgit(
            workspace,
            mode=effective_mode or "status",
            changed_only=changed_only,
            dry_run=args.dry_run,
            confirm=args.confirm,
        ),
        "razorall": lambda: wgit.run_razorgit(
            workspace,
            mode=effective_mode or "status",
            changed_only=changed_only,
            dry_run=args.dry_run,
            confirm=args.confirm,
        ),
        "git-status-sweep": lambda: wgit.run_razorgit(
            workspace,
            mode=effective_mode or "status",
            changed_only=changed_only,
            dry_run=args.dry_run,
            confirm=args.confirm,
        ),
        "git-sync-sweep": lambda: wgit.run_razorgit(
            workspace,
            mode=effective_mode or "sync",
            changed_only=changed_only,
            dry_run=args.dry_run,
            confirm=args.confirm,
        ),
        "git-push-sweep": lambda: wgit.run_razorgit(
            workspace,
            mode=effective_mode or "push",
            changed_only=changed_only,
            dry_run=args.dry_run,
            confirm=args.confirm,
        ),
        "git-sync-push-sweep": lambda: wgit.run_razorgit(
            workspace,
            mode=effective_mode or "sync-push",
            changed_only=changed_only,
            dry_run=args.dry_run,
            confirm=args.confirm,
        ),
        "git-push-all-sweep": lambda: wgit.run_razorgit(
            workspace,
            mode=effective_mode or "push",
            changed_only=changed_only,
            dry_run=args.dry_run,
            confirm=args.confirm,
        ),
        "razorgitstatus": lambda: wgit.run_razorgit(
            workspace,
            mode=effective_mode or "status",
            changed_only=changed_only,
            dry_run=args.dry_run,
            confirm=args.confirm,
        ),
        "razorgitsync": lambda: wgit.run_razorgit(
            workspace,
            mode=effective_mode or "sync",
            changed_only=changed_only,
            dry_run=args.dry_run,
            confirm=args.confirm,
        ),
        "razorgitpush": lambda: wgit.run_razorgit(
            workspace,
            mode=effective_mode or "push",
            changed_only=changed_only,
            dry_run=args.dry_run,
            confirm=args.confirm,
        ),
        "razorgitsyncpush": lambda: wgit.run_razorgit(
            workspace,
            mode=effective_mode or "sync-push",
            changed_only=changed_only,
            dry_run=args.dry_run,
            confirm=args.confirm,
        ),
        "razorpushall": lambda: wgit.run_razorgit(
            workspace,
            mode=effective_mode or "push",
            changed_only=changed_only,
            dry_run=args.dry_run,
            confirm=args.confirm,
        ),
        "push-apps": lambda: wgit.run_legacy_pushapps(
            workspace,
            dry_run=args.dry_run,
            confirm=args.confirm,
        ),
        "pushapps": lambda: wgit.run_legacy_pushapps(
            workspace,
            dry_run=args.dry_run,
            confirm=args.confirm,
        ),
        "razorconfig": lambda: cmd.sync_configs(
            workspace,
            dry_run=args.dry_run,
            include_pyproject=args.with_pyproject,
            include_vscode_tasks=args.with_vscode_tasks,
        ),
        "sync-docs": lambda: _sync_docs_bundle(workspace, args.dry_run),
        "razoragents": lambda: _sync_docs_bundle(workspace, args.dry_run),
        "commit": lambda: cmd.commit_all(workspace, args.message),
        "razorcommit": lambda: cmd.commit_all(workspace, args.message),
        "bump": lambda: cmd.bump_version(workspace, args.project, dry_run=args.dry_run),
        "razorbump": lambda: cmd.bump_version(
            workspace, args.project, dry_run=args.dry_run
        ),
        "install-hooks": lambda: cmd.install_hooks(
            workspace, projects=args.projects or None
        ),
        "razorhooks": lambda: cmd.install_hooks(
            workspace, projects=args.projects or None
        ),
        "list": lambda: cmd.list_projects(workspace),
        "razorlist": lambda: cmd.list_projects(workspace),
        "bolt": lambda: cmd.bolt_command(workspace),
        "journal": lambda: cmd.journal_command(workspace),
        "baseline": lambda: cmd.baseline_command(
            workspace, save=args.save, compare=args.compare
        ),
        "nexus": lambda: _run_legacy_nexus(args.sync),
        "audit": lambda: _run_legacy_audit_with_fix(args.fix),
        "charm": lambda: print("Executing 4Charm operations...") or 0,
    }


def main(argv: list[str] | None = None) -> int:
    """Main entry point for all razorcore subcommands."""
    parser = _build_parser()
    args = parser.parse_args(argv)

    if args.verbose:
        print("[DEBUG] Verbose mode enabled")

    workspace = _resolve_workspace(args.workspace)
    handlers = _build_command_handlers(workspace, args)
    handler = handlers.get(args.command)
    if handler is not None:
        return handler()

    parser.print_help()
    return 1


if __name__ == "__main__":
    sys.exit(main())
