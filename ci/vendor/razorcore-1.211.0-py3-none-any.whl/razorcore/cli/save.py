"""Razorcore CLI Save — save/commit/push workflow and all remaining functions."""

from __future__ import annotations

import importlib
import json
import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path

from razorcore.cli.build import _run_project_preflight as _run_project_push_preflight
from razorcore.cli.git_safety import pr_creation_allowed, require_git_mutation_allowed
from razorcore.cli.registry import (
    BUILDABLE_PROJECTS,
    CYAN,
    GREEN,
    MANAGED_PROJECTS,
    NC,
    RED,
    YELLOW,
    _project_has_changes,
    get_projects,
    log_error,
    log_info,
    log_success,
    log_warning,
    resolve_project_name,
    resolve_project_path,
)
from razorcore.cli.sync import (
    _sync_version_docs,
    sync_configs,
    sync_docs,
    sync_project_agent_versions,
    sync_ssot_versions,
)
from razorcore.cli.version import auto_bump_version


# ---------------------------------------------------------------------------
# Helpers: git context
# ---------------------------------------------------------------------------


def _resolve_git_context(proj_dir: Path) -> tuple[Path, bool, str] | None:
    """Resolve git repository context for a managed project path."""
    git_root_result = subprocess.run(
        ["git", "rev-parse", "--show-toplevel"],
        cwd=proj_dir,
        capture_output=True,
        text=True,
        check=False,
    )
    if git_root_result.returncode != 0 or not git_root_result.stdout.strip():
        log_error("Not inside a git repository")
        return None

    repo_root = Path(git_root_result.stdout.strip()).resolve()
    proj_dir_resolved = proj_dir.resolve()

    if repo_root == proj_dir_resolved:
        return repo_root, False, ""

    try:
        project_rel = proj_dir_resolved.relative_to(repo_root).as_posix()
    except ValueError:
        log_error("Project is not inside the detected git repository")
        return None

    return repo_root, True, project_rel


# ---------------------------------------------------------------------------
# Helpers: markdown autoformat
# ---------------------------------------------------------------------------


def _run_markdown_autoformatter(workspace: Path, proj_dir: Path, project: str) -> None:
    """Run markdown formatting before save flows when appropriate."""
    if project.startswith("."):
        return

    try:
        from .formatter import format_markdown_files

        log_info("Running auto-formatter on markdown files...")
        format_markdown_files(workspace, proj_dir)
    except Exception as e:
        log_warning(f"Auto-formatter failed (non-critical): {e}")


# ---------------------------------------------------------------------------
# Helpers: git status / changes
# ---------------------------------------------------------------------------


def _get_project_status(
    repo_root: Path,
    proj_dir: Path,
    is_nested_project: bool,
    project_rel: str,
) -> subprocess.CompletedProcess[str]:
    """Fetch git status output for either whole repo or nested project path."""
    if is_nested_project:
        return subprocess.run(
            [
                "git",
                "status",
                "--porcelain",
                "--untracked-files=all",
                "--",
                project_rel,
            ],
            cwd=repo_root,
            capture_output=True,
            text=True,
            check=False,
        )

    return subprocess.run(
        ["git", "status", "--porcelain"],
        cwd=proj_dir,
        capture_output=True,
        text=True,
        check=False,
    )


def _warn_outside_changes(repo_root: Path, project_rel: str) -> int:
    """Warn when a nested repo has unrelated staged/unstaged changes."""
    all_status_result = subprocess.run(
        ["git", "status", "--porcelain", "--untracked-files=all"],
        cwd=repo_root,
        capture_output=True,
        text=True,
        check=False,
    )
    if all_status_result.returncode != 0:
        stderr = all_status_result.stderr.strip()
        if stderr:
            log_error(f"Failed to read git status: {stderr}")
        else:
            log_error("Failed to read git status")
        return 1

    outside_changes: list[str] = []
    all_lines = (
        all_status_result.stdout.strip().split("\n")
        if all_status_result.stdout.strip()
        else []
    )
    for line in all_lines:
        if not line.strip():
            continue
        path_part = line[3:].strip()
        candidates = [path_part]
        if "->" in path_part:
            candidates = [p.strip() for p in path_part.split("->", 1)]

        in_project = all(
            p == project_rel or p.startswith(f"{project_rel}/") for p in candidates
        )
        if not in_project:
            outside_changes.append(path_part)

    if outside_changes:
        log_warning(
            f"Other changes detected outside {project_rel}. "
            f"Razorcore will commit only {project_rel} and leave the rest uncommitted."
        )
        for item in outside_changes[:10]:
            log_warning(f"Outside: {item}")

    return 0


def _categorize_changed_files(
    status_output: str,
) -> tuple[list[str], list[str], list[str]]:
    """Split git status output into added, modified, and deleted file paths."""
    added: list[str] = []
    modified: list[str] = []
    deleted: list[str] = []

    for change in status_output.splitlines():
        if not change.strip():
            continue

        status = change[:2].strip()
        filename = change[3:].strip()
        file_path = Path(filename)
        if file_path.name == "GENTS.md":
            filename = str(file_path.with_name("AGENTS.md"))

        if "A" in status or "?" in status:
            added.append(filename)
        elif "D" in status:
            deleted.append(filename)
        else:
            modified.append(filename)

    return added, modified, deleted


def _infer_commit_type(
    all_files: list[str], repo_root: Path, proj_dir: Path, is_nested_project: bool
) -> str:
    """Infer conventional commit type from file names and diffs."""
    for file_path in all_files:
        lower_path = file_path.lower()
        if "test" in lower_path:
            return "test"
        if "fix" in lower_path or "bug" in lower_path:
            return "fix"
        if any(token in lower_path for token in ["feature", "new", "add"]):
            return "feat"
        if not file_path.endswith(".py"):
            continue

        diff_cwd = repo_root if is_nested_project else proj_dir
        diff_result = subprocess.run(
            ["git", "diff", "--", file_path],
            cwd=diff_cwd,
            capture_output=True,
            text=True,
            check=False,
        )
        diff_text = diff_result.stdout.lower()
        if "def " in diff_text and "+" in diff_text:
            return "feat"
        if "fix" in diff_text or "bug" in diff_text:
            return "fix"

    return "chore"


def _infer_scope(all_files: list[str]) -> str:
    """Infer commit scope from changed file paths."""
    scope_parts = set()
    for file_path in all_files:
        parts = file_path.split("/")
        if len(parts) <= 1:
            continue
        scope_parts.add(
            parts[-2] if parts[-1].endswith(".py") else parts[-1].split(".")[0]
        )

    if len(scope_parts) == 1:
        return f"({next(iter(scope_parts))})"
    return ""


def _build_commit_message(
    status_output: str,
    repo_root: Path,
    proj_dir: Path,
    is_nested_project: bool,
) -> str:
    """Generate a conventional commit message from git status output."""
    added, modified, deleted = _categorize_changed_files(status_output)
    all_files = added + modified + deleted

    commit_type = _infer_commit_type(all_files, repo_root, proj_dir, is_nested_project)
    scope = _infer_scope(all_files)

    if added and not modified and not deleted:
        desc = f"add {', '.join(file_path.split('/')[-1] for file_path in added[:3])}"
        if len(added) > 3:
            desc += f" and {len(added) - 3} more"
    elif deleted and not added and not modified:
        desc = (
            f"remove {', '.join(file_path.split('/')[-1] for file_path in deleted[:3])}"
        )
    elif modified:
        desc = f"update {', '.join(file_path.split('/')[-1] for file_path in modified[:3])}"
        if len(modified) > 3:
            desc += f" and {len(modified) - 3} more"
    else:
        desc = f"update {len(all_files)} files"

    return f"{commit_type}{scope}: {desc}"


def _commit_project_changes(
    repo_root: Path,
    proj_dir: Path,
    is_nested_project: bool,
    project_rel: str,
    commit_msg: str,
) -> subprocess.CompletedProcess[str]:
    """Commit changes for a project, isolating index in nested repos."""
    if not require_git_mutation_allowed("commit project changes", log_error):
        return subprocess.CompletedProcess(
            args=["git", "commit"],
            returncode=1,
            stdout="",
            stderr="Git mutation not approved",
        )

    if not is_nested_project:
        subprocess.run(["git", "add", "-A"], cwd=proj_dir, check=False)
        return subprocess.run(
            ["git", "commit", "-m", commit_msg],
            cwd=proj_dir,
            capture_output=True,
            text=True,
            check=False,
        )

    with tempfile.NamedTemporaryFile(prefix="razorcore_index_", delete=False) as tmp:
        temp_index = tmp.name

    env = os.environ.copy()
    env["GIT_INDEX_FILE"] = temp_index

    try:
        subprocess.run(
            ["git", "read-tree", "HEAD"],
            cwd=repo_root,
            env=env,
            capture_output=True,
            text=True,
            check=False,
        )
        subprocess.run(
            ["git", "add", "-A", "--", project_rel],
            cwd=repo_root,
            env=env,
            capture_output=True,
            text=True,
            check=False,
        )
        commit_result = subprocess.run(
            ["git", "commit", "-m", commit_msg],
            cwd=repo_root,
            env=env,
            capture_output=True,
            text=True,
            check=False,
        )

        if commit_result.returncode == 0:
            subprocess.run(
                ["git", "reset", "HEAD", "--", project_rel],
                cwd=repo_root,
                capture_output=True,
                text=True,
                check=False,
            )
        return commit_result
    finally:
        try:
            os.remove(temp_index)
        except OSError:
            pass


# ---------------------------------------------------------------------------
# Helpers: push / PR creation
# ---------------------------------------------------------------------------


def _current_branch_name(repo_cwd: Path) -> str | None:
    """Return the current git branch name, if available."""
    branch_result = subprocess.run(
        ["git", "rev-parse", "--abbrev-ref", "HEAD"],
        cwd=repo_cwd,
        capture_output=True,
        text=True,
        check=False,
    )
    if branch_result.returncode != 0:
        log_warning("Unable to detect current branch; skipping PR creation")
        return None

    branch = branch_result.stdout.strip()
    if not branch or branch == "HEAD":
        log_warning("Detached HEAD detected; skipping PR creation")
        return None
    return branch


def _origin_default_branch(repo_cwd: Path) -> str:
    """Detect default branch from origin HEAD, falling back to main."""
    default_result = subprocess.run(
        ["git", "symbolic-ref", "--quiet", "--short", "refs/remotes/origin/HEAD"],
        cwd=repo_cwd,
        capture_output=True,
        text=True,
        check=False,
    )
    if default_result.returncode == 0:
        remote_head = default_result.stdout.strip()
        if remote_head.startswith("origin/"):
            return remote_head.split("/", 1)[1]
    return "main"


def _find_open_pr_url(repo_cwd: Path, branch: str) -> str | None:
    """Return open PR URL for branch if one exists."""
    pr_list_result = subprocess.run(
        [
            "gh",
            "pr",
            "list",
            "--head",
            branch,
            "--state",
            "open",
            "--json",
            "url",
            "--limit",
            "1",
        ],
        cwd=repo_cwd,
        capture_output=True,
        text=True,
        check=False,
    )
    if pr_list_result.returncode != 0:
        return None

    try:
        rows = json.loads(pr_list_result.stdout or "[]")
    except json.JSONDecodeError:
        return None

    if not rows:
        return None
    url = rows[0].get("url")
    if isinstance(url, str) and url.strip():
        return url.strip()
    return None


def _maybe_create_pull_request(repo_cwd: Path) -> None:
    """Create a PR for the current branch when one is not already open."""
    if not pr_creation_allowed():
        log_info(
            "Skipping automatic PR creation; set RAZORCORE_ALLOW_PR_CREATION=1 "
            "only when a pull request was explicitly requested."
        )
        return

    branch = _current_branch_name(repo_cwd)
    if branch is None:
        return

    base_branch = _origin_default_branch(repo_cwd)
    if branch == base_branch:
        log_info(f"Current branch '{branch}' is the base branch; skipping PR creation")
        return

    if shutil.which("gh") is None:
        log_warning("GitHub CLI (gh) not found; skipping PR creation")
        return

    auth_result = subprocess.run(
        ["gh", "auth", "status"],
        cwd=repo_cwd,
        capture_output=True,
        text=True,
        check=False,
    )
    if auth_result.returncode != 0:
        log_warning("gh is not authenticated; skipping PR creation")
        return

    existing_url = _find_open_pr_url(repo_cwd, branch)
    if existing_url:
        log_info(f"Pull request already open: {existing_url}")
        return

    log_info(f"Creating pull request for '{branch}' -> '{base_branch}'...")
    create_result = subprocess.run(
        ["gh", "pr", "create", "--fill", "--base", base_branch, "--head", branch],
        cwd=repo_cwd,
        capture_output=True,
        text=True,
        check=False,
    )

    if create_result.returncode == 0:
        output_lines = [line.strip() for line in create_result.stdout.splitlines()]
        pr_url = next((line for line in output_lines if line.startswith("http")), "")
        if pr_url:
            log_success(f"Opened pull request: {pr_url}")
        else:
            log_success("Opened pull request")
        return

    error_text = (create_result.stderr or create_result.stdout).strip()
    if "already exists" in error_text.lower():
        existing_url = _find_open_pr_url(repo_cwd, branch)
        if existing_url:
            log_info(f"Pull request already open: {existing_url}")
            return
    if error_text:
        log_warning(f"Automatic PR creation skipped: {error_text}")
    else:
        log_warning("Automatic PR creation skipped")


def _push_changes(push_cwd: Path) -> int:
    """Push the current branch to remote."""
    if not require_git_mutation_allowed("push project changes", log_error):
        return 1

    log_info("Pushing to remote...")
    push_result = subprocess.run(
        ["git", "push"], cwd=push_cwd, capture_output=True, text=True, check=False
    )
    if push_result.returncode == 0:
        log_success("Pushed to GitHub")
        _maybe_create_pull_request(push_cwd)
        return 0

    log_error(f"Push failed: {push_result.stderr}")
    return 1


# ---------------------------------------------------------------------------
# Helpers: save workflow internal
# ---------------------------------------------------------------------------


def _maybe_auto_save_razorcore(workspace: Path) -> int:
    razorcore_dir = workspace / ".razorcore"
    if not razorcore_dir.exists():
        return 0

    if not _project_has_changes(razorcore_dir):
        return 0

    log_info("Auto-saving .razorcore...")
    return save_project(
        workspace, ".razorcore", auto_bump=True, auto_save_razorcore=False
    )


def _handle_no_changes(
    workspace: Path,
    project: str,
    auto_save_razorcore: bool,
) -> int:
    """Handle save flow when no project changes are present."""
    log_info("No changes to commit")
    if auto_save_razorcore and project != ".razorcore":
        razorcore_save_result = _maybe_auto_save_razorcore(workspace)
        if razorcore_save_result != 0:
            log_warning("Auto-save .razorcore failed")
            return 1

    _sync_version_docs(workspace)
    return 0


def _run_save_loop(
    workspace: Path,
    project_names: list[str],
    *,
    auto_bump: bool | None = None,
    auto_save_razorcore: bool | None = None,
    run_preflight: bool | None = None,
    commit: bool | None = None,
    push: bool | None = None,
    tag: bool | None = None,
    print_project_header: bool = False,
) -> tuple[int, int, int]:
    """Save changed projects and return (saved, skipped, errors)."""
    saved = 0
    skipped = 0
    errors = 0

    for name in project_names:
        proj_dir = workspace / name
        if not proj_dir.exists():
            continue

        if not _project_has_changes(proj_dir):
            skipped += 1
            continue

        if print_project_header:
            print(f"\n{CYAN}[{name}]{NC}")

        save_kwargs = {}
        if auto_bump is not None:
            save_kwargs["auto_bump"] = auto_bump
        if auto_save_razorcore is not None:
            save_kwargs["auto_save_razorcore"] = auto_save_razorcore
        if run_preflight is not None:
            save_kwargs["run_preflight"] = run_preflight
        if commit is not None:
            save_kwargs["commit"] = commit
        if push is not None:
            save_kwargs["push"] = push
        if tag is not None:
            save_kwargs["tag"] = tag

        result = save_project(workspace, name, **save_kwargs)
        if result == 0:
            saved += 1
        else:
            errors += 1

    return saved, skipped, errors


def _print_save_summary(saved: int, skipped: int, errors: int) -> None:
    """Print the standard save workflow summary block."""
    print(f"\n{'=' * 60}")
    print(f"  Total Saved: {saved}, Skipped: {skipped}, Errors: {errors}")
    if errors == 0:
        print(f"  {GREEN}✓ All automation completed successfully{NC}")
    else:
        print(f"  {RED}✗ Completed with {errors} errors{NC}")
    print(f"{'=' * 60}\n")


# ---------------------------------------------------------------------------
# Public: save_project
# ---------------------------------------------------------------------------


def save_project(
    workspace: Path,
    project: str,
    auto_bump: bool = True,
    auto_save_razorcore: bool = True,
    run_preflight: bool = False,
    run_autoformat: bool = True,
    commit: bool = False,
    push: bool = False,
    tag: bool = False,
) -> int:
    """Save workflow with explicit commit/push/tag controls."""
    project = resolve_project_name(project)

    print(f"\n{'=' * 60}")
    print(f"  Razorcore Save: {project}")
    print(f"{'=' * 60}\n")

    if push and not commit:
        log_error("Refusing push without commit; use --commit with --push")
        return 1
    if tag and not commit:
        log_error("Refusing tag without commit; use --commit with --tag")
        return 1

    if not require_git_mutation_allowed("save project changes", log_error):
        return 1

    proj_dir = resolve_project_path(workspace, project)
    if not proj_dir.exists():
        log_error(f"Project not found: {project}")
        return 1

    git_context = _resolve_git_context(proj_dir)
    if git_context is None:
        return 1
    repo_root, is_nested_project, project_rel = git_context

    if run_autoformat and commit:
        _run_markdown_autoformatter(workspace, proj_dir, project)
    elif run_autoformat and not commit:
        log_info("Skipping markdown auto-formatter (enable with --commit)")

    if run_preflight:
        preflight_result = _run_project_push_preflight(proj_dir, project)
        if preflight_result != 0:
            return preflight_result

    status_result = _get_project_status(
        repo_root, proj_dir, is_nested_project, project_rel
    )
    if status_result.returncode != 0:
        stderr = status_result.stderr.strip()
        if stderr:
            log_error(f"Failed to read git status: {stderr}")
        else:
            log_error("Failed to read git status")
        return 1

    if not status_result.stdout.strip():
        return _handle_no_changes(workspace, project, auto_save_razorcore)

    if is_nested_project and _warn_outside_changes(repo_root, project_rel) != 0:
        return 1

    commit_msg = _build_commit_message(
        status_result.stdout, repo_root, proj_dir, is_nested_project
    )
    log_info(f"Generated message: {commit_msg}")

    if not commit:
        log_info(f"Dry-run: would commit with message: {commit_msg}")
        if push:
            log_info("Dry-run: would push current branch")
        if tag:
            log_info("Dry-run: would auto-bump version and tag")
        _sync_version_docs(workspace)
        print(f"\n{'=' * 60}")
        print(f"  {GREEN}✓ Dry run complete (no commit/push/tag executed){NC}")
        print(f"{'=' * 60}\n")
        return 0

    commit_result = _commit_project_changes(
        repo_root, proj_dir, is_nested_project, project_rel, commit_msg
    )
    if commit_result.returncode != 0:
        log_error(f"Commit failed: {commit_result.stderr}")
        return 1
    log_success(f"Committed: {commit_msg}")

    push_cwd = repo_root if is_nested_project else proj_dir
    if push:
        if _push_changes(push_cwd) != 0:
            return 1
    else:
        log_info("Skipping push (enable with --push)")

    pyproject = proj_dir / "pyproject.toml"
    if tag and auto_bump and pyproject.exists():
        log_info("Auto-bumping version...")
        bump_result = auto_bump_version(workspace, project)
        if bump_result == 0:
            log_info("Syncing AGENTS.md...")
            sync_docs(workspace)
            sync_project_agent_versions(workspace)
            log_info("Syncing SSOT versions...")
            sync_ssot_versions(workspace)
        else:
            log_warning("Version bump skipped (no commits since last tag or error)")
    elif auto_bump and not tag and pyproject.exists():
        log_info("Skipping auto-tag/version bump (enable with --tag)")

    if auto_save_razorcore and project != ".razorcore":
        razorcore_save_result = _maybe_auto_save_razorcore(workspace)
        if razorcore_save_result != 0:
            log_warning("Auto-save .razorcore failed")

    log_info("Syncing SSOT versions...")
    _sync_version_docs(workspace)

    print(f"\n{'=' * 60}")
    if push:
        print(f"  {GREEN}✓ Saved and pushed!{NC}")
    else:
        print(f"  {GREEN}✓ Saved (commit only){NC}")
    print(f"{'=' * 60}\n")

    return 0


# ---------------------------------------------------------------------------
# Public: aggregate save commands
# ---------------------------------------------------------------------------


def save_apps(
    workspace: Path,
    *,
    commit: bool = False,
    push: bool = False,
    tag: bool = False,
) -> int:
    """Save only buildable Python app projects, excluding .razorcore."""
    print(f"\n{'=' * 60}")
    print("  Razorcore Save Apps")
    print(f"{'=' * 60}\n")

    if push and not commit:
        log_error("Refusing push without commit; use --commit with --push")
        return 1
    if tag and not commit:
        log_error("Refusing tag without commit; use --commit with --tag")
        return 1
    if (commit or push or tag) and not require_git_mutation_allowed(
        "save app projects", log_error
    ):
        return 1

    log_info("Step 1: Syncing shared configurations...")
    sync_configs(workspace, projects=BUILDABLE_PROJECTS, include_pyproject=False)

    saved, skipped, errors = _run_save_loop(
        workspace,
        BUILDABLE_PROJECTS,
        auto_save_razorcore=False,
        run_preflight=True,
        commit=commit,
        push=push,
        tag=tag,
        print_project_header=True,
    )

    log_info("Step 3: Final documentation sync (AGENTS.md)...")
    sync_docs(workspace)
    sync_project_agent_versions(workspace)
    log_info("Step 4: Final SSOT sync (CONTEXT.md)...")
    sync_ssot_versions(workspace)

    if prune_worktrees(workspace) != 0:
        errors += 1

    _print_save_summary(saved, skipped, errors)

    return 1 if errors > 0 else 0


def save_all_safe(
    workspace: Path,
    *,
    commit: bool = False,
    push: bool = False,
) -> int:
    print(f"\n{'=' * 60}")
    print("  Razorcore Safe Save (No Bump/Tags/Docs)")
    print(f"{'=' * 60}\n")

    if push and not commit:
        log_error("Refusing push without commit; use --commit with --push")
        return 1
    if (commit or push) and not require_git_mutation_allowed(
        "save all projects", log_error
    ):
        return 1

    order = [".razorcore"] + [p for p in MANAGED_PROJECTS if p != ".razorcore"]

    saved, skipped, errors = _run_save_loop(
        workspace,
        order,
        auto_bump=False,
        auto_save_razorcore=False,
        commit=commit,
        push=push,
        tag=False,
    )

    if saved == 0 and errors == 0:
        log_info("No changes to commit")
        sync_project_agent_versions(workspace)
        sync_ssot_versions(workspace)
        return 0

    log_info("Syncing SSOT versions...")
    sync_project_agent_versions(workspace)
    sync_ssot_versions(workspace)

    _print_save_summary(saved, skipped, errors)

    return 1 if errors > 0 else 0


def save_all(
    workspace: Path,
    *,
    commit: bool = False,
    push: bool = False,
    tag: bool = False,
) -> int:
    """Save all projects with changes, including automated config and doc syncing."""
    print(f"\n{'=' * 60}")
    print("  Razorcore Save All (Automated Workflow)")
    print(f"{'=' * 60}\n")

    if push and not commit:
        log_error("Refusing push without commit; use --commit with --push")
        return 1
    if tag and not commit:
        log_error("Refusing tag without commit; use --commit with --tag")
        return 1
    if (commit or push or tag) and not require_git_mutation_allowed(
        "save and push all projects", log_error
    ):
        return 1

    # 1. Sync configs first to ensure projects have latest shared settings
    log_info("Step 1: Syncing shared configurations...")
    sync_configs(workspace, include_pyproject=False)

    # 2. Save .razorcore first if it has changes, as it might affect others
    order = [".razorcore"] + [p for p in MANAGED_PROJECTS if p != ".razorcore"]
    saved, skipped, errors = _run_save_loop(
        workspace,
        order,
        auto_save_razorcore=False,
        run_preflight=True,
        commit=commit,
        push=push,
        tag=tag,
        print_project_header=True,
    )

    # 3. Final documentation sync
    log_info("Step 3: Final documentation sync (AGENTS.md)...")
    sync_docs(workspace)
    sync_project_agent_versions(workspace)
    log_info("Step 4: Final SSOT sync (CONTEXT.md)...")
    sync_ssot_versions(workspace)

    if not commit:
        log_info("Dry-run mode: skipped doc-sync cleanup commits/pushes")

    if prune_worktrees(workspace) != 0:
        errors += 1

    _print_save_summary(saved, skipped, errors)

    return 1 if errors > 0 else 0


def push_all(workspace: Path) -> int:
    """Save all projects with changes (commit, push, bump, docs)."""
    return save_all(workspace, commit=True, push=True, tag=False)


def razormax(workspace: Path) -> int:
    """Maximum workflow: sync configs, save all projects, verify health.

    Runs in order:
    1. syncall - Sync shared configs to all 8 locations
    2. pushall - Save and push all changed projects
    3. razorhealth - Verify workspace health
    """
    from razorcore.cli.sync import sync_all
    from razorcore.cli.verify import verify

    print(f"\n{'=' * 60}")
    print("  🚀 RAZORMAX - Full Workspace Workflow")
    print(f"{'=' * 60}\n")

    if not require_git_mutation_allowed("run razormax save/push workflow", log_error):
        return 1

    errors = 0

    # Step 1: Sync configs
    log_info("Step 1/3: Syncing shared configs...")
    result = sync_all(workspace)
    if result != 0:
        log_error("Config sync failed")
        errors += 1

    # Step 2: Push all changes
    log_info("Step 2/3: Saving and pushing all projects...")
    result = push_all(workspace)
    if result != 0:
        log_error("Push all failed")
        errors += 1

    # Step 3: Health check
    log_info("Step 3/3: Running health verification...")
    result = verify(workspace, strict=True)
    if result != 0:
        log_error("Health check failed")
        errors += 1

    # Summary
    print(f"\n{'=' * 60}")
    if errors == 0:
        print(f"  {GREEN}✓ RAZORMAX COMPLETE - All systems go!{NC}")
    else:
        print(f"  {RED}✗ RAZORMAX COMPLETED WITH {errors} ERRORS{NC}")
    print(f"{'=' * 60}\n")

    return 1 if errors > 0 else 0


# ---------------------------------------------------------------------------
# Public: commit / list / hooks / prune / test
# ---------------------------------------------------------------------------


def commit_all(
    workspace: Path, message: str, projects: list[str] | None = None, push: bool = False
) -> int:
    """Commit changes across all projects."""
    print(f"\n{'=' * 60}")
    print("  Razorcore Multi-Project Commit")
    print(f"{'=' * 60}\n")

    if not require_git_mutation_allowed("commit across projects", log_error):
        return 1

    project_dirs = get_projects(workspace, projects)

    if not project_dirs:
        log_error("No projects found")
        return 1

    errors = 0
    committed = 0
    skipped = 0

    for proj_dir in project_dirs:
        proj_name = proj_dir.name
        print(f"\n{CYAN}[{proj_name}]{NC}")

        # Check if git repo
        if not (proj_dir / ".git").exists():
            log_info("Not a git repository, skipping")
            skipped += 1
            continue

        # Check for changes
        if not _project_has_changes(proj_dir):
            log_info("No changes to commit")
            skipped += 1
            continue

        # Stage all changes
        subprocess.run(["git", "add", "-A"], cwd=proj_dir, check=True)

        # Commit
        commit_result = subprocess.run(
            ["git", "commit", "-m", message],
            cwd=proj_dir,
            capture_output=True,
            text=True,
            check=False,
        )

        if commit_result.returncode == 0:
            log_success(f"Committed: {message[:50]}...")
            committed += 1

            # Push if requested
            if push:
                if _push_changes(proj_dir) == 0:
                    log_success("Pushed to remote")
                else:
                    errors += 1
        else:
            if "nothing to commit" in commit_result.stdout:
                log_info("Nothing to commit")
                skipped += 1
            else:
                log_error(f"Commit failed: {commit_result.stderr}")
                errors += 1

    # Summary
    print(f"\n{'=' * 60}")
    print(f"  Committed: {committed}, Skipped: {skipped}, Errors: {errors}")
    if errors == 0:
        print(f"  {GREEN}✓ All commits successful{NC}")
    else:
        print(f"  {RED}✗ Some commits failed{NC}")
    print(f"{'=' * 60}\n")

    return 1 if errors > 0 else 0


def list_projects(workspace: Path) -> int:
    """List all managed projects and their status."""
    print(f"\n{'=' * 60}")
    print("  Razorcore Managed Projects")
    print(f"  Workspace: {workspace}")
    print(f"{'=' * 60}\n")

    for name in MANAGED_PROJECTS:
        proj_dir = workspace / name

        if not proj_dir.exists():
            print(f"  {RED}✗{NC} {name} (not found)")
            continue

        # Get version if available
        version = "n/a"
        pyproject = proj_dir / "pyproject.toml"
        if pyproject.exists():
            try:
                import tomllib

                with open(pyproject, "rb") as f:
                    data = tomllib.load(f)
                    version = data.get("project", {}).get("version", "n/a")
            except (OSError, ValueError, ImportError):
                pass

        # Check git status
        git_status = ""
        if (proj_dir / ".git").exists():
            result = subprocess.run(
                ["git", "status", "--porcelain"],
                cwd=proj_dir,
                capture_output=True,
                text=True,
                check=False,
            )
            if result.stdout.strip():
                git_status = f" {YELLOW}(uncommitted changes){NC}"
            else:
                git_status = f" {GREEN}(clean){NC}"

        print(f"  {GREEN}✓{NC} {name} v{version}{git_status}")

    print()
    return 0


def install_hooks(workspace: Path, projects: list[str] | None = None) -> int:
    """Install git hooks to auto-save .razorcore after commits."""
    print(f"\n{'=' * 60}")
    print("  Razorcore Install Hooks")
    print(f"{'=' * 60}\n")

    if not require_git_mutation_allowed(
        "install Git hooks that auto-save .razorcore", log_error
    ):
        return 1

    candidates: list[Path] = [workspace]
    candidates.extend(get_projects(workspace, projects))

    installed = 0
    skipped = 0
    errors = 0

    hook_snippet = """RAZORCORE_HOOK_AUTOSAVE=1

if [ "${RAZORCORE_AUTO_PUSH:-}" != "1" ]; then
  exit 0
fi
export RAZORCORE_ALLOW_GIT_MUTATION=1

repo_root="$(git rev-parse --show-toplevel 2>/dev/null || true)"
if [ -z "$repo_root" ]; then
  exit 0
fi

workspace="$repo_root"
if [ ! -d "$workspace/.razorcore" ]; then
  parent="$(dirname "$repo_root")"
  if [ -d "$parent/.razorcore" ]; then
    workspace="$parent"
  else
    exit 0
  fi
fi

if ! git -C "$workspace/.razorcore" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  exit 0
fi

hash="$(printf %s "$workspace" | shasum | awk '{print $1}' | cut -c1-12)"
lockdir="${TMPDIR:-/tmp}/razorcore_hook_${hash}.lock"
if ! mkdir "$lockdir" 2>/dev/null; then
  exit 0
fi
trap 'rmdir "$lockdir" 2>/dev/null || true' EXIT

if [ -z "$(git -C "$workspace/.razorcore" status --porcelain 2>/dev/null || true)" ]; then
  exit 0
fi

PYTHONPATH="$workspace/.razorcore/src${PYTHONPATH:+:$PYTHONPATH}" \\
  python3 -m razorcore.cli.main --workspace "$workspace" \\
    save .razorcore --commit --push || true
"""

    hook_body = f"""#!/bin/sh
set -eu

{hook_snippet}
"""

    for repo in candidates:
        git_dir = repo / ".git"
        if not git_dir.exists():
            continue

        hooks_result = subprocess.run(
            ["git", "rev-parse", "--git-path", "hooks"],
            cwd=repo,
            capture_output=True,
            text=True,
            check=False,
        )
        if hooks_result.returncode != 0 or not hooks_result.stdout.strip():
            log_error(f"Failed to resolve hooks path for {repo}")
            errors += 1
            continue

        hooks_dir = Path(hooks_result.stdout.strip())
        if not hooks_dir.is_absolute():
            hooks_dir = repo / hooks_dir
        hook_path = hooks_dir / "post-commit"
        hooks_dir.mkdir(parents=True, exist_ok=True)

        if hook_path.exists():
            try:
                existing = hook_path.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                existing = ""

            if "RAZORCORE_HOOK_AUTOSAVE=1" in existing:
                prefix = existing.partition("RAZORCORE_HOOK_AUTOSAVE=1")[0].rstrip()
                updated = f"{prefix}\n\n{hook_snippet}" if prefix else hook_body
                if updated == existing:
                    log_info(f"Hook already installed: {repo}")
                    skipped += 1
                    continue
                try:
                    hook_path.write_text(updated, encoding="utf-8")
                    hook_path.chmod(0o755)
                    log_success(f"Updated Razorcore hook: {repo}")
                    installed += 1
                except OSError as e:
                    log_error(f"Failed to update hook in {repo}: {e}")
                    errors += 1
                continue

            if (
                "python3 -m razorcore.cli.main" in existing
                and "save .razorcore" in existing
            ):
                log_warning(f"Legacy Razorcore hook exists, skipping: {hook_path}")
                skipped += 1
                continue

            if "git lfs post-commit" in existing:
                try:
                    hook_path.write_text(
                        existing.rstrip() + "\n\n" + hook_snippet,
                        encoding="utf-8",
                    )
                    hook_path.chmod(0o755)
                    log_success(f"Appended Razorcore to existing hook: {repo}")
                    installed += 1
                except OSError as e:
                    log_error(f"Failed to update hook in {repo}: {e}")
                    errors += 1
                continue

            log_warning(f"Hook exists, skipping: {hook_path}")
            skipped += 1
            continue

        try:
            hook_path.write_text(hook_body, encoding="utf-8")
            hook_path.chmod(0o755)
            log_success(f"Installed post-commit hook: {repo}")
            installed += 1
        except OSError as e:
            log_error(f"Failed to install hook in {repo}: {e}")
            errors += 1

    print(f"\n{'=' * 60}")
    print(f"  Installed: {installed}, Skipped: {skipped}, Errors: {errors}")
    print(f"{'=' * 60}\n")

    return 1 if errors > 0 else 0


def test_all(
    workspace: Path,
    projects: list[str] | None = None,
    pytest_args: list[str] | None = None,
) -> int:
    """Run pytest across all managed projects that have a tests/ directory."""
    print(f"\n{'=' * 60}")
    print("  Razorcore Test Runner")
    print(f"{'=' * 60}\n")

    project_dirs = get_projects(workspace, projects)
    if not project_dirs:
        log_error("No projects found to test")
        return 1

    extra_args = pytest_args or ["-q"]
    passed = 0
    failed = 0
    skipped = 0

    for proj_dir in project_dirs:
        proj_name = proj_dir.name
        tests_dir = proj_dir / "tests"
        if not tests_dir.is_dir():
            print(f"\n{CYAN}[{proj_name}]{NC}")
            log_info("No tests/ directory — skipping")
            skipped += 1
            continue

        print(f"\n{CYAN}[{proj_name}]{NC}")
        result = subprocess.run(
            ["uv", "run", "pytest", "tests/", *extra_args],
            cwd=proj_dir,
            check=False,
        )
        if result.returncode == 0:
            log_success(f"{proj_name}: tests passed")
            passed += 1
        else:
            log_error(f"{proj_name}: tests failed")
            failed += 1

    print(f"\n{'=' * 60}")
    summary = f"passed={passed}, failed={failed}, skipped={skipped}"
    if failed == 0:
        print(f"  {GREEN}✓ All tests passed ({summary}){NC}")
    else:
        print(f"  {RED}✗ {failed} project(s) failed ({summary}){NC}")
    print(f"{'=' * 60}\n")

    return 1 if failed > 0 else 0


# ---------------------------------------------------------------------------
# Public: prune
# ---------------------------------------------------------------------------


def _detect_default_branch(proj_dir: Path, has_remote: bool) -> str | None:
    """Return the default branch name for a git repo, or None if it cannot be determined."""
    if has_remote:
        result = subprocess.run(
            ["git", "symbolic-ref", "refs/remotes/origin/HEAD"],
            cwd=proj_dir,
            capture_output=True,
            text=True,
            check=False,
        )
        if result.returncode == 0:
            # "refs/remotes/origin/main" → "main"
            return result.stdout.strip().split("/")[-1]

    # Fall back: check which of main / master exists locally
    for candidate in ("main", "master"):
        result = subprocess.run(
            ["git", "rev-parse", "--verify", candidate],
            cwd=proj_dir,
            capture_output=True,
            text=True,
            check=False,
        )
        if result.returncode == 0:
            return candidate

    return None


def prune_all(workspace: Path, dry_run: bool = True) -> int:
    """Prune stale remote-tracking refs and delete merged local branches."""
    print(f"\n{'=' * 60}")
    print("  Razorcore Prune All")
    print(f"{'=' * 60}\n")

    if not dry_run and not require_git_mutation_allowed(
        "prune remote refs and delete local branches", log_error
    ):
        return 1
    if dry_run:
        log_info("Dry-run mode enabled; no refs or branches will be deleted")

    errors = 0

    for name in MANAGED_PROJECTS:
        proj_dir = workspace / name
        if not proj_dir.exists():
            continue
        if not (proj_dir / ".git").exists():
            log_warning(f"Skipping {name} — not a git repository")
            continue

        print(f"\n{CYAN}[{name}]{NC}")

        # Check whether this repo has a remote
        remote_result = subprocess.run(
            ["git", "remote"],
            cwd=proj_dir,
            capture_output=True,
            text=True,
            check=False,
        )
        has_remote = bool(remote_result.stdout.strip())

        if has_remote:
            if dry_run:
                log_info("Dry-run: would run git fetch --prune origin")
            else:
                fetch_result = subprocess.run(
                    ["git", "fetch", "--prune", "origin"],
                    cwd=proj_dir,
                    capture_output=True,
                    text=True,
                    check=False,
                )
                if fetch_result.returncode == 0:
                    log_success("Pruned remote-tracking refs")
                else:
                    log_warning(f"fetch --prune failed: {fetch_result.stderr.strip()}")
                    errors += 1
                    continue
        else:
            log_info("No remote — skipping fetch")

        # Detect default branch dynamically (main, master, or origin/HEAD)
        default_branch = _detect_default_branch(proj_dir, has_remote)
        if default_branch is None:
            log_warning("Could not determine default branch — skipping branch cleanup")
            continue

        # Delete local branches already merged into the default branch
        branch_result = subprocess.run(
            ["git", "branch", "--merged", default_branch],
            cwd=proj_dir,
            capture_output=True,
            text=True,
            check=False,
        )
        if branch_result.returncode != 0:
            log_warning(
                f"Could not list merged branches: {branch_result.stderr.strip()}"
            )
            continue

        merged = [
            b.strip()
            for b in branch_result.stdout.splitlines()
            if b.strip()
            and not b.strip().startswith("*")
            and b.strip() not in {"main", "master", default_branch}
        ]

        if not merged:
            log_info("No merged local branches to delete")
        else:
            for branch in merged:
                if dry_run:
                    log_info(f"Dry-run: would delete local branch: {branch}")
                else:
                    del_result = subprocess.run(
                        ["git", "branch", "-d", branch],
                        cwd=proj_dir,
                        capture_output=True,
                        text=True,
                        check=False,
                    )
                    if del_result.returncode == 0:
                        log_success(f"Deleted local branch: {branch}")
                    else:
                        log_warning(
                            f"Could not delete {branch}: {del_result.stderr.strip()}"
                        )
                        errors += 1

    print(f"\n{'=' * 60}")
    if errors == 0 and dry_run:
        print(f"  {GREEN}✓ Prune dry run complete{NC}")
    elif errors == 0:
        print(f"  {GREEN}✓ Prune complete{NC}")
    else:
        print(f"  {RED}✗ Completed with {errors} errors{NC}")
    print(f"{'=' * 60}\n")

    return 1 if errors > 0 else 0


def _remove_project_egg_info_dirs(
    proj_dir: Path, project: str, dry_run: bool
) -> tuple[int, int]:
    removed = 0
    errors = 0

    for search_root in (proj_dir, proj_dir / "src"):
        if not search_root.exists():
            continue

        for egg_info_dir in sorted(search_root.glob("*.egg-info")):
            if not egg_info_dir.is_dir():
                continue

            rel_path = f"{project}/{egg_info_dir.relative_to(proj_dir)}"
            if dry_run:
                log_info(f"Dry-run: would remove egg-info: {rel_path}")
                removed += 1
                continue

            try:
                shutil.rmtree(egg_info_dir)
                log_success(f"Removed egg-info: {rel_path}")
                removed += 1
            except OSError as exc:
                log_warning(f"Could not remove egg-info {rel_path}: {exc}")
                errors += 1

    return removed, errors


def prune_worktrees(workspace: Path, dry_run: bool = True) -> int:
    """Remove detached git worktrees created by Codex or Devin."""
    print(f"\n{'=' * 60}")
    print("  Razorcore Prune Worktrees")
    print(f"{'=' * 60}\n")

    if not dry_run and not require_git_mutation_allowed(
        "remove git worktrees", log_error
    ):
        return 1
    if dry_run:
        log_info("Dry-run mode enabled; no worktrees will be removed")

    errors = 0
    removed = 0
    egg_info_removed = 0

    for name in MANAGED_PROJECTS:
        proj_dir = workspace / name
        if not proj_dir.exists():
            continue
        if not (proj_dir / ".git").exists():
            continue

        # List worktrees
        wt_result = subprocess.run(
            ["git", "worktree", "list"],
            cwd=proj_dir,
            capture_output=True,
            text=True,
            check=False,
        )
        if wt_result.returncode != 0:
            log_warning(
                f"Could not list worktrees in {name}: {wt_result.stderr.strip()}"
            )
            continue

        lines = wt_result.stdout.splitlines()
        for line in lines:
            if not line.strip():
                continue
            parts = line.split()
            wt_path = parts[0]

            # Skip the main worktree which matches the proj_dir
            if Path(wt_path).resolve() == proj_dir.resolve():
                continue

            # Check if it's a codex/devin or detached worktree
            if (
                ".codex/worktrees" in wt_path
                or ".devin/worktrees" in wt_path
                or "(detached HEAD)" in line
            ):
                if dry_run:
                    log_info(f"Dry-run: would remove worktree {wt_path} from {name}")
                    removed += 1
                else:
                    log_info(f"Removing worktree {wt_path} from {name}...")
                    rm_result = subprocess.run(
                        ["git", "worktree", "remove", wt_path],
                        cwd=proj_dir,
                        capture_output=True,
                        text=True,
                        check=False,
                    )
                    if rm_result.returncode == 0:
                        log_success(f"Removed worktree: {wt_path}")
                        removed += 1
                    else:
                        log_warning(
                            f"Could not remove worktree {wt_path}: {rm_result.stderr.strip()}"
                        )
                        errors += 1

        project_egg_info_removed, egg_info_errors = _remove_project_egg_info_dirs(
            proj_dir, name, dry_run=dry_run
        )
        egg_info_removed += project_egg_info_removed
        errors += egg_info_errors

    # Also clean up the codex/devin directories if they are empty
    home_dir = Path.home()
    for tool_dir in [".codex/worktrees", ".devin/worktrees"]:
        worktrees_dir = home_dir / tool_dir
        if worktrees_dir.exists():
            try:
                # Remove empty directories inside worktrees_dir
                for d in worktrees_dir.iterdir():
                    if d.is_dir() and not any(d.iterdir()):
                        d.rmdir()
            except OSError as e:
                log_warning(f"Failed to clean up {worktrees_dir}: {e}")

    print(f"\n{'=' * 60}")
    if errors == 0 and dry_run:
        print(
            f"  {GREEN}✓ Prune dry run complete ({removed} worktrees, {egg_info_removed} egg-info candidates){NC}"
        )
    elif errors == 0:
        print(
            f"  {GREEN}✓ Prune complete ({removed} worktrees, {egg_info_removed} egg-info removed){NC}"
        )
    else:
        print(
            f"  {RED}✗ Completed with {errors} errors ({removed} worktrees, {egg_info_removed} egg-info removed){NC}"
        )
    print(f"{'=' * 60}\n")

    return 1 if errors > 0 else 0


# ---------------------------------------------------------------------------
# Public: bolt/journal/baseline
# ---------------------------------------------------------------------------


def bolt_command(workspace: Path) -> int:
    """Activate the Bolt performance optimization agent."""
    try:
        pyperclip = importlib.import_module("pyperclip")
    except ImportError:
        pyperclip = None

    bolt_md = workspace / ".razorcore" / "bolt.md"
    if not bolt_md.exists():
        log_error("Bolt agent documentation not found (.razorcore/bolt.md)")
        return 1

    print(f"\n{'=' * 60}")
    print("  Bolt Professional Performance Optimizer ⚡")
    print(f"{'=' * 60}\n")

    activation_cmd = f"@{bolt_md}"

    if pyperclip:
        try:
            pyperclip.copy(activation_cmd)
            copied_msg = f"  {GREEN}✓ Copied to clipboard! Just paste in chat.{NC}"
        except Exception:
            copied_msg = f"  {YELLOW}(Clipboard copy failed){NC}"
    else:
        copied_msg = f"  {YELLOW}(Install 'pyperclip' for auto-copy){NC}"

    print("To activate Bolt, use the following prompt with your AI assistant:\n")
    print(f"{CYAN}{activation_cmd}{NC}")
    print(copied_msg + "\n")

    return 0


def journal_command(workspace: Path) -> int:
    """Open the Bolt performance journal."""
    journal_file = workspace / ".razorcore" / "bolt" / "journal.md"
    if not journal_file.exists():
        log_warning(f"Journal not found at {journal_file}")
        log_info("Creating new journal...")
        journal_file.parent.mkdir(parents=True, exist_ok=True)
        journal_file.write_text(
            "# Bolt Performance Journal ⚡\n\n## Active Optimization Targets\n\n- [ ] Target 1\n",
            encoding="utf-8",
        )

    # Try to open with appropriate editor for the platform
    editors = []

    # Check for VS Code first
    if shutil.which("code"):
        editors.append("code")

    # Add platform-specific editors
    if os.name == "posix":
        if os.uname().sysname == "Darwin":  # macOS
            editors.extend(["open", "mate", "vim"])
        else:  # Linux
            editors.extend(["xdg-open", "vim", "nano"])
    else:  # Windows
        editors.extend(["start", "notepad"])

    # Add fallback from EDITOR env var
    editor_env = os.environ.get("EDITOR")
    if editor_env and editor_env not in editors:
        editors.append(editor_env)

    for editor in editors:
        try:
            if editor == "open":
                # macOS open command
                subprocess.run(["open", str(journal_file)], check=True)
            elif editor == "start":
                # Windows start command (start is a cmd builtin; no shell=True
                # with a list — that misroutes the path. Empty "" is the title arg.)
                subprocess.run(
                    ["cmd", "/c", "start", "", str(journal_file)], check=True
                )
            elif editor == "xdg-open":
                # Linux xdg-open
                subprocess.run(["xdg-open", str(journal_file)], check=True)
            else:
                # Direct editor invocation
                subprocess.run([editor, str(journal_file)], check=True)
            log_success(f"Opened journal with {editor}")
            return 0
        except (FileNotFoundError, subprocess.CalledProcessError, Exception):
            continue

    log_error(f"Could not open journal. Please open {journal_file} manually.")
    return 1


def _measure_import_time(proj_dir: Path, module_name: str) -> float | None:
    """Measure the import time for a Python module."""
    # Map project names to module names
    module_map = {
        "4Charm": "four_charm",
        "Nexus": "nexus",
        "RyuSync": "ryusync",
        "razorcore": "razorcore",
    }

    actual_module = module_map.get(module_name, module_name.lower().replace("-", "_"))
    src_dir = proj_dir / "src"

    if not src_dir.exists():
        return None

    # Use Python's importtime to measure
    try:
        result = subprocess.run(
            [
                "python3",
                "-X",
                "importtime",
                "-c",
                f"import {actual_module}",
            ],
            cwd=src_dir,
            capture_output=True,
            text=True,
            timeout=30,
            env={**os.environ, "PYTHONPATH": str(src_dir)},
            check=False,
        )

        # Parse the import time from stderr
        # Format: "import time: self [us] | cumulative | package"
        for line in result.stderr.strip().split("\n"):
            if actual_module in line and "import time:" in line:
                parts = line.split("|")
                if len(parts) >= 2:
                    try:
                        cumulative = int(parts[1].strip())
                        return cumulative / 1_000_000  # Convert to seconds
                    except ValueError:
                        pass
    except (subprocess.TimeoutExpired, OSError):
        pass

    return None


def _get_directory_size(path: Path) -> int:
    """Get total size of a directory in bytes."""
    total = 0
    try:
        for entry in path.rglob("*"):
            if entry.is_file():
                total += entry.stat().st_size
    except OSError:
        pass
    return total


def _measure_all_projects(workspace: Path) -> dict:
    """Measure performance metrics for all managed projects."""
    metrics = {}

    for name in BUILDABLE_PROJECTS:
        proj_dir = workspace / name
        if not proj_dir.exists():
            continue

        proj_metrics = {}

        # Measure import time for main module
        import_time = _measure_import_time(proj_dir, name)
        if import_time is not None:
            proj_metrics["import_time_ms"] = round(import_time * 1000, 2)

        # Measure bundle size if exists
        dist_dir = proj_dir / "build" / "dist"
        app_path = dist_dir / f"{name}.app"
        if app_path.exists():
            size = _get_directory_size(app_path)
            proj_metrics["bundle_size_mb"] = round(size / (1024 * 1024), 2)

        # Check DMG size
        dmg_path = dist_dir / f"{name}.dmg"
        if dmg_path.exists():
            proj_metrics["dmg_size_mb"] = round(
                dmg_path.stat().st_size / (1024 * 1024), 2
            )

        if proj_metrics:
            metrics[name] = proj_metrics

    # Measure razorcore import time
    razorcore_time = _measure_import_time(workspace / ".razorcore", "razorcore")
    if razorcore_time is not None:
        metrics[".razorcore"] = {"import_time_ms": round(razorcore_time * 1000, 2)}

    return metrics


def _display_metrics(metrics: dict) -> None:
    """Display metrics in a formatted table."""
    print(f"{'Project':<15} {'Import (ms)':<15} {'Bundle (MB)':<15} {'DMG (MB)':<12}")
    print("-" * 57)

    for name, data in sorted(metrics.items()):
        import_time = data.get("import_time_ms", "-")
        bundle_size = data.get("bundle_size_mb", "-")
        dmg_size = data.get("dmg_size_mb", "-")
        print(
            f"{name:<15} {str(import_time):<15} {str(bundle_size):<15} {str(dmg_size):<12}"
        )


def _compare_metrics(old: dict, new: dict) -> None:
    """Compare old and new metrics, highlighting changes."""

    def format_change(old_val: float, new_val: float) -> str:
        if old_val == 0:
            return f"{new_val}"
        change = ((new_val - old_val) / old_val) * 100
        if change > 0:
            return f"{new_val} ({RED}+{change:.1f}%{NC})"
        elif change < 0:
            return f"{new_val} ({GREEN}{change:.1f}%{NC})"
        else:
            return f"{new_val} (no change)"

    print(f"{'Project':<15} {'Metric':<20} {'Change'}")
    print("-" * 60)

    all_projects = set(old.keys()) | set(new.keys())
    for name in sorted(all_projects):
        old_data = old.get(name, {})
        new_data = new.get(name, {})

        all_metrics = set(old_data.keys()) | set(new_data.keys())
        for metric in sorted(all_metrics):
            old_val = old_data.get(metric, 0)
            new_val = new_data.get(metric, 0)
            if old_val != new_val:
                change_str = format_change(old_val, new_val)
                print(f"{name:<15} {metric:<20} {change_str}")


def baseline_command(workspace: Path, save: bool = False, compare: bool = False) -> int:
    """Measure or compare performance baselines for all projects."""
    import time

    print(f"\n{'=' * 60}")
    print("  📊 Performance Baseline")
    print(f"{'=' * 60}\n")

    baseline_file = workspace / ".razorcore" / "bolt" / "baseline.json"

    # Measure current metrics
    log_info("Measuring performance metrics...")
    metrics = _measure_all_projects(workspace)

    if not metrics:
        log_error("No projects found to measure")
        return 1

    # Display current metrics
    _display_metrics(metrics)

    if save:
        # Save baseline
        baseline_file.parent.mkdir(parents=True, exist_ok=True)
        baseline_data = {
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "metrics": metrics,
        }
        baseline_file.write_text(json.dumps(baseline_data, indent=2), encoding="utf-8")
        log_success(f"Baseline saved to: {baseline_file}")

    if compare and baseline_file.exists():
        # Compare with saved baseline
        try:
            saved = json.loads(baseline_file.read_text(encoding="utf-8"))
            print(f"\n{CYAN}Comparison with baseline from {saved['timestamp']}:{NC}\n")
            _compare_metrics(saved["metrics"], metrics)
        except (json.JSONDecodeError, KeyError) as e:
            log_error(f"Could not read baseline: {e}")
            return 1
    elif compare:
        log_warning("No baseline saved. Run 'razorcore baseline --save' first.")

    print(f"\n{'=' * 60}")
    print(f"  {GREEN}✓ Baseline complete{NC}")
    print(f"{'=' * 60}\n")

    return 0


# ---------------------------------------------------------------------------
# Public: misc remaining
# ---------------------------------------------------------------------------


def razorstatus(workspace: Path) -> int:
    """Show the current status of all managed repositories."""
    return list_projects(workspace)


def format_markdown(
    workspace: Path, file_path: Path | None = None, dry_run: bool = False
) -> int:
    """Format markdown files in the workspace."""
    from .formatter import format_markdown_files

    return format_markdown_files(workspace, file_path, dry_run)


def _format_size(size_bytes: int | float) -> str:
    """Format bytes in human readable format."""
    for unit in ["B", "KB", "MB", "GB"]:
        if size_bytes < 1024.0:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024.0
    return f"{size_bytes:.1f} TB"


_SECRET_NAME_MARKERS = ("TOKEN", "KEY", "SECRET", "PASSWORD", "AUTH", "PAT")
_PROVIDER_MARKERS = (
    "GITHUB",
    "GH_",
    "MCP",
    "OPENAI",
    "CONTEXT7",
    "ANTHROPIC",
    "GOOGLE",
    "VERCEL",
    "GITLAB",
    "BITBUCKET",
)


def _looks_sensitive_name(name: str) -> bool:
    """Return True when an env-var style name looks credential-related."""
    upper = name.upper()
    if upper in {"PATH", "PYTHONPATH", "HOME", "SHELL", "PWD", "TERM"}:
        return False
    return bool(
        re.search(
            r"(?:^|_)(TOKEN|KEY|SECRET|PASSWORD|AUTH|PAT)(?:_|$)",
            upper,
        )
    )


def _has_provider_marker(name: str) -> bool:
    """Return True when name matches common auth provider prefixes."""
    upper = name.upper()
    return any(marker in upper for marker in _PROVIDER_MARKERS)


def _mask_secret(value: str) -> str:
    """Mask sensitive values while preserving enough context for validation."""
    if not value:
        return "-"
    if len(value) <= 8:
        return "*" * len(value)
    return f"{value[:4]}...{value[-4:]}"


def _parse_zshrc_credentials(zshrc_path: Path) -> dict[str, str]:
    """Extract credential-like env assignments from ~/.zshrc."""
    if not zshrc_path.exists():
        return {}

    assignment_re = re.compile(
        r"^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$"
    )
    credentials: dict[str, str] = {}

    for raw_line in zshrc_path.read_text(
        encoding="utf-8", errors="replace"
    ).splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        match = assignment_re.match(raw_line)
        if not match:
            continue

        name, value = match.group(1), match.group(2).strip()
        if not _looks_sensitive_name(name):
            continue

        if len(value) >= 2 and value[0] in {'"', "'"} and value[-1] == value[0]:
            value = value[1:-1]
        credentials[name] = value

    return credentials


def _extract_mcp_env_refs(mcp_config_path: Path) -> set[str]:
    """Extract referenced credential env vars from MCP config placeholders."""
    if not mcp_config_path.exists():
        return set()

    text = mcp_config_path.read_text(encoding="utf-8", errors="replace")
    refs = {
        name
        for name in re.findall(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}", text)
        if _looks_sensitive_name(name)
    }

    try:
        config = json.loads(text)
    except json.JSONDecodeError:
        return refs

    def _walk(node: object) -> None:
        if isinstance(node, dict):
            for key, value in node.items():
                if isinstance(key, str) and _looks_sensitive_name(key):
                    refs.add(key)
                _walk(value)
        elif isinstance(node, list):
            for item in node:
                _walk(item)

    _walk(config)
    return refs
