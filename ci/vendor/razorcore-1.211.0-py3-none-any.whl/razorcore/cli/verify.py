"""Razorcore CLI Verify — project verification functions."""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

from razorcore.cli.registry import (
    BUILDABLE_PROJECTS,
    CYAN,
    DOC_ONLY_PROJECTS,
    GREEN,
    NC,
    PYTHON_VERSION,
    PYTHON_VERSION_TUPLE,
    RED,
    YELLOW,
    get_projects,
    log_error,
    log_info,
    log_success,
    log_warning,
)


def _verify_project_configs(
    proj_dir: Path, proj_name: str, is_doc_only: bool, errors: int, warnings: int
) -> tuple[int, int]:
    """Verify project configuration files (pyproject.toml, pyrightconfig.json)."""
    for config_name in ["pyproject.toml", "pyrightconfig.json"]:
        config_path = proj_dir / config_name
        if config_path.is_symlink():
            log_error(f"{config_name} is still a symlink!")
            errors += 1
        elif config_path.exists():
            log_success(f"{config_name} is a regular file")
        else:
            if is_doc_only:
                log_info(f"Skipping {config_name} check (documentation project)")
            else:
                log_warning(f"{config_name} missing")
                warnings += 1
    return errors, warnings


def _verify_portfolio_link(proj_dir: Path) -> int:
    """Verify PORTFOLIO.md is not a symlink."""
    portfolio_path = proj_dir / "docs" / "PORTFOLIO.md"
    if portfolio_path.is_symlink():
        log_error("docs/PORTFOLIO.md is still a symlink!")
        return 1
    elif portfolio_path.exists():
        log_success("docs/PORTFOLIO.md is a regular file")
    return 0


def _verify_gitignore(proj_dir: Path, warnings: int) -> int:
    """Verify .gitignore doesn't reference deprecated .dev-tools."""
    gitignore = proj_dir / ".gitignore"
    if gitignore.exists():
        content = gitignore.read_text(encoding="utf-8")
        if ".dev-tools" in content:
            log_warning(".gitignore still references .dev-tools")
            warnings += 1
    return warnings


def _verify_required_files(proj_dir: Path, errors: int) -> int:
    """Verify README.md and LICENSE exist."""
    if (proj_dir / "README.md").exists():
        log_success("README.md exists")
    else:
        log_error("README.md missing")
        errors += 1

    has_license = (proj_dir / "LICENSE").exists()
    if has_license:
        log_success("LICENSE exists")
    else:
        log_error("LICENSE missing")
        errors += 1
    return errors


def _verify_build_tooling(
    proj_dir: Path, proj_name: str, errors: int, warnings: int
) -> tuple[int, int]:
    """Verify build tooling (spec file, requirements.txt, dmg-config.json)."""
    import json

    spec_path = proj_dir / f"{proj_name}.spec"
    if spec_path.exists():
        log_success(f"{proj_name}.spec exists (PyInstaller)")
    else:
        log_error(f"{proj_name}.spec missing (PyInstaller required)")
        errors += 1

    requirements = proj_dir / "requirements.txt"
    if requirements.exists():
        try:
            req_text = requirements.read_text(encoding="utf-8").lower()
        except OSError:
            req_text = ""
        if "py2app" in req_text:
            log_error("requirements.txt references py2app (PyInstaller only)")
            errors += 1

    setup_py = proj_dir / "setup.py"
    if setup_py.exists():
        try:
            setup_text = setup_py.read_text(encoding="utf-8").lower()
        except OSError:
            setup_text = ""
        if "py2app" in setup_text:
            log_warning(
                "setup.py still references py2app (legacy; build uses PyInstaller)"
            )
            warnings += 1

    dmg_config = proj_dir / "build" / "dmg-config.json"
    if dmg_config.exists():
        try:
            with open(dmg_config, encoding="utf-8") as f:
                dmg_data = json.load(f)

            expected = {
                "window_width": 600,
                "window_height": 350,
                "window_x": 200,
                "window_y": 120,
                "app_icon_x": 175,
                "app_icon_y": 150,
                "applications_icon_x": 425,
                "applications_icon_y": 150,
                "icon_size": 100,
            }

            mismatched = [
                key
                for key, value in expected.items()
                if dmg_data.get(key, value) != value
            ]

            if mismatched:
                log_error("build/dmg-config.json has non-standard DMG layout values")
                for key in mismatched:
                    log_error(f"  {key}={dmg_data.get(key)}")
                errors += 1
            else:
                log_success("build/dmg-config.json DMG layout values are standard")
        except (OSError, ValueError):
            log_warning("Could not parse build/dmg-config.json")
            warnings += 1

    return errors, warnings


def verify(
    workspace: Path, projects: list[str] | None = None, strict: bool = False
) -> int:
    """Verify project structure and compliance."""
    print(f"\n{'=' * 60}")
    print("  Razorcore Project Verification")
    print(f"{'=' * 60}\n")

    project_dirs = get_projects(workspace, projects)

    if not project_dirs:
        log_error("No projects found to verify")
        return 1

    errors = 0
    warnings = 0

    for proj_dir in project_dirs:
        proj_name = proj_dir.name
        print(f"\n{CYAN}[{proj_name}]{NC}")

        # Check for pyproject.toml
        is_doc_only = proj_name in DOC_ONLY_PROJECTS
        if (proj_dir / "pyproject.toml").exists():
            log_success("pyproject.toml exists")
        else:
            if is_doc_only:
                log_info("Skipping pyproject.toml check (documentation project)")
            else:
                log_error("pyproject.toml missing")
                errors += 1

        # Check for symlinks (should NOT exist anymore)
        errors, warnings = _verify_project_configs(
            proj_dir, proj_name, is_doc_only, errors, warnings
        )

        # Check for PORTFOLIO.md symlink (should NOT exist)
        errors += _verify_portfolio_link(proj_dir)

        # Check for .dev-tools references
        warnings = _verify_gitignore(proj_dir, warnings)

        # Check README exists
        errors = _verify_required_files(proj_dir, errors)

        # Enforce build tooling + DMG layout for buildable apps
        if proj_name in BUILDABLE_PROJECTS:
            errors, warnings = _verify_build_tooling(
                proj_dir, proj_name, errors, warnings
            )

    # Check that .dev-tools doesn't exist
    dev_tools = workspace / ".dev-tools"
    print(f"\n{CYAN}[Workspace Checks]{NC}")

    # Verify running Python matches the locked workspace version
    actual = sys.version_info[:2]
    if actual != PYTHON_VERSION_TUPLE:
        log_warning(
            f"Python version mismatch: running {actual[0]}.{actual[1]},"
            f" workspace requires {PYTHON_VERSION}"
        )
        warnings += 1
    else:
        log_success(f"Python {PYTHON_VERSION} (matches workspace lock)")
    if dev_tools.exists():
        log_error(".dev-tools directory still exists!")
        errors += 1
    else:
        log_success(".dev-tools directory removed")

    # Check .razorcore exists
    if (workspace / ".razorcore").exists():
        log_success(".razorcore directory exists")
    else:
        log_error(".razorcore directory missing")
        errors += 1

    # Summary
    print(f"\n{'=' * 60}")
    if errors == 0 and (warnings == 0 or not strict):
        print(f"  {GREEN}✓ All verifications passed{NC}")
        if warnings > 0:
            print(f"  {YELLOW}  ({warnings} warnings){NC}")
    else:
        print(f"  {RED}✗ Verification failed{NC}")
        print(f"  {RED}  {errors} errors, {warnings} warnings{NC}")
    print(f"{'=' * 60}\n")

    if strict and warnings > 0:
        return 1
    return 1 if errors > 0 else 0


def check(workspace: Path, verify_mode: bool = False, strict: bool = False) -> int:
    """Run local quality checks by default, with optional full verification."""
    if verify_mode or strict:
        return verify(workspace, strict=strict)

    return check_repo_quality(Path.cwd())


def _run_quality_command(repo_dir: Path, command: list[str], label: str) -> int:
    """Run one quality command and print pass/fail status."""
    log_info(f"[{repo_dir.name}] {label}")
    env = os.environ.copy()
    # Prevent uv from warning when this process was launched from a different venv.
    env.pop("VIRTUAL_ENV", None)
    result = subprocess.run(command, cwd=repo_dir, env=env, check=False)
    if result.returncode == 0:
        log_success(f"[{repo_dir.name}] {label} passed")
        return 0
    log_error(f"[{repo_dir.name}] {label} failed (exit {result.returncode})")
    return result.returncode


def check_repo_quality(repo_dir: Path) -> int:
    """Run ruff/ty/pytest checks for a single repository path."""
    if not (repo_dir / "pyproject.toml").exists():
        log_error(f"{repo_dir} is not a Python project (missing pyproject.toml)")
        return 1

    commands = [
        (["uv", "run", "ruff", "check", "."], "ruff"),
        (
            ["uv", "run", "ty", "check", "src", "--python-version", "3.14"],
            "ty (3.14)",
        ),
        (["uv", "run", "pytest", "tests/", "-q"], "pytest"),
    ]

    failures = 0
    for command, label in commands:
        if _run_quality_command(repo_dir, command, label) != 0:
            failures += 1
    return 1 if failures else 0


def check_all_repos_quality(workspace: Path) -> int:
    """Run quality checks for all managed repositories in Apps workspace."""
    project_dirs = get_projects(workspace)
    if not project_dirs:
        log_error("No projects found to run quality checks")
        return 1

    failures = 0
    for proj_dir in project_dirs:
        print(f"\n{CYAN}[{proj_dir.name}]{NC}")
        if check_repo_quality(proj_dir) != 0:
            failures += 1

    print(f"\n{'=' * 60}")
    if failures == 0:
        print(f"  {GREEN}✓ All repository quality checks passed{NC}")
    else:
        print(f"  {RED}✗ Repository quality checks failed in {failures} repo(s){NC}")
    print(f"{'=' * 60}\n")
    return 1 if failures else 0
