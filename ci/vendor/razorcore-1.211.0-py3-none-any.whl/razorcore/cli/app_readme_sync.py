"""Sync per-app README headers with current version and workspace health.

Surgical update: keeps every existing badge and prose section, only
injects a `<!-- Workspace Health Layer -->` block and updates or adds a
`Version` badge pointing at the current release. Also updates hardcoded
`vX.Y.Z` text in the Download DMG link if one is present.
"""

from __future__ import annotations

import re
from pathlib import Path

from razorcore.cli.app_kind import AppKind, detect_app_kind, read_version_file
from razorcore.cli.app_readme import (
    GITHUB_ORG,
    AppReadmeContext,
    _health_layer,
    readme_has_health_layer,
)
from razorcore.cli.registry import log_info, log_success, log_warning
from razorcore.cli.version import PUBLIC_APP_PROJECTS, _collect_versions


def _display_name(proj_dir: Path) -> str:
    return proj_dir.name


def _version_badge_line(name: str, version: str, *, org: str = GITHUB_ORG) -> str:
    return (
        f"[![Version](https://img.shields.io/badge/version-{version}-blue"
        f"?style=for-the-badge)](https://github.com/{org}/{name}/releases/tag/v{version})"
    )


def _download_version_re(name: str, version: str) -> str:
    """Regex to find a `Download {name}.dmg (vX.Y.Z)` link text."""
    return rf"({re.escape(name)}\.dmg \(v)(\d+\.\d+\.\d+)(\))"


def _find_badge_block(lines: list[str], name: str) -> tuple[int, int, list[str], int]:
    """Locate the badge block that immediately follows `# {name}`.

    Returns (title_end, block_start, block_lines, block_end).
    """
    title_idx = -1
    for i, line in enumerate(lines):
        if line.startswith(f"# {name}"):
            title_idx = i
            break
    if title_idx < 0:
        return 0, 0, [], 0

    # Index after the title line
    title_end = title_idx + 1

    # Skip the blank line after the title
    block_start = title_end
    while block_start < len(lines) and lines[block_start].strip() == "":
        block_start += 1

    block_end = block_start
    while block_end < len(lines) and (
        lines[block_end].lstrip().startswith("[") or lines[block_end].strip() == ""
    ):
        block_end += 1

    block_lines = [
        line for line in lines[block_start:block_end] if line.lstrip().startswith("[")
    ]
    return title_end, block_start, block_lines, block_end


def _extract_badge_label(line: str) -> str | None:
    match = re.match(r"^\[!\[(.*?)]", line)
    return match.group(1) if match else None


def _sync_app_readme_text(
    text: str,
    display_name: str,
    version: str,
    kind: AppKind,
) -> str:
    """Update the header of a single app README while preserving the rest."""
    if readme_has_health_layer(text) and _version_badge_is_current(text, version):
        return text

    lines = text.splitlines()
    title_end, block_start, block_lines, block_end = _find_badge_block(
        lines, display_name
    )
    if block_start == 0:
        # Could not find a recognizable badge block; leave README untouched.
        return text

    # Preserve existing badges and add/refresh the Version badge.
    new_badges: list[str] = []
    has_version = False
    for line in block_lines:
        label = _extract_badge_label(line)
        if label == "Version":
            new_badges.append(_version_badge_line(display_name, version))
            has_version = True
        else:
            new_badges.append(line)
    if not has_version:
        # Insert Version badge right after Download/CI, or at the front.
        insert_at = 0
        for i, line in enumerate(new_badges):
            label = _extract_badge_label(line)
            if label in {"Download", "CI"}:
                insert_at = i + 1
                break
        new_badges.insert(insert_at, _version_badge_line(display_name, version))

    health = _health_layer(kind).rstrip()
    header = f"# {display_name}\n\n" + "\n".join(new_badges) + f"\n\n{health}\n\n"
    body = "\n".join(lines[block_end:])

    new_text = header + body

    # Fix hardcoded version in Download DMG link text, if present.
    dl_re = _download_version_re(display_name, version)
    new_text = re.sub(dl_re, rf"\g<1>{version}\g<3>", new_text)

    # Normalize trailing newline.
    return new_text.rstrip() + "\n"


def _version_badge_is_current(text: str, version: str) -> bool:
    return f"version-{version}-" in text or f"tag/v{version}" in text


def _build_sync_context(proj_dir: Path) -> AppReadmeContext:
    display_name = _display_name(proj_dir)
    kind = detect_app_kind(proj_dir)
    version, version_file = read_version_file(kind, proj_dir)
    return AppReadmeContext(
        display_name=display_name,
        version=version,
        description="",
        run_command="",
        build_command="",
        version_file=version_file,
        kind=kind,
    )


def sync_app_readme(
    proj_dir: Path,
    version: str | None = None,
    dry_run: bool = False,
) -> int:
    """Update an app README's health layer and version badge."""
    display_name = _display_name(proj_dir)
    readme_path = proj_dir / "README.md"
    if not readme_path.exists():
        log_warning(f"README.md not found for {display_name}")
        return 0

    ctx = _build_sync_context(proj_dir)
    if version is None:
        version = ctx.version

    original = readme_path.read_text(encoding="utf-8")
    updated = _sync_app_readme_text(
        original,
        display_name,
        version,
        ctx.kind,
    )

    if updated == original:
        log_info(f"{display_name} README already up to date")
        return 0

    if dry_run:
        log_info(f"Dry run - would update {display_name} README.md")
        return 0

    readme_path.write_text(updated, encoding="utf-8")
    log_success(f"Updated {display_name} README.md")
    return 0


def sync_app_readmes(
    workspace: Path,
    dry_run: bool = False,
) -> int:
    """Sync all public app READMEs."""
    print(f"\n{'=' * 60}")
    print("  Razorcore Sync App READMEs")
    print(f"{'=' * 60}\n")

    versions = _collect_versions(workspace)
    status = 0
    for name in PUBLIC_APP_PROJECTS:
        proj_dir = workspace / name
        if not proj_dir.is_dir():
            log_warning(f"Project directory not found: {name}")
            status = 1
            continue
        version = versions.get(name)
        if not version:
            log_warning(f"Could not determine version for {name}")
            status = 1
            continue
        if sync_app_readme(proj_dir, version=version, dry_run=dry_run) != 0:
            status = 1

    print(f"\n{'=' * 60}")
    print(f"  {'✓ Sync complete' if status == 0 else '⚠ Sync completed with warnings'}")
    print(f"{'=' * 60}\n")
    return status
