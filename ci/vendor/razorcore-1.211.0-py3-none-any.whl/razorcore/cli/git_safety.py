"""Explicit approval gates for mutating Git automation."""

from __future__ import annotations

import os
from collections.abc import Callable, Mapping


GIT_MUTATION_ENV = "RAZORCORE_ALLOW_GIT_MUTATION"
PR_CREATION_ENV = "RAZORCORE_ALLOW_PR_CREATION"
_TRUTHY = {"1", "true", "yes", "y", "on"}


def _env_enabled(name: str, env: Mapping[str, str] | None = None) -> bool:
    value = (env or os.environ).get(name, "")
    return value.strip().lower() in _TRUTHY


def git_mutation_allowed(env: Mapping[str, str] | None = None) -> bool:
    """Return whether commits, pushes, tags, branches, or worktrees are allowed."""
    return _env_enabled(GIT_MUTATION_ENV, env)


def pr_creation_allowed(env: Mapping[str, str] | None = None) -> bool:
    """Return whether automatic pull-request creation is allowed."""
    return _env_enabled(PR_CREATION_ENV, env)


def require_git_mutation_allowed(action: str, log_error: Callable[[str], None]) -> bool:
    """Log and return False unless mutating Git automation is explicitly enabled."""
    if git_mutation_allowed():
        return True

    log_error(
        f"Refusing to {action} without explicit approval. "
        f"Set {GIT_MUTATION_ENV}=1 only when you intentionally want "
        "commit, push, tag, branch, or worktree changes."
    )
    return False
