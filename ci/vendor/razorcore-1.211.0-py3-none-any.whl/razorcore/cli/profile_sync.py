"""Sync public app versions onto github.com/RazorBackRoar/RazorBackRoar.

The profile README is not in the local workspace. Updates clone that repo to a
temp directory, rewrite the badge row and Apps table from local manifests, then
commit and push when git mutation is allowed (or RAZORCORE_AUTO_PUSH=1).
"""

from __future__ import annotations

import os
import re
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path

from razorcore.cli.git_safety import git_mutation_allowed
from razorcore.cli.registry import (
    PUBLIC_APP_PROJECTS,
    log_error,
    log_info,
    log_success,
    log_warning,
)
from razorcore.cli.version import _collect_versions


PROFILE_REPO = "RazorBackRoar/RazorBackRoar"
GITHUB_ORG = "RazorBackRoar"


@dataclass(frozen=True)
class ProfileApp:
    repo: str
    badge_name: str
    color: str
    stack: str
    blurb: str
    logo_color: str | None = None


# Display order on the public profile. Private tooling is omitted.
PROFILE_APPS: tuple[ProfileApp, ...] = (
    ProfileApp(
        "4Charm",
        "4Charm",
        "green",
        "Python · PySide6",
        "High-performance 4chan media downloader with smart organization and resume",
    ),
    ProfileApp(
        "Nexus",
        "Nexus",
        "purple",
        "Python · PySide6",
        "Safari bookmark manager and batch URL opener",
    ),
    ProfileApp(
        "RyuSync",
        "RyuSync",
        "blue",
        "Python · PySide6",
        "Nintendo Switch `.nsp` / `.xci` file organizer with Dry Mode preview",
    ),
    ProfileApp(
        "Swifter",
        "Swifter",
        "orange",
        "Swift · SwiftUI",
        "Ultra-fast exact duplicate photo & video finder with CryptoKit and quarantine",
    ),
    ProfileApp(
        "SwiftTemp",
        "SwiftTemp",
        "c4711a",
        "Swift · SwiftUI",
        "Lightweight native macOS menu bar thermal monitor for Apple Silicon",
    ),
    ProfileApp(
        "Libra",
        "Libra",
        "yellow",
        "Swift · SwiftUI",
        "Local-first video organization toolkit (sort, rename, GPS / iPhone tools)",
        logo_color="black",
    ),
    ProfileApp(
        "Looper",
        "Looper",
        "5B8DEF",
        "Swift · AppKit",
        "Minimal native video player with gapless looping",
    ),
    ProfileApp(
        "MetaBurn",
        "MetaBurn",
        "critical",
        "Swift · SwiftUI",
        "Strip EXIF, GPS, and device metadata from photos and videos locally",
    ),
)

_BADGE_BLOCK_RE = re.compile(
    r"(# RazorBackRoar\n\n\*\*Native macOS apps[^\n]*\n\n)(.*?)(\n<br/>)",
    flags=re.S,
)
_TABLE_BLOCK_RE = re.compile(
    r"(<h2 align=\"center\">Apps</h2>\n\n)(\| App.*?)(\n\nAll apps ship)",
    flags=re.S,
)


def _env_auto_push() -> bool:
    return os.environ.get("RAZORCORE_AUTO_PUSH", "").strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    }


def profile_push_allowed() -> bool:
    """Autosync already publishes; treat AUTO_PUSH as approval for the profile repo."""
    return git_mutation_allowed() or _env_auto_push()


def render_badge_row(app: ProfileApp, version: str) -> str:
    extra = f"&logoColor={app.logo_color}" if app.logo_color else ""
    return (
        f"[![{app.badge_name}](https://img.shields.io/badge/"
        f"{app.badge_name}-v{version}-{app.color}"
        f"?style=for-the-badge&logo=apple{extra})]"
        f"(https://github.com/{GITHUB_ORG}/{app.repo}/releases)"
    )


def render_table_row(app: ProfileApp, version: str) -> str:
    name = f"**{app.badge_name}**"
    return (
        f"| [{name}](https://github.com/{GITHUB_ORG}/{app.repo}) "
        f"| {app.blurb} "
        f"| {app.stack} "
        f"| [v{version}](https://github.com/{GITHUB_ORG}/{app.repo}/releases) |"
    )


def _profile_apps_sorted() -> tuple[ProfileApp, ...]:
    """Return PROFILE_APPS sorted alphabetically by badge name."""
    return tuple(sorted(PROFILE_APPS, key=lambda app: app.badge_name))


def render_badge_block(versions: dict[str, str]) -> str:
    lines = [
        render_badge_row(app, versions[app.repo])
        for app in _profile_apps_sorted()
        if app.repo in versions
    ]
    return "\n".join(lines) + "\n"


def render_apps_table(versions: dict[str, str]) -> str:
    header = "| App | What it does | Stack | Latest |\n| --- | --- | --- | --- |\n"
    rows = [
        render_table_row(app, versions[app.repo])
        for app in _profile_apps_sorted()
        if app.repo in versions
    ]
    return header + "\n".join(rows)


_SECTION_RE = re.compile(
    r"^(#{1,6}\s+.*|<h[1-6](?:\s[^>]*)?>.*?</h[1-6]>\s*)$",
    flags=re.S | re.M,
)
_SECTION_TITLE_RE = re.compile(
    r"^(?:#{1,6}\s*(.+?)|<h[1-6](?:\s[^>]*)?>(.+?)</h[1-6]>)\s*$",
    flags=re.S | re.M,
)


def _section_title(line: str) -> str:
    match = _SECTION_TITLE_RE.match(line)
    if not match:
        return line
    title = match.group(1) or match.group(2)
    return title.strip()


def _split_sections(readme: str) -> tuple[str, list[tuple[str, str]]]:
    """Split README into a preface and (title, content) sections."""
    sections: list[tuple[str, str]] = []
    preface_lines: list[str] = []
    current_title: str | None = None
    current_lines: list[str] = []

    for line in readme.splitlines(keepends=True):
        if _SECTION_RE.match(line.rstrip("\n")):
            if current_title is not None:
                sections.append((current_title, "".join(current_lines).strip("\n")))
            else:
                preface_lines.extend(current_lines)
            current_title = _section_title(line)
            current_lines = []
            continue
        current_lines.append(line)

    if current_title is not None:
        sections.append((current_title, "".join(current_lines).strip("\n")))
    else:
        preface_lines.extend(current_lines)

    preface = "".join(preface_lines).strip("\n")
    return preface, sections


def _is_target_format(readme: str) -> bool:
    return (
        _BADGE_BLOCK_RE.search(readme) is not None
        and _TABLE_BLOCK_RE.search(readme) is not None
    )


def _is_about_title(title: str) -> bool:
    return bool(re.search(r"(?i)\babout\b", title))


def _is_apps_title(title: str) -> bool:
    return bool(re.search(r"(?i)\bapps\b", title))


def _is_tech_title(title: str) -> bool:
    return bool(re.search(r"(?i)\btech\b", title))


def _is_contact_title(title: str) -> bool:
    return bool(re.search(r"(?i)\bcontact\b", title))


def _format_optional_section(title: str, content: str) -> str | None:
    if not content:
        return None
    return f"\n{title}\n\n{content}\n"


def _build_profile_readme(
    versions: dict[str, str],
    about: str,
    tech: str,
    contact: str,
) -> str:
    """Generate a complete profile README in the machine-updateable format."""
    badges = render_badge_block(versions)
    table = render_apps_table(versions)
    footer = (
        "All apps ship as **Apple Silicon DMGs**. "
        "First launch: right-click → **Open** (ad-hoc signed builds)."
    )

    parts = [
        '<div align="center">',
        "",
        "# RazorBackRoar",
        "",
        "**Native macOS apps for Apple Silicon**",
        "",
        badges,
        "<br/>",
        "</div>",
        "",
        "---",
        "",
        '<h2 align="center">Apps</h2>',
        "",
        table,
        "",
        footer,
        _format_optional_section("## 👨‍💻 About me", about),
        _format_optional_section("## 🛠️ Tech I work with", tech),
        _format_optional_section("## Contact", contact),
    ]
    return "\n".join(part for part in parts if part is not None)


def apply_profile_readme(readme: str, versions: dict[str, str]) -> str:
    """Rewrite the badge row and Apps table from `versions`. Preserve the rest."""
    missing = [name for name in PUBLIC_APP_PROJECTS if name not in versions]
    if missing:
        raise ValueError(f"Missing versions for profile apps: {', '.join(missing)}")

    badges = render_badge_block(versions)
    table = render_apps_table(versions)

    if _is_target_format(readme):
        updated, badge_count = _BADGE_BLOCK_RE.subn(rf"\1{badges}\3", readme, count=1)
        if badge_count != 1:
            raise ValueError("Could not find the profile badge block in README.md")

        updated, table_count = _TABLE_BLOCK_RE.subn(rf"\1{table}\3", updated, count=1)
        if table_count != 1:
            raise ValueError("Could not find the profile Apps table in README.md")
        return updated

    preface, sections = _split_sections(readme)
    about = ""
    tech = ""
    contact = ""
    # Preface is only used as a fallback about blurb when there is no About me
    # heading and the preface is not just an HTML wrapper.
    fallback_about = preface if preface and "<div" not in preface else ""
    for title, content in sections:
        if _is_about_title(title):
            about = f"{about}\n\n{content}".strip() if about else content
        elif _is_tech_title(title):
            tech = content
        elif _is_contact_title(title):
            contact = content
        elif _is_apps_title(title):
            # Drop old app list; we'll regenerate it below.
            continue

    if not about:
        about = fallback_about

    return _build_profile_readme(versions, about, tech, contact)


def _run_git(args: list[str], cwd: Path) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["git", *args],
        cwd=cwd,
        capture_output=True,
        text=True,
        check=False,
    )


def _clone_profile(dest: Path) -> int:
    result = subprocess.run(
        ["gh", "repo", "clone", PROFILE_REPO, str(dest), "--", "--depth", "1"],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        log_error(result.stderr.strip() or f"Failed to clone {PROFILE_REPO}")
        return result.returncode
    return 0


def sync_github_profile(workspace: Path, dry_run: bool = False) -> int:
    """Update RazorBackRoar/RazorBackRoar so listed apps match local manifests."""
    print(f"\n{'=' * 60}")
    print("  Razorcore Sync GitHub Profile")
    print(f"{'=' * 60}\n")

    versions = _collect_versions(workspace)
    public_versions = {
        name: versions[name] for name in PUBLIC_APP_PROJECTS if name in versions
    }
    missing = [name for name in PUBLIC_APP_PROJECTS if name not in public_versions]
    if missing:
        log_error(f"Missing local versions: {', '.join(missing)}")
        return 1

    if dry_run:
        log_info(
            "Dry run — would clone RazorBackRoar/RazorBackRoar and rewrite README.md"
        )
        for app in PROFILE_APPS:
            log_info(f"{app.badge_name}: v{public_versions[app.repo]}")
        return 0

    with tempfile.TemporaryDirectory(prefix="razor-profile-") as tmp:
        dest = Path(tmp) / "RazorBackRoar"
        if _clone_profile(dest) != 0:
            return 1

        readme_path = dest / "README.md"
        original = readme_path.read_text(encoding="utf-8")
        try:
            updated = apply_profile_readme(original, public_versions)
        except ValueError as exc:
            log_error(str(exc))
            return 1

        if updated == original:
            log_info("GitHub profile README already matches local app versions")
            return 0

        if not profile_push_allowed():
            log_warning(
                "Profile README is stale, but git mutation is not enabled. "
                "Re-run with RAZORCORE_ALLOW_GIT_MUTATION=1 (or RAZORCORE_AUTO_PUSH=1)."
            )
            return 0

        readme_path.write_text(updated, encoding="utf-8")
        add = _run_git(["add", "README.md"], dest)
        if add.returncode != 0:
            log_error(add.stderr.strip() or "git add failed")
            return 1
        commit = _run_git(
            [
                "commit",
                "-m",
                "chore: sync public app versions on the GitHub profile",
            ],
            dest,
        )
        if commit.returncode != 0:
            log_error(commit.stderr.strip() or "git commit failed")
            return 1
        push = _run_git(["push", "origin", "HEAD"], dest)
        if push.returncode != 0:
            log_error(push.stderr.strip() or "git push failed")
            return 1

    log_success(f"Updated {PROFILE_REPO} to match local app versions")
    return 0
