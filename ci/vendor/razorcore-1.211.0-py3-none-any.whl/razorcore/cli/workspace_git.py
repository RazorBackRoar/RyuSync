"""Centralized safe Git/test workflows for managed app repositories."""

from __future__ import annotations

import os
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path

from razorcore.cli.git_safety import require_git_mutation_allowed
from razorcore.cli.registry import (
    CYAN,
    GREEN,
    NC,
    PROJECT_NAME_ALIASES,
    PUBLIC_APP_PROJECTS,
    RED,
    YELLOW,
)


def _run(
    args: list[str], cwd: Path, *, capture: bool = True
) -> subprocess.CompletedProcess[str]:
    """Run a subprocess command with predictable text capture."""
    return subprocess.run(
        args,
        cwd=cwd,
        check=False,
        capture_output=capture,
        text=True,
    )


def _cmd_stdout(args: list[str], cwd: Path) -> str | None:
    """Return command stdout on success; otherwise None."""
    result = _run(args, cwd)
    if result.returncode != 0:
        return None
    return result.stdout.strip()


@dataclass(slots=True)
class RepoState:
    """Computed repository status used by safety checks and summaries."""

    app: str
    path: Path
    exists: bool
    is_git: bool
    branch: str = "-"
    remote_exists: bool = False
    upstream: str | None = None
    upstream_exists: bool = False
    ahead: int | None = None
    behind: int | None = None
    staged: int = 0
    unstaged: int = 0
    untracked: int = 0
    dirty: bool = False
    merge_in_progress: bool = False
    rebase_in_progress: bool = False
    cherry_pick_in_progress: bool = False
    conflicts: int = 0
    pyproject_exists: bool = False
    venv_exists: bool = False
    uv_available: bool = False
    python_version: str = "-"
    notes: list[str] = field(default_factory=list)


def _new_state(app: str, path: Path) -> RepoState:
    return RepoState(app=app, path=path, exists=path.exists(), is_git=False)


def _apps_root(workspace: Path) -> Path:
    """Normalize either Workspace root or Apps root into Apps root."""
    if workspace.name == "Apps":
        return workspace
    candidate = workspace / "Apps"
    if candidate.is_dir():
        return candidate
    return workspace


def _managed_apps() -> list[str]:
    """Return canonical managed app names across all public product apps."""
    return list(PUBLIC_APP_PROJECTS)


def _normalize_app_name(raw: str) -> str:
    canonical = PROJECT_NAME_ALIASES.get(raw.strip().lower(), raw.strip())
    return canonical


def _app_path(apps_root: Path, app: str) -> Path:
    return apps_root / app


def _is_within(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False


def _detect_current_app(apps_root: Path, cwd: Path) -> str | None:
    """Return the managed app name when cwd is inside one app repo."""
    for app in _managed_apps():
        if _is_within(cwd, _app_path(apps_root, app)):
            return app
    return None


def _resolve_single_app(
    apps_root: Path,
    cwd: Path,
    app: str | None,
    *,
    command_name: str,
) -> tuple[str | None, str | None]:
    """Resolve one target app for local-only commands.

    Push/pull commands operate on all public product apps, not just the
    legacy Python managed-app list.
    """
    allowed = (
        PUBLIC_APP_PROJECTS
        if command_name in {"razorpushapp", "razorpullapp"}
        else _managed_apps()
    )
    if app:
        normalized = _normalize_app_name(app)
        if normalized not in allowed:
            return None, f"Unknown app: {app}"
        return normalized, None

    for candidate in allowed:
        if _is_within(cwd, _app_path(apps_root, candidate)):
            return candidate, None

    counterpart = "razorpushapp" if command_name == "razorpullapp" else "razorpullapp"
    return (
        None,
        "\n".join(
            [
                "Not inside a managed app repo.",
                "Use one of:",
                f"  {command_name} --app SwiftTemp",
                f"  {counterpart} --app 4Charm",
                "  razorgit",
                "  razorall",
            ]
        ),
    )


def _git_dir(path: Path) -> Path | None:
    out = _cmd_stdout(["git", "rev-parse", "--git-dir"], path)
    if not out:
        return None
    git_dir = Path(out)
    if not git_dir.is_absolute():
        git_dir = (path / git_dir).resolve()
    return git_dir


def _count_conflicts(path: Path) -> int:
    out = _cmd_stdout(["git", "diff", "--name-only", "--diff-filter=U"], path)
    if out is None:
        return 0
    return len([line for line in out.splitlines() if line.strip()])


def _compute_untracked_overwrite_risk(path: Path, upstream: str) -> list[str]:
    """Return untracked files that overlap incoming remote changes."""
    status_out = _cmd_stdout(
        ["git", "status", "--porcelain", "--untracked-files=all"], path
    )
    if status_out is None:
        return []

    untracked: set[str] = set()
    for line in status_out.splitlines():
        if line.startswith("?? "):
            untracked.add(line[3:].strip())

    if not untracked:
        return []

    remote_changed_out = _cmd_stdout(
        ["git", "diff", "--name-only", f"HEAD..{upstream}"], path
    )
    if remote_changed_out is None:
        return []

    remote_changed = {
        line.strip() for line in remote_changed_out.splitlines() if line.strip()
    }
    overlap = sorted(untracked & remote_changed)
    return overlap


def collect_repo_state(app: str, repo: Path) -> RepoState:
    """Collect git + tooling state for one managed repository path."""
    state = _new_state(app, repo)
    state.pyproject_exists = (repo / "pyproject.toml").exists()
    state.venv_exists = (repo / ".venv").exists()
    state.uv_available = shutil.which("uv") is not None

    if not state.exists:
        state.notes.append("missing path")
        return state

    git_probe = _run(["git", "rev-parse", "--is-inside-work-tree"], repo)
    if git_probe.returncode != 0:
        state.notes.append("not a git repo")
        return state

    state.is_git = True

    branch = _cmd_stdout(["git", "branch", "--show-current"], repo)
    if branch:
        state.branch = branch

    remote_out = _cmd_stdout(["git", "remote"], repo)
    state.remote_exists = bool(remote_out)

    upstream_out = _cmd_stdout(
        ["git", "rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}"], repo
    )
    if upstream_out:
        state.upstream_exists = True
        state.upstream = upstream_out

    if state.upstream_exists:
        counts = _cmd_stdout(
            ["git", "rev-list", "--left-right", "--count", "HEAD...@{u}"], repo
        )
        if counts:
            parts = counts.split()
            if len(parts) == 2:
                try:
                    state.ahead = int(parts[0])
                    state.behind = int(parts[1])
                except ValueError:
                    state.notes.append("unable to parse ahead/behind")
        else:
            state.notes.append("unable to determine ahead/behind")

    status_out = (
        _cmd_stdout(["git", "status", "--porcelain", "--untracked-files=all"], repo)
        or ""
    )
    for line in status_out.splitlines():
        if not line.strip():
            continue
        if line.startswith("?? "):
            state.untracked += 1
            continue
        index_status = line[0]
        worktree_status = line[1]
        if index_status != " ":
            state.staged += 1
        if worktree_status != " ":
            state.unstaged += 1

    state.dirty = bool(state.staged or state.unstaged or state.untracked)

    git_dir = _git_dir(repo)
    if git_dir:
        state.merge_in_progress = (git_dir / "MERGE_HEAD").exists()
        state.rebase_in_progress = (git_dir / "rebase-apply").exists() or (
            git_dir / "rebase-merge"
        ).exists()
        state.cherry_pick_in_progress = (git_dir / "CHERRY_PICK_HEAD").exists()

    state.conflicts = _count_conflicts(repo)

    if state.uv_available and state.pyproject_exists:
        # Avoid uv VIRTUAL_ENV mismatch warnings when parent shell is in another venv.
        base_env = {k: v for k, v in os.environ.items() if k != "VIRTUAL_ENV"}
        py_result = subprocess.run(
            ["uv", "run", "python", "--version"],
            cwd=repo,
            check=False,
            capture_output=True,
            text=True,
            env=base_env,
        )
        py_text = (py_result.stdout or py_result.stderr).strip()
        if py_result.returncode == 0 and py_text:
            state.python_version = py_text.splitlines()[-1]
        elif py_text:
            state.notes.append(f"python version check failed: {py_text}")

    if not state.pyproject_exists:
        state.notes.append("missing pyproject.toml")
    if not state.venv_exists:
        state.notes.append("missing .venv")
    if not state.uv_available:
        state.notes.append("uv not found on PATH")

    return state


def _status_label(state: RepoState) -> str:
    if not state.exists:
        return "missing"
    if not state.is_git:
        return "not-git"
    return "dirty" if state.dirty else "clean"


def _ahead_behind_label(state: RepoState) -> str:
    if state.ahead is None or state.behind is None:
        return "-"
    return f"{state.ahead}/{state.behind}"


def _notes_label(state: RepoState) -> str:
    notes: list[str] = []
    if state.merge_in_progress:
        notes.append("merge in progress")
    if state.rebase_in_progress:
        notes.append("rebase in progress")
    if state.cherry_pick_in_progress:
        notes.append("cherry-pick in progress")
    if state.conflicts:
        notes.append(f"{state.conflicts} conflict(s)")
    if state.untracked:
        notes.append("untracked files")
    if state.notes:
        notes.extend(n for n in state.notes if n not in notes)
    return ", ".join(notes) if notes else "ok"


def _print_summary(states: list[RepoState]) -> None:
    print(f"\n{'=' * 96}")
    print("APP        BRANCH      STATUS   AHEAD/BEHIND  REMOTE  UPSTREAM  NOTES")
    print(f"{'-' * 96}")
    for state in states:
        remote = "yes" if state.remote_exists else "no"
        upstream = "yes" if state.upstream_exists else "no"
        print(
            f"{state.app:<10} "
            f"{state.branch:<11} "
            f"{_status_label(state):<8} "
            f"{_ahead_behind_label(state):<13} "
            f"{remote:<7} "
            f"{upstream:<8} "
            f"{_notes_label(state)}"
        )
    print(f"{'=' * 96}\n")


def _print_single_state(state: RepoState) -> None:
    _print_summary([state])
    print(f"Repo: {state.path}")
    print(f"Python: {state.python_version}")
    print(f".venv present: {'yes' if state.venv_exists else 'no'}")
    print(f"uv available: {'yes' if state.uv_available else 'no'}")
    print(f"pyproject.toml: {'yes' if state.pyproject_exists else 'no'}")
    print(
        f"staged={state.staged} unstaged={state.unstaged} untracked={state.untracked}"
    )
    print()


def _targets_for_status(
    apps_root: Path,
    cwd: Path,
    *,
    app: str | None,
    all_repos: bool,
) -> tuple[list[tuple[str, Path]], str | None]:
    if app:
        normalized = _normalize_app_name(app)
        if normalized not in _managed_apps():
            return [], f"Unknown app: {app}"
        return [(normalized, _app_path(apps_root, normalized))], None

    if all_repos:
        return [(name, _app_path(apps_root, name)) for name in _managed_apps()], None

    detected = _detect_current_app(apps_root, cwd)
    if detected:
        return [(detected, _app_path(apps_root, detected))], None

    return [(name, _app_path(apps_root, name)) for name in _managed_apps()], None


def run_razorcheck(
    workspace: Path,
    cwd: Path,
    *,
    app: str | None,
    all_repos: bool,
) -> int:
    """Read-only Git and environment health checker."""
    apps_root = _apps_root(workspace)
    targets, error = _targets_for_status(apps_root, cwd, app=app, all_repos=all_repos)
    if error:
        print(f"{RED}✗{NC} {error}")
        return 1

    states = [collect_repo_state(name, path) for name, path in targets]
    if len(states) == 1:
        _print_single_state(states[0])
    else:
        _print_summary(states)
    return 0


def _run_repo_quality(repo: Path) -> int:
    commands: list[tuple[list[str], str]] = [
        (["uv", "--version"], "uv --version"),
        (["uv", "run", "python", "--version"], "uv run python --version"),
        (["uv", "run", "ruff", "check", "."], "uv run ruff check ."),
        (["uv", "run", "ty", "check", "."], "uv run ty check ."),
    ]

    env = {k: v for k, v in os.environ.items() if k != "VIRTUAL_ENV"}
    failures = 0

    for command, label in commands:
        print(f"{CYAN}→{NC} {label}")
        result = subprocess.run(command, cwd=repo, env=env, check=False)
        if result.returncode == 0:
            print(f"{GREEN}✓{NC} {label} passed")
        else:
            print(f"{RED}✗{NC} {label} failed (exit {result.returncode})")
            failures += 1

    tests_dir = repo / "tests"
    if not tests_dir.exists():
        print(f"{YELLOW}⚠{NC} tests/ not found (pytest skipped)")
        return 1 if failures else 0

    print(f"{CYAN}→{NC} uv run pytest")
    pytest_result = subprocess.run(
        ["uv", "run", "pytest"], cwd=repo, env=env, check=False
    )
    if pytest_result.returncode == 0:
        print(f"{GREEN}✓{NC} uv run pytest passed")
    else:
        print(f"{RED}✗{NC} uv run pytest failed (exit {pytest_result.returncode})")
        failures += 1

    return 1 if failures else 0


def run_razortest(
    workspace: Path,
    cwd: Path,
    *,
    app: str | None,
    all_repos: bool,
) -> int:
    """Run lint/type/test checks for one app or all managed apps."""
    apps_root = _apps_root(workspace)

    if app:
        normalized = _normalize_app_name(app)
        if normalized not in _managed_apps():
            print(f"{RED}✗{NC} Unknown app: {app}")
            return 1
        targets = [(normalized, _app_path(apps_root, normalized))]
    elif all_repos:
        targets = [(name, _app_path(apps_root, name)) for name in _managed_apps()]
    else:
        detected = _detect_current_app(apps_root, cwd)
        if not detected:
            print(
                "Not inside a managed app repo. Use `razortest --all` or `razortest --app <AppName>`."
            )
            return 1
        targets = [(detected, _app_path(apps_root, detected))]

    failures = 0
    for name, repo in targets:
        print(f"\n[{name}]")
        if not repo.exists():
            print(f"{RED}✗{NC} Missing path: {repo}")
            failures += 1
            continue
        if not (repo / "pyproject.toml").exists():
            print(
                f"{YELLOW}⚠{NC} {repo} missing pyproject.toml; skipping Python checks"
            )
            failures += 1
            continue
        failures += _run_repo_quality(repo)

    return 1 if failures else 0


def _sync_precheck(state: RepoState, *, require_upstream: bool = True) -> list[str]:
    reasons: list[str] = []
    if not state.exists:
        reasons.append("repo path missing")
    if not state.is_git:
        reasons.append("not a git repository")
    if not state.remote_exists:
        reasons.append("no git remote configured")
    if require_upstream and not state.upstream_exists:
        reasons.append("branch has no upstream")
    if (
        state.merge_in_progress
        or state.rebase_in_progress
        or state.cherry_pick_in_progress
    ):
        reasons.append("git operation already in progress")
    if state.conflicts:
        reasons.append("unresolved conflicts present")
    if state.upstream_exists and (state.ahead is None or state.behind is None):
        reasons.append("remote state could not be determined")
    if state.upstream_exists:
        overlap = _compute_untracked_overwrite_risk(
            state.path, state.upstream or "@{u}"
        )
        if overlap:
            reasons.append(
                "untracked files may be overwritten: " + ", ".join(overlap[:5])
            )
    return reasons


def _push_precheck(state: RepoState, *, set_upstream: bool) -> list[str]:
    reasons = _sync_precheck(state, require_upstream=not set_upstream)

    if state.staged:
        reasons.append("staged but uncommitted changes")
    if state.unstaged:
        reasons.append("unstaged changes")
    if state.untracked:
        reasons.append("untracked files present")

    if not state.upstream_exists and not set_upstream:
        reasons.append("branch has no upstream (use --set-upstream)")

    if state.behind is not None and state.behind > 0:
        reasons.append("branch is behind remote")

    if state.branch in {"", "HEAD", "-"}:
        reasons.append("detached or unknown branch")

    return reasons


def _print_reasons(app: str, reasons: list[str]) -> None:
    print(f"{RED}✗{NC} [{app}] refusing operation:")
    for reason in reasons:
        print(f"  - {reason}")


def run_razorsync(
    workspace: Path,
    cwd: Path,
    *,
    app: str | None,
    dry_run: bool,
) -> int:
    """Sync one repo only using fetch + pull --rebase --autostash."""
    apps_root = _apps_root(workspace)
    resolved, error = _resolve_single_app(
        apps_root, cwd, app, command_name="razorpullapp"
    )
    if error:
        print(error)
        return 1
    assert resolved is not None

    repo = _app_path(apps_root, resolved)
    state = collect_repo_state(resolved, repo)
    reasons = _sync_precheck(state)
    if reasons:
        _print_reasons(resolved, reasons)
        return 1

    if dry_run:
        print(f"[{resolved}] dry-run")
        print("  git fetch --prune")
        print("  git status --short")
        print("  git pull --rebase --autostash")
        return 0

    for command in (
        ["git", "fetch", "--prune"],
        ["git", "status", "--short"],
        ["git", "pull", "--rebase", "--autostash"],
    ):
        print(f"{CYAN}→{NC} [{resolved}] {' '.join(command)}")
        result = subprocess.run(command, cwd=repo, check=False)
        if result.returncode != 0:
            print(
                f"{RED}✗{NC} [{resolved}] command failed with exit {result.returncode}"
            )
            return result.returncode or 1

    print(f"{GREEN}✓{NC} [{resolved}] sync complete")
    return 0


def run_razorpush(
    workspace: Path,
    cwd: Path,
    *,
    app: str | None,
    dry_run: bool,
    set_upstream: bool,
) -> int:
    """Push one repo only after strict safety checks."""
    apps_root = _apps_root(workspace)
    resolved, error = _resolve_single_app(
        apps_root, cwd, app, command_name="razorpushapp"
    )
    if error:
        print(error)
        return 1
    assert resolved is not None

    repo = _app_path(apps_root, resolved)
    state = collect_repo_state(resolved, repo)
    reasons = _push_precheck(state, set_upstream=set_upstream)
    if reasons:
        _print_reasons(resolved, reasons)
        return 1

    if state.ahead == 0:
        print(f"{YELLOW}⚠{NC} [{resolved}] nothing to push")
        return 0

    if not dry_run and not require_git_mutation_allowed(
        "push project changes", lambda msg: print(f"{RED}✗{NC} {msg}")
    ):
        return 1

    if dry_run:
        print(f"[{resolved}] dry-run")
        if set_upstream and not state.upstream_exists:
            print(f"  git push --set-upstream origin {state.branch}")
        else:
            print("  git push")
        return 0

    if set_upstream and not state.upstream_exists:
        command = ["git", "push", "--set-upstream", "origin", state.branch]
    else:
        command = ["git", "push"]

    print(f"{CYAN}→{NC} [{resolved}] {' '.join(command)}")
    result = subprocess.run(command, cwd=repo, check=False)
    if result.returncode != 0:
        print(f"{RED}✗{NC} [{resolved}] push failed (exit {result.returncode})")
        return result.returncode or 1

    print(f"{GREEN}✓{NC} [{resolved}] push complete")
    return 0


def _repo_has_changes(state: RepoState) -> bool:
    if state.staged or state.unstaged or state.untracked:
        return True
    if (state.ahead or 0) > 0:
        return True
    if (state.behind or 0) > 0:
        return True
    return False


def _collect_states(apps_root: Path) -> list[RepoState]:
    return [
        collect_repo_state(app, _app_path(apps_root, app)) for app in _managed_apps()
    ]


def run_razorgit(
    workspace: Path,
    *,
    mode: str,
    changed_only: bool,
    dry_run: bool,
    confirm: bool,
) -> int:
    """Workspace-aware multi-repo Git sweeper with safe defaults."""
    command_by_mode = {
        "status": "razorgitstatus",
        "sync": "razorgitsync",
        "push": "razorgitpush",
        "sync-push": "razorgitsyncpush",
    }
    apps_root = _apps_root(workspace)
    states = _collect_states(apps_root)

    if mode == "status":
        _print_summary(states)
        return 0

    if mode in {"push", "sync-push"} and not confirm and not dry_run:
        one_word = command_by_mode.get(mode, "razorgit")
        print(f"{RED}✗{NC} Refusing {mode} without --confirm")
        print(f"Run: {one_word} --changed-only --dry-run")
        print(f"Then: {one_word} --changed-only --confirm")
        return 1

    if mode == "sync" and not confirm and not dry_run:
        print(f"{RED}✗{NC} Refusing sync without --confirm (or --dry-run)")
        print("Run: razorgitsync --changed-only --dry-run")
        print("Then: razorgitsync --changed-only --confirm")
        return 1

    failures = 0

    for state in states:
        if changed_only and not _repo_has_changes(state):
            print(f"{CYAN}→{NC} [{state.app}] skipped (no changes)")
            continue

        if mode == "sync":
            reasons = _sync_precheck(state)
            if reasons:
                _print_reasons(state.app, reasons)
                failures += 1
                continue
            if dry_run:
                print(
                    f"[{state.app}] dry-run: git fetch --prune && git pull --rebase --autostash"
                )
                continue
            sync_result = run_razorsync(
                apps_root, apps_root, app=state.app, dry_run=False
            )
            if sync_result != 0:
                failures += 1
            continue

        if mode == "push":
            reasons = _push_precheck(state, set_upstream=False)
            if reasons:
                _print_reasons(state.app, reasons)
                failures += 1
                continue
            if dry_run:
                print(f"[{state.app}] dry-run: git push")
                continue
            push_result = run_razorpush(
                apps_root,
                apps_root,
                app=state.app,
                dry_run=False,
                set_upstream=False,
            )
            if push_result != 0:
                failures += 1
            continue

        if mode == "sync-push":
            sync_reasons = _sync_precheck(state)
            if sync_reasons:
                _print_reasons(state.app, sync_reasons)
                failures += 1
                continue

            if dry_run:
                # sync-push may clear "behind remote", so ignore that dry-run-only blocker.
                push_dry_reasons = [
                    reason
                    for reason in _push_precheck(state, set_upstream=False)
                    if reason != "branch is behind remote"
                ]
                if push_dry_reasons:
                    _print_reasons(state.app, push_dry_reasons)
                    failures += 1
                    continue
                print(
                    f"[{state.app}] dry-run: git fetch --prune && git pull --rebase --autostash && git push"
                )
                continue

            sync_result = run_razorsync(
                apps_root, apps_root, app=state.app, dry_run=False
            )
            if sync_result != 0:
                failures += 1
                continue

            refreshed = collect_repo_state(state.app, state.path)
            push_reasons = _push_precheck(refreshed, set_upstream=False)
            if push_reasons:
                _print_reasons(state.app, push_reasons)
                failures += 1
                continue

            push_result = run_razorpush(
                apps_root,
                apps_root,
                app=state.app,
                dry_run=False,
                set_upstream=False,
            )
            if push_result != 0:
                failures += 1
            continue

    return 1 if failures else 0


def run_legacy_pushapps(
    workspace: Path,
    *,
    dry_run: bool,
    confirm: bool,
) -> int:
    """Compatibility wrapper for pushapps -> razorgitpush."""
    print("pushapps is deprecated.")
    print("Use:")
    print("  razorgitpush --changed-only --dry-run")
    print("  razorgitpush --changed-only --confirm")
    return run_razorgit(
        workspace,
        mode="push",
        changed_only=True,
        dry_run=dry_run,
        confirm=confirm,
    )
