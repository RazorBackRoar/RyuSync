"""CLI entry points for RazorBackRoar ecosystem commands."""

import argparse
import json
import os
import re
import shutil
import subprocess
from collections.abc import Callable
from pathlib import Path

from razorcore.cli import commands as cmd
from razorcore.cli import workspace_git as wgit


def _as_apps_dir(candidate: Path) -> Path | None:
    """Normalize a path candidate into an Apps directory when possible."""
    path = candidate.expanduser().resolve()

    if path.name == "Apps" and (path / ".razorcore").is_dir():
        return path

    if path.name == ".razorcore" and path.parent.name == "Apps":
        return path.parent

    if (path / ".razorcore").is_dir():
        return path

    nested_apps = path / "Apps"
    if (nested_apps / ".razorcore").is_dir():
        return nested_apps

    return None


def _candidate_paths() -> list[Path]:
    """Return candidate roots to discover the Apps directory."""
    candidates: list[Path] = []

    env_workspace = os.environ.get("RAZOR_WORKSPACE")
    if env_workspace:
        candidates.append(Path(env_workspace))

    cwd = Path.cwd()
    candidates.append(cwd)
    candidates.extend(cwd.parents)

    module_path = Path(__file__).resolve()
    candidates.extend(module_path.parents)

    home = Path.home()
    candidates.extend([home / "Workspace", home / "Desktop" / "Workspace", home])

    return candidates


def _find_razorguard_script(workspace: Path) -> Path | None:
    """Locate razorguard script across common workspace layouts."""
    candidates: list[Path] = [workspace / ".razorcore" / "razorguard"]

    if workspace.name == "Apps":
        candidates.append(workspace.parent / "razorguard")

    for root in _candidate_paths():
        apps = _as_apps_dir(root)
        if apps is not None:
            candidates.append(apps / ".razorcore" / "razorguard")
            candidates.append(apps.parent / "razorguard")

    for script in candidates:
        if script.is_file():
            return script

    return None


def _get_workspace() -> Path:
    """Resolve the canonical Apps workspace directory."""
    for candidate in _candidate_paths():
        apps_dir = _as_apps_dir(candidate)
        if apps_dir is not None:
            return apps_dir
    return Path.cwd()


def _exit_with_status(code: int | None = 0) -> None:
    """Exit console scripts with an explicit status code."""
    raise SystemExit(0 if code is None else code)


def _parse_no_args(description: str) -> None:
    """Parse CLI args for commands that intentionally accept no options."""
    parser = argparse.ArgumentParser(description=description)
    parser.parse_args()


def _parse_save_no_arg_args(description: str) -> argparse.Namespace:
    """Parse save commands that accept only optional flags."""
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument(
        "--no-skills-fix",
        action="store_true",
        help="Skip automatic .skills/skills link normalization before save.",
    )
    parser.add_argument(
        "--no-auto-bump",
        action="store_true",
        help="Skip automatic version bump after a successful save.",
    )
    parser.add_argument(
        "--no-format",
        action="store_true",
        help="Skip markdown autoformatting before commit.",
    )
    return parser.parse_args()


def _run_no_arg_command(description: str, action: Callable[[Path], int]) -> None:
    """Run a no-arg command after argument validation."""
    _parse_no_args(description)
    workspace = _get_workspace()
    _exit_with_status(action(workspace))


def _workspace_root_from_apps(workspace: Path) -> Path:
    """Resolve Workspace root from an Apps path when possible."""
    if workspace.name == "Apps":
        return workspace.parent
    return workspace


def _skills_link_dirs(workspace: Path) -> list[Path]:
    """Return roots that should expose a .skills symlink."""
    workspace_root = _workspace_root_from_apps(workspace)
    apps_root = workspace if workspace.name == "Apps" else workspace_root / "Apps"

    dirs = [
        workspace_root,
        workspace_root / "IDE",
        apps_root,
        workspace_root / "IDE" / "Codex",
        workspace_root / "IDE" / "Devin",
        workspace_root / "IDE" / "Antigravity",
        workspace_root / "IDE" / "OpenCode",
        apps_root / ".razorcore",
        apps_root / "4Charm",
        apps_root / "Nexus",
        apps_root / "RyuSync",
    ]

    deduped: list[Path] = []
    seen: set[Path] = set()
    for path in dirs:
        if path in seen:
            continue
        seen.add(path)
        deduped.append(path)
    return deduped


def _ensure_skills_links(workspace: Path) -> None:
    """Normalize .skills symlinks for workspace roots."""
    skills_canonical = _workspace_root_from_apps(workspace) / "Skills"
    targets = _skills_link_dirs(workspace)
    updated = 0

    for root in targets:
        if not root.is_dir():
            continue

        hidden = root / ".skills"

        if hidden.exists() and not hidden.is_symlink():
            print(f"⚠ Skipping non-symlink path: {hidden}")
            continue

        if hidden.is_symlink():
            if hidden.resolve() == skills_canonical:
                continue
            hidden.unlink()
        hidden.symlink_to(skills_canonical)
        updated += 1

    if updated:
        print(f"✓ Skills links normalized in {updated} location(s)")


def _run_save_entrypoint_with_precheck(
    action: Callable[[Path], int], *, no_skills_fix: bool = False
) -> None:
    """Run save workflow with skills-link normalization and razorguard pre-check."""
    workspace = _get_workspace()
    if no_skills_fix:
        print("→ Skipping skills-link normalization (--no-skills-fix)")
    else:
        _ensure_skills_links(workspace)
    precheck_status = _run_razorguard_precheck(workspace)
    if precheck_status != 0:
        _exit_with_status(precheck_status)
    _exit_with_status(action(workspace))


def _run_razorguard_precheck(workspace: Path) -> int:
    """Run razorguard workspace validation before save operations."""
    guard_script = _find_razorguard_script(workspace)

    if guard_script is None:
        expected = workspace / ".razorcore" / "razorguard"
        print(f"Error: razorguard file not found at {expected}")
        print("Error: could not locate razorguard via fallback search paths.")
        print("Hint: set RAZOR_WORKSPACE=/Users/home/Workspace for all IDE shells.")
        print("Aborting save flow. Restore razorguard or run checks manually.")
        return 1

    workspace_root = (
        guard_script.parent.parent.parent
        if guard_script.parent.name == ".razorcore"
        and guard_script.parent.parent.name == "Apps"
        else (workspace.parent if workspace.name == "Apps" else workspace)
    )

    if not guard_script.exists():
        print(f"Error: razorguard file not found at {guard_script}")
        print("Aborting save flow. Restore razorguard or run checks manually.")
        return 1

    print("→ Running razorguard pre-check...")
    result = subprocess.run(
        [
            str(guard_script),
            "check",
            "--workspace",
            str(workspace_root),
            "--no-color",
        ],
        capture_output=True,
        text=True,
    )

    if result.returncode != 0:
        print("❌ Razorguard checks failed:")
        print(result.stdout)
        print(result.stderr)
        print("Error: razorguard pre-check failed. Aborting save flow.")
        return result.returncode or 1

    print("✓ razorguard pre-check passed")
    return 0


# ==============================================================================
# SAVE COMMANDS
# ==============================================================================


def pushall():
    """Entry point for 'pushall'."""
    args = _parse_save_no_arg_args(
        "Save all managed projects. Requires RAZORCORE_ALLOW_GIT_MUTATION=1."
    )
    _run_save_entrypoint_with_precheck(cmd.push_all, no_skills_fix=args.no_skills_fix)


def razormax():
    """Entry point for 'razormax'."""
    args = _parse_save_no_arg_args(
        "Full workflow: sync configs, save all, verify health. "
        "Requires RAZORCORE_ALLOW_GIT_MUTATION=1."
    )
    _run_save_entrypoint_with_precheck(cmd.razormax, no_skills_fix=args.no_skills_fix)


def pushapps():
    """Compatibility wrapper for legacy pushapps."""
    parser = argparse.ArgumentParser(
        description=(
            "Deprecated compatibility wrapper. "
            "Use razorgitpush --changed-only --dry-run/--confirm."
        )
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Preview workspace push operations without mutating Git.",
    )
    parser.add_argument(
        "--confirm",
        action="store_true",
        help="Confirm workspace push operations.",
    )
    args = parser.parse_args()

    workspace = _get_workspace()
    _exit_with_status(
        wgit.run_legacy_pushapps(workspace, dry_run=args.dry_run, confirm=args.confirm)
    )


def _run_razorgit_mode_entry(
    mode: str,
    *,
    description: str,
) -> None:
    """Shared parser/runner for one-word razorgit mode wrappers."""
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument(
        "--changed-only",
        action="store_true",
        help="Operate only on repos with pending local/remote changes.",
    )
    parser.add_argument(
        "--all-repos",
        action="store_true",
        help="Disable changed-only filtering for mutating modes.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Preview mutating commands without applying changes.",
    )
    parser.add_argument(
        "--confirm",
        action="store_true",
        help="Confirm mutating workspace operations.",
    )
    args = parser.parse_args()

    workspace = _get_workspace()
    changed_only = args.changed_only or (
        mode in {"sync", "push", "sync-push"} and not args.all_repos
    )
    _exit_with_status(
        wgit.run_razorgit(
            workspace,
            mode=mode,
            changed_only=changed_only,
            dry_run=args.dry_run,
            confirm=args.confirm,
        )
    )


def razorgitstatus():
    """One-word wrapper for workspace Git status sweep."""
    _run_razorgit_mode_entry(
        "status",
        description="Read-only workspace Git status summary.",
    )


def razorgitsync():
    """One-word wrapper for workspace Git sync sweep."""
    _run_razorgit_mode_entry(
        "sync",
        description="Workspace Git sync sweep (safe, confirmation-gated).",
    )


def razorgitpush():
    """One-word wrapper for workspace Git push sweep."""
    _run_razorgit_mode_entry(
        "push",
        description="Workspace Git push sweep (safe, confirmation-gated).",
    )


def razorgitsyncpush():
    """One-word wrapper for workspace Git sync+push sweep."""
    _run_razorgit_mode_entry(
        "sync-push",
        description="Workspace Git sync+push sweep (safe, confirmation-gated).",
    )


def razorpushall():
    """One-word compatibility alias for workspace push sweep."""
    razorgitpush()


def razortestall():
    """One-word wrapper for testing all managed app repos."""
    _parse_no_args("Run ruff/ty/pytest across all managed app repositories.")
    workspace = _get_workspace()
    _exit_with_status(
        wgit.run_razortest(
            workspace,
            Path.cwd(),
            app=None,
            all_repos=True,
        )
    )


def pushsafe():
    """Entry point for 'pushsafe'."""
    args = _parse_save_no_arg_args(
        "Safe save mode (no version bump, tags, or docs updates). "
        "Requires RAZORCORE_ALLOW_GIT_MUTATION=1."
    )
    _run_save_entrypoint_with_precheck(
        cmd.save_all_safe, no_skills_fix=args.no_skills_fix
    )


def pruneall():
    """Entry point for 'pruneall' - prune stale branches across all projects."""
    _run_no_arg_command(
        "Prune stale remote-tracking refs and delete merged local branches. "
        "Requires RAZORCORE_ALLOW_GIT_MUTATION=1.",
        cmd.prune_all,
    )


def razorworktrees():
    """Entry point for 'razorworktrees' - remove detached worktrees."""
    _run_no_arg_command(
        "Remove detached git worktrees created by Codex or Devin. "
        "Requires RAZORCORE_ALLOW_GIT_MUTATION=1.",
        cmd.prune_worktrees,
    )


def razorpush():
    """Entry point for safe single-repo push behavior."""
    parser = argparse.ArgumentParser(
        description="Push one managed app repo only after strict safety checks."
    )
    parser.add_argument(
        "--app",
        help="Target app name (e.g. Nexus). If omitted, current repo must be inside one managed app.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Preview push command without mutating Git.",
    )
    parser.add_argument(
        "--set-upstream",
        action="store_true",
        help="Allow initial push with upstream creation when no upstream exists.",
    )
    args = parser.parse_args()

    workspace = _get_workspace()
    _exit_with_status(
        wgit.run_razorpush(
            workspace,
            Path.cwd(),
            app=args.app,
            dry_run=args.dry_run,
            set_upstream=args.set_upstream,
        )
    )


def charm_push():
    """Entry point for '4charmpush'."""
    args = _parse_save_no_arg_args(
        "Save and push 4Charm. Requires RAZORCORE_ALLOW_GIT_MUTATION=1."
    )
    _run_save_entrypoint_with_precheck(
        lambda workspace: cmd.save_project(
            workspace,
            "4Charm",
            auto_bump=not args.no_auto_bump,
            run_autoformat=not args.no_format,
        ),
        no_skills_fix=args.no_skills_fix,
    )


def nexus_push():
    """Entry point for 'nexuspush'."""
    args = _parse_save_no_arg_args(
        "Save and push Nexus. Requires RAZORCORE_ALLOW_GIT_MUTATION=1."
    )
    _run_save_entrypoint_with_precheck(
        lambda workspace: cmd.save_project(
            workspace,
            "Nexus",
            auto_bump=not args.no_auto_bump,
            run_autoformat=not args.no_format,
        ),
        no_skills_fix=args.no_skills_fix,
    )


def charmbuild():
    """Entry point for '4charmbuild'."""
    _run_no_arg_command(
        "Build 4Charm app artifacts.",
        lambda workspace: cmd.build_project(workspace, "4Charm"),
    )


def nexusbuild():
    """Entry point for 'nexusbuild'."""
    _run_no_arg_command(
        "Build Nexus app artifacts.",
        lambda workspace: cmd.build_project(workspace, "Nexus"),
    )


def rustybuild():
    """Entry point for 'rustybuild'."""
    _run_no_arg_command(
        "Build Rusty app artifacts.",
        lambda workspace: cmd.build_project(workspace, "Rusty"),
    )


def ryusyncbuild():
    """Entry point for 'ryusyncbuild'."""
    _run_no_arg_command(
        "Build RyuSync app artifacts.",
        lambda workspace: cmd.build_project(workspace, "RyuSync"),
    )


# ==============================================================================
# VERIFICATION & SYNC
# ==============================================================================


def razorcheck():
    """Entry point for read-only app/workspace status checks."""
    parser = argparse.ArgumentParser(
        description="Read-only health/status check for one app or all managed apps."
    )
    parser.add_argument("--app", help="Check one app by name.")
    parser.add_argument(
        "--all",
        action="store_true",
        help="Force full managed-app summary even when inside one app repo.",
    )
    args = parser.parse_args()

    workspace = _get_workspace()
    _exit_with_status(
        wgit.run_razorcheck(
            workspace,
            Path.cwd(),
            app=args.app,
            all_repos=args.all,
        )
    )


def razorcheckall():
    """Entry point for 'razorcheckall'."""
    _parse_no_args("Run local quality checks across all managed repositories.")
    workspace = _get_workspace()
    quality_status = cmd.check_all_repos_quality(workspace)
    baseline_status = cmd.verify_app_baseline(workspace)
    _exit_with_status(1 if (quality_status != 0 or baseline_status != 0) else 0)


def razorhealth():
    """Entry point for 'razorhealth'."""
    parser = argparse.ArgumentParser(description="Run workspace health checks.")
    parser.add_argument(
        "--no-strict",
        action="store_true",
        help="Do not fail on warnings (strict mode is default)",
    )
    args = parser.parse_args()

    workspace = _get_workspace()
    _exit_with_status(cmd.verify(workspace, strict=not args.no_strict))


def razornewapp():
    """Entry point for 'razornewapp <project>'."""
    parser = argparse.ArgumentParser(
        description=(
            "Bootstrap a new app repository with CI, README badges, LICENSE, "
            "and RazorBackRoar GitHub metadata."
        )
    )
    parser.add_argument("project", help="Project folder name under Apps/")
    parser.add_argument(
        "--module",
        help="Python module name for README run command (auto-derived by default)",
    )
    parser.add_argument(
        "--tagline",
        help="One-line README/GitHub description override",
    )
    parser.add_argument(
        "--dry-run", action="store_true", help="Preview planned baseline changes"
    )
    parser.add_argument(
        "--force-readme",
        action="store_true",
        help="Overwrite README.md with the RazorBackRoar scaffold",
    )
    parser.add_argument(
        "--skip-github",
        action="store_true",
        help="Skip gh repo edit (description, topics, homepage, wiki)",
    )
    args = parser.parse_args()

    workspace = _get_workspace()
    _exit_with_status(
        cmd.bootstrap_app_baseline(
            workspace,
            args.project,
            module_name=args.module,
            dry_run=args.dry_run,
            force_readme=args.force_readme,
            skip_github=args.skip_github,
            tagline=args.tagline,
        )
    )


def razorgithub():
    """Entry point for 'razorgithub <project>'."""
    parser = argparse.ArgumentParser(
        description="Apply RazorBackRoar GitHub metadata to an existing app repo."
    )
    parser.add_argument("project", help="Project folder name under Apps/")
    parser.add_argument(
        "--tagline",
        help="One-line GitHub description override",
    )
    parser.add_argument(
        "--dry-run", action="store_true", help="Preview gh commands only"
    )
    args = parser.parse_args()

    workspace = _get_workspace()
    _exit_with_status(
        cmd.polish_github_repo(
            workspace,
            args.project,
            tagline=args.tagline,
            dry_run=args.dry_run,
        )
    )


def razorappcheck():
    """Entry point for 'razorappcheck [projects...]'."""
    parser = argparse.ArgumentParser(
        description="Fail when app CI/README baseline drifts from policy."
    )
    parser.add_argument(
        "projects",
        nargs="*",
        help="Optional project names (defaults to all .razorcore-enabled repos)",
    )
    args = parser.parse_args()

    workspace = _get_workspace()
    _exit_with_status(
        cmd.verify_app_baseline(workspace, projects=args.projects or None)
    )


def razorvendor():
    """Entry point for 'razorvendor [--dry-run]'."""
    parser = argparse.ArgumentParser(
        description=(
            "Build razorcore and refresh ci/vendor wheels in public Python apps."
        )
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Preview wheel refresh without writing files",
    )
    args = parser.parse_args()

    workspace = _get_workspace()
    _exit_with_status(
        cmd.refresh_ci_vendor_wheels(workspace, dry_run=args.dry_run)
    )


def razortest():
    """Entry point for Python lint/type/test checks."""
    parser = argparse.ArgumentParser(
        description="Run ruff/ty/pytest for one app or all managed apps."
    )
    parser.add_argument("--app", help="Run checks for one app.")
    parser.add_argument(
        "--all",
        action="store_true",
        help="Run checks across all managed app repos.",
    )
    args = parser.parse_args()

    workspace = _get_workspace()
    _exit_with_status(
        wgit.run_razortest(
            workspace,
            Path.cwd(),
            app=args.app,
            all_repos=args.all,
        )
    )


def razorsync():
    """Entry point for safe single-repo sync behavior."""
    parser = argparse.ArgumentParser(
        description="Sync one managed app repo only (git fetch/pull --rebase --autostash)."
    )
    parser.add_argument(
        "--app",
        help="Target app name. If omitted, current directory must be inside one managed app repo.",
    )
    parser.add_argument("--dry-run", action="store_true", help="Preview sync commands.")
    args = parser.parse_args()

    workspace = _get_workspace()
    _exit_with_status(
        wgit.run_razorsync(
            workspace,
            Path.cwd(),
            app=args.app,
            dry_run=args.dry_run,
        )
    )


def razorgit():
    """Entry point for safe multi-repo Git status/sync/push sweeps."""
    parser = argparse.ArgumentParser(
        description=(
            "Workspace Git sweeper. Default mode is read-only status. "
            "Mutating modes require explicit confirmation."
        )
    )
    parser.add_argument(
        "mode",
        nargs="?",
        default="status",
        choices=["status", "sync", "push", "sync-push"],
        help="Operation mode (default: status).",
    )
    parser.add_argument(
        "--changed-only",
        action="store_true",
        help="Operate only on repos with pending local/remote changes.",
    )
    parser.add_argument(
        "--all-repos",
        action="store_true",
        help="Disable changed-only filtering for mutating modes.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Preview mutating commands without applying changes.",
    )
    parser.add_argument(
        "--confirm",
        action="store_true",
        help="Confirm mutating workspace operations.",
    )
    args = parser.parse_args()

    workspace = _get_workspace()
    changed_only = args.changed_only or (
        args.mode in {"sync", "push", "sync-push"} and not args.all_repos
    )
    _exit_with_status(
        wgit.run_razorgit(
            workspace,
            mode=args.mode,
            changed_only=changed_only,
            dry_run=args.dry_run,
            confirm=args.confirm,
        )
    )


def razorall():
    """Compatibility wrapper: razorall forwards directly to razorgit."""
    razorgit()


def syncall():
    """Entry point for 'syncall' — sync toolchain configs to all locations.

    Deploys .vscode/settings.json and pyrightconfig.json to:
      - App projects: 4Charm, Nexus, RyuSync, .razorcore
      - Sandbox roots: IDE/Codex, IDE/Devin, IDE/Antigravity, IDE/OpenCode (local git, no remote)
    """
    workspace = _get_workspace()
    _exit_with_status(cmd.sync_all(workspace))


def razoragents():
    """Entry point for 'razoragents'."""
    parser = argparse.ArgumentParser(
        description="Sync AGENTS.md docs and SSOT version section."
    )
    parser.add_argument("--dry-run", action="store_true", help="Preview changes")
    args = parser.parse_args()

    workspace = _get_workspace()
    statuses = (
        cmd.sync_docs(workspace, dry_run=args.dry_run),
        cmd.sync_project_agent_versions(workspace, dry_run=args.dry_run),
        cmd.sync_ssot_versions(workspace, dry_run=args.dry_run),
    )
    _exit_with_status(1 if any(status != 0 for status in statuses) else 0)


def razorcommit():
    """Entry point for 'razorcommit <message>'."""
    parser = argparse.ArgumentParser(
        description="Commit to all projects. Requires RAZORCORE_ALLOW_GIT_MUTATION=1."
    )
    parser.add_argument("message", help="Commit message")
    args = parser.parse_args()

    workspace = _get_workspace()
    _exit_with_status(cmd.commit_all(workspace, args.message))


def razorbump():
    """Entry point for 'razorbump <project>'."""
    parser = argparse.ArgumentParser(
        description=(
            "Auto-bump a project's version. Requires "
            "RAZORCORE_ALLOW_GIT_MUTATION=1 unless --dry-run is used."
        )
    )
    parser.add_argument(
        "project",
        help="Project name (e.g. 4Charm, Nexus, RyuSync)",
    )
    parser.add_argument("--dry-run", action="store_true", help="Preview version bump")
    args = parser.parse_args()

    workspace = _get_workspace()
    _exit_with_status(cmd.bump_version(workspace, args.project, dry_run=args.dry_run))


def update():
    """Entry point for 'update one|two|three' inside an app repo."""
    parser = argparse.ArgumentParser(
        description=(
            "Manual semantic version bump for the current app repository: "
            "one=major, two=minor, three=patch."
        )
    )
    parser.add_argument("selector", help="one | two | three")
    parser.add_argument(
        "--allow-dirty",
        action="store_true",
        help="Allow running in a dirty repo (default: refuse).",
    )
    parser.add_argument(
        "--allow-repeat",
        action="store_true",
        help="Allow repeating the same selector bump on the current version.",
    )
    args = parser.parse_args()

    _exit_with_status(
        cmd.update_version_by_selector(
            Path.cwd(),
            args.selector,
            allow_dirty=args.allow_dirty,
            allow_repeat=args.allow_repeat,
        )
    )


def release():
    """Entry point for 'release' from inside a managed app repo."""
    parser = argparse.ArgumentParser(
        description=(
            "Publish the current app's DMG to GitHub Release v<version> "
            "using pyproject.toml version and standard release notes."
        )
    )
    parser.add_argument(
        "--app",
        help="Optional app name. If omitted, detect from current directory.",
    )
    parser.add_argument(
        "--allow-dirty",
        action="store_true",
        help="Allow release from dirty repository (default: refuse).",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Print release inputs and record a dry-run activity event only.",
    )
    args = parser.parse_args()

    workspace = _get_workspace()
    app = args.app
    if not app:
        current = Path.cwd().resolve()
        for candidate in cmd.MANAGED_APP_PROJECTS:
            repo_path = (workspace / candidate).resolve()
            if current == repo_path or repo_path in current.parents:
                app = candidate
                break

    if not app:
        parser.error(
            "Could not detect app from current directory. "
            "Run inside an app repo or provide --app."
        )

    app = cmd.resolve_project_name(app)
    from razorcore.cli.release import publish_release

    _exit_with_status(
        publish_release(
            workspace,
            app,
            allow_dirty=args.allow_dirty,
            dry_run=args.dry_run,
        )
    )


def razorhooks():
    """Entry point for 'razorhooks [projects...]'."""
    parser = argparse.ArgumentParser(
        description=(
            "Install post-commit hooks for one or more projects. Requires "
            "RAZORCORE_ALLOW_GIT_MUTATION=1."
        )
    )
    parser.add_argument("projects", nargs="*", help="Optional project names")
    args = parser.parse_args()

    workspace = _get_workspace()
    _exit_with_status(cmd.install_hooks(workspace, projects=args.projects or None))


def razorlist():
    """Entry point for 'razorlist'."""
    _run_no_arg_command("List managed projects and status.", cmd.list_projects)


def razorconfig():
    """Entry point for 'razorconfig [project]'."""
    parser = argparse.ArgumentParser(description="Sync shared configuration files.")
    parser.add_argument("project", nargs="?", help="Optional project name")
    parser.add_argument("--dry-run", action="store_true", help="Preview config changes")
    parser.add_argument(
        "--with-pyproject",
        action="store_true",
        help="Also sync pyproject.toml (can overwrite app metadata/version)",
    )
    parser.add_argument(
        "--with-vscode-tasks",
        action="store_true",
        help="Also sync .vscode/tasks.json into each project",
    )
    args = parser.parse_args()

    workspace = _get_workspace()
    projects = [args.project] if args.project else None
    _exit_with_status(
        cmd.sync_configs(
            workspace,
            projects=projects,
            dry_run=args.dry_run,
            include_pyproject=args.with_pyproject,
            include_vscode_tasks=args.with_vscode_tasks,
        )
    )


# ==============================================================================
# BUILD
# ==============================================================================


def _reinstall_razorcore_cli(workspace: Path) -> int:
    """Reinstall razorcore CLI in editable mode."""
    razorcore_dir = workspace / ".razorcore"

    if not razorcore_dir.exists():
        print(f"Error: .razorcore directory not found at {razorcore_dir}")
        return 1

    print("→ Reinstalling razorcore via uv sync...")
    try:
        subprocess.run(
            ["uv", "sync", "--reinstall-package", "razorcore"],
            cwd=razorcore_dir,
            check=True,
        )
    except subprocess.CalledProcessError as exc:
        print(f"Error: Razorcore CLI reinstall failed: {exc}")
        return exc.returncode or 1

    print("✓ RazorCore CLI reinstalled successfully")
    return 0


def razorbuild():
    """Entry point for 'razorbuild <project>'."""
    parser = argparse.ArgumentParser(
        description=("Build registered app artifacts without creating tags or pushing.")
    )
    parser.add_argument(
        "project",
        nargs="?",
        help="Buildable project name (e.g. 4Charm, Nexus, RyuSync, Rusty)",
    )
    parser.add_argument(
        "--reinstall-cli",
        action="store_true",
        help="Reinstall razorcore CLI instead of building app artifacts",
    )
    args = parser.parse_args()

    workspace = _get_workspace()
    if args.reinstall_cli:
        _exit_with_status(_reinstall_razorcore_cli(workspace))

    if not args.project:
        parser.error("project is required unless --reinstall-cli is provided")

    _exit_with_status(cmd.build_project(workspace, args.project))


# ==============================================================================
# BOLT PERFORMANCE AGENT
# ==============================================================================


def bolt():
    """Entry point for 'bolt'."""
    _run_no_arg_command("Activate Bolt performance agent.", cmd.bolt_command)


def journal():
    """Entry point for 'journal'."""
    _run_no_arg_command("Open Bolt performance journal.", cmd.journal_command)


def baseline():
    """Entry point for 'baseline'."""
    parser = argparse.ArgumentParser(description="Measure performance baseline.")
    parser.add_argument(
        "--save", action="store_true", help="Save current metrics as baseline"
    )
    parser.add_argument(
        "--compare", action="store_true", help="Compare against saved baseline"
    )
    args = parser.parse_args()

    workspace = _get_workspace()
    _exit_with_status(
        cmd.baseline_command(workspace, save=args.save, compare=args.compare)
    )


def cleanup():
    """Entry point for 'cleanup' - remove cache and temporary files."""
    parser = argparse.ArgumentParser(
        description="Clean up cache and temporary files from workspace."
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be removed without actually deleting",
    )
    parser.add_argument("--force", action="store_true", help="Skip confirmation prompt")
    parser.add_argument(
        "--recursive",
        action="store_true",
        help="Also clean matching files from project subdirectories",
    )
    args = parser.parse_args()

    workspace = _get_workspace()

    # Files and directories to clean up
    cleanup_targets = [
        ".pytest_cache",
        ".ruff_cache",
        ".hypothesis",
        ".venv",
        ".logs",
        ".archive",
        "Icon",
        ".DS_Store",
    ]

    removed_count = 0
    total_size = 0

    print(f"🧹 Cleaning workspace: {workspace}")
    print()

    search_roots = [workspace]
    if args.recursive:
        search_roots.extend(
            child
            for child in sorted(workspace.iterdir())
            if child.is_dir() and (child / "pyproject.toml").exists()
        )

    for root in search_roots:
        for target in cleanup_targets:
            target_path = root / target

            if not target_path.exists():
                continue

            display_target = str(target_path.relative_to(workspace))

            if target_path.is_dir():
                size = sum(
                    f.stat().st_size for f in target_path.rglob("*") if f.is_file()
                )
            else:
                size = target_path.stat().st_size

            total_size += size

            if args.dry_run:
                print(f"  📋 Would remove: {display_target} ({_format_size(size)})")
                removed_count += 1
            else:
                if not args.force:
                    response = input(
                        f"  Remove {display_target}? ({_format_size(size)}) [y/N]: "
                    )
                    if response.lower() not in ["y", "yes"]:
                        print(f"  ⏭️  Skipped: {display_target}")
                        continue

                try:
                    if target_path.is_dir():
                        shutil.rmtree(target_path)
                    else:
                        target_path.unlink()
                    print(f"  ✅ Removed: {display_target} ({_format_size(size)})")
                    removed_count += 1
                except Exception as e:
                    print(f"  ❌ Failed to remove {display_target}: {e}")

    print()
    if args.dry_run:
        print(
            f"📋 Dry run: Would remove {removed_count} items ({_format_size(total_size)})"
        )
        print("   Run 'cleanup --force' to actually remove these files.")
    else:
        print(
            f"✨ Cleanup complete: Removed {removed_count} items ({_format_size(total_size)})"
        )
        print("   Caches will regenerate automatically when needed.")


def _format_size(size_bytes: int | float) -> str:
    """Format bytes in human readable format."""
    for unit in ["B", "KB", "MB", "GB"]:
        if size_bytes < 1024.0:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024.0
    return f"{size_bytes:.1f} TB"


_SECRET_NAME_MARKERS = ("TOKEN", "KEY", "SECRET", "PASSWORD", "AUTH", "PAT")
_PROVIDER_MARKERS = (
    "GITHUB",
    "GH_",
    "MCP",
    "OPENAI",
    "CONTEXT7",
    "ANTHROPIC",
    "GOOGLE",
    "VERCEL",
    "GITLAB",
    "BITBUCKET",
)


def _looks_sensitive_name(name: str) -> bool:
    """Return True when an env-var style name looks credential-related."""
    upper = name.upper()
    if upper in {"PATH", "PYTHONPATH", "HOME", "SHELL", "PWD", "TERM"}:
        return False
    return bool(
        re.search(
            r"(?:^|_)(TOKEN|KEY|SECRET|PASSWORD|AUTH|PAT)(?:_|$)",
            upper,
        )
    )


def _has_provider_marker(name: str) -> bool:
    """Return True when name matches common auth provider prefixes."""
    upper = name.upper()
    return any(marker in upper for marker in _PROVIDER_MARKERS)


def _mask_secret(value: str) -> str:
    """Mask sensitive values while preserving enough context for validation."""
    if not value:
        return "-"
    if len(value) <= 8:
        return "*" * len(value)
    return f"{value[:4]}...{value[-4:]}"


def _parse_zshrc_credentials(zshrc_path: Path) -> dict[str, str]:
    """Extract credential-like env assignments from ~/.zshrc."""
    if not zshrc_path.exists():
        return {}

    assignment_re = re.compile(
        r"^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$"
    )
    credentials: dict[str, str] = {}

    for raw_line in zshrc_path.read_text(
        encoding="utf-8", errors="replace"
    ).splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        match = assignment_re.match(raw_line)
        if not match:
            continue

        name, value = match.group(1), match.group(2).strip()
        if not _looks_sensitive_name(name):
            continue

        if len(value) >= 2 and value[0] in {'"', "'"} and value[-1] == value[0]:
            value = value[1:-1]
        credentials[name] = value

    return credentials


def _extract_mcp_env_refs(mcp_config_path: Path) -> set[str]:
    """Extract referenced credential env vars from MCP config placeholders."""
    if not mcp_config_path.exists():
        return set()

    text = mcp_config_path.read_text(encoding="utf-8", errors="replace")
    refs = {
        name
        for name in re.findall(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}", text)
        if _looks_sensitive_name(name)
    }

    try:
        config = json.loads(text)
    except json.JSONDecodeError:
        return refs

    def _walk(node: object) -> None:
        if isinstance(node, dict):
            for key, value in node.items():
                if isinstance(key, str) and _looks_sensitive_name(key):
                    refs.add(key)
                _walk(value)
        elif isinstance(node, list):
            for item in node:
                _walk(item)

    _walk(config)
    return refs


def razorkey():
    """Entry point for 'razorkey' - inspect shell + MCP auth key references."""
    parser = argparse.ArgumentParser(
        description=(
            "Show ~/.zshrc and summarize GitHub/MCP-related keys or auth tokens."
        )
    )
    parser.add_argument(
        "--show-values",
        action="store_true",
        help="Show full values (default is masked output).",
    )
    parser.add_argument(
        "--no-zshrc",
        action="store_true",
        help="Skip printing ~/.zshrc contents.",
    )
    args = parser.parse_args()

    home = Path.home()
    zshrc_path = home / ".zshrc"
    mcp_config_path = home / ".mcp" / "config.json"

    if not args.no_zshrc:
        print(f"=== {zshrc_path} ===")
        if zshrc_path.exists():
            print(zshrc_path.read_text(encoding="utf-8", errors="replace"))
        else:
            print("(missing)")
        print()

    zshrc_credentials = _parse_zshrc_credentials(zshrc_path)
    mcp_refs = _extract_mcp_env_refs(mcp_config_path)
    env_refs = {
        name
        for name in os.environ
        if _looks_sensitive_name(name) and _has_provider_marker(name)
    }

    all_names = sorted(set(zshrc_credentials) | mcp_refs | env_refs)

    print(f"=== Credential Summary ({mcp_config_path}) ===")
    if not all_names:
        print("No credential-like keys detected.")
        _exit_with_status(0)

    for name in all_names:
        sources: list[str] = []
        if name in zshrc_credentials:
            sources.append("zshrc")
        if name in mcp_refs:
            sources.append("mcp")
        if name in os.environ:
            sources.append("env")

        value = os.environ.get(name, zshrc_credentials.get(name, ""))
        status = "set" if value else "unset"
        rendered_value = value if args.show_values else _mask_secret(value)
        print(
            f"- {name} | status={status} | source={','.join(sources) or 'unknown'} | "
            f"value={rendered_value}"
        )

    _exit_with_status(0)


def review_branch():
    """Entry point for 'review' - review current branch and keep it updated."""
    parser = argparse.ArgumentParser(
        description="Review current branch and optionally update it."
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Run checks and status reporting only; do not merge or push",
    )
    args = parser.parse_args()

    workspace = _get_workspace()
    script_path = workspace / ".razorcore" / "scripts" / "review-branch.sh"

    if not script_path.exists():
        print(f"❌ Review script not found: {script_path}")
        _exit_with_status(1)

    try:
        # Change to the current git repository directory
        cwd = Path.cwd()
        inside_repo = subprocess.run(
            ["git", "rev-parse", "--is-inside-work-tree"],
            cwd=cwd,
            capture_output=True,
            text=True,
            check=False,
        )
        if inside_repo.returncode != 0 or inside_repo.stdout.strip() != "true":
            print("❌ Not in a git repository")
            _exit_with_status(1)

        # Run the review script
        command = [str(script_path)]
        if args.dry_run:
            command.append("--dry-run")

        result = subprocess.run(
            command,
            cwd=cwd,
            text=True,
            check=False,
            timeout=300,  # 5 minute timeout
        )

        _exit_with_status(result.returncode)

    except subprocess.TimeoutExpired:
        print("❌ Review script timed out after 5 minutes")
        _exit_with_status(1)
    except Exception as e:
        print(f"❌ Error running review script: {e}")
        _exit_with_status(1)
