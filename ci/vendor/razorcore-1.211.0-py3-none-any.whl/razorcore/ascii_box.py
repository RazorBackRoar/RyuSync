"""Shared ASCII box formatting helpers."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any


DEFAULT_CHECKLIST_ITEMS = (
    "[ ] No emojis as icons (use SVG: Heroicons/Lucide)",
    "[ ] cursor-pointer on all clickable elements",
    "[ ] Hover states with smooth transitions (150-300ms)",
    "[ ] Light mode: text contrast 4.5:1 minimum",
    "[ ] Focus states visible for keyboard nav",
    "[ ] prefers-reduced-motion respected",
    "[ ] Responsive: 375px, 768px, 1024px, 1440px",
)


def _wrap_text(text: str, prefix: str, width: int) -> list[str]:
    """Wrap long text into multiple lines."""
    if not text:
        return []
    words = text.split()
    lines: list[str] = []
    current_line = prefix
    for word in words:
        if len(current_line) + len(word) + 1 <= width - 2:
            current_line += (" " if current_line != prefix else "") + word
        else:
            if current_line != prefix:
                lines.append(current_line)
            current_line = prefix + word
    if current_line != prefix:
        lines.append(current_line)
    return lines


def format_design_system_ascii_box(
    design_system: Mapping[str, Any],
    *,
    box_width: int = 90,
    checklist_items: Sequence[str] = DEFAULT_CHECKLIST_ITEMS,
) -> str:
    """Format design system data as an ASCII box report."""
    project = str(design_system.get("project_name", "PROJECT"))
    pattern = dict(design_system.get("pattern", {}))
    style = dict(design_system.get("style", {}))
    colors = dict(design_system.get("colors", {}))
    typography = dict(design_system.get("typography", {}))
    effects = str(design_system.get("key_effects", ""))
    anti_patterns = str(design_system.get("anti_patterns", ""))

    sections = str(pattern.get("sections", "")).split(">")
    sections = [section.strip() for section in sections if section.strip()]

    lines: list[str] = []
    width_minus_one = box_width - 1

    lines.append("+" + "-" * width_minus_one + "+")
    lines.append(
        f"|  TARGET: {project} - RECOMMENDED DESIGN SYSTEM".ljust(box_width) + "|"
    )
    lines.append("+" + "-" * width_minus_one + "+")
    lines.append("|" + " " * box_width + "|")

    lines.append(f"|  PATTERN: {pattern.get('name', '')}".ljust(box_width) + "|")
    if pattern.get("conversion"):
        lines.append(
            f"|     Conversion: {pattern.get('conversion', '')}".ljust(box_width) + "|"
        )
    if pattern.get("cta_placement"):
        lines.append(
            f"|     CTA: {pattern.get('cta_placement', '')}".ljust(box_width) + "|"
        )
    lines.append("|     Sections:".ljust(box_width) + "|")
    for i, section in enumerate(sections, 1):
        lines.append(f"|       {i}. {section}".ljust(box_width) + "|")
    lines.append("|" + " " * box_width + "|")

    lines.append(f"|  STYLE: {style.get('name', '')}".ljust(box_width) + "|")
    if style.get("keywords"):
        for line in _wrap_text(
            f"Keywords: {style.get('keywords', '')}", "|     ", box_width
        ):
            lines.append(line.ljust(box_width) + "|")
    if style.get("best_for"):
        for line in _wrap_text(
            f"Best For: {style.get('best_for', '')}", "|     ", box_width
        ):
            lines.append(line.ljust(box_width) + "|")
    if style.get("performance") or style.get("accessibility"):
        perf_a11y = (
            f"Performance: {style.get('performance', '')} | "
            f"Accessibility: {style.get('accessibility', '')}"
        )
        lines.append(f"|     {perf_a11y}".ljust(box_width) + "|")
    lines.append("|" + " " * box_width + "|")

    lines.append("|  COLORS:".ljust(box_width) + "|")
    lines.append(
        f"|     Primary:    {colors.get('primary', '')}".ljust(box_width) + "|"
    )
    lines.append(
        f"|     Secondary:  {colors.get('secondary', '')}".ljust(box_width) + "|"
    )
    lines.append(f"|     CTA:        {colors.get('cta', '')}".ljust(box_width) + "|")
    lines.append(
        f"|     Background: {colors.get('background', '')}".ljust(box_width) + "|"
    )
    lines.append(f"|     Text:       {colors.get('text', '')}".ljust(box_width) + "|")
    if colors.get("notes"):
        for line in _wrap_text(
            f"Notes: {colors.get('notes', '')}", "|     ", box_width
        ):
            lines.append(line.ljust(box_width) + "|")
    lines.append("|" + " " * box_width + "|")

    lines.append(
        f"|  TYPOGRAPHY: {typography.get('heading', '')} / {typography.get('body', '')}".ljust(
            box_width
        )
        + "|"
    )
    if typography.get("mood"):
        for line in _wrap_text(
            f"Mood: {typography.get('mood', '')}", "|     ", box_width
        ):
            lines.append(line.ljust(box_width) + "|")
    if typography.get("best_for"):
        for line in _wrap_text(
            f"Best For: {typography.get('best_for', '')}", "|     ", box_width
        ):
            lines.append(line.ljust(box_width) + "|")
    if typography.get("google_fonts_url"):
        lines.append(
            f"|     Google Fonts: {typography.get('google_fonts_url', '')}".ljust(
                box_width
            )
            + "|"
        )
    if typography.get("css_import"):
        lines.append(
            f"|     CSS Import: {str(typography.get('css_import', ''))[:70]}...".ljust(
                box_width
            )
            + "|"
        )
    lines.append("|" + " " * box_width + "|")

    if effects:
        lines.append("|  KEY EFFECTS:".ljust(box_width) + "|")
        for line in _wrap_text(effects, "|     ", box_width):
            lines.append(line.ljust(box_width) + "|")
        lines.append("|" + " " * box_width + "|")

    if anti_patterns:
        lines.append("|  AVOID (Anti-patterns):".ljust(box_width) + "|")
        for line in _wrap_text(anti_patterns, "|     ", box_width):
            lines.append(line.ljust(box_width) + "|")
        lines.append("|" + " " * box_width + "|")

    lines.append("|  PRE-DELIVERY CHECKLIST:".ljust(box_width) + "|")
    for item in checklist_items:
        lines.append(f"|     {item}".ljust(box_width) + "|")
    lines.append("|" + " " * box_width + "|")
    lines.append("+" + "-" * width_minus_one + "+")

    return "\n".join(lines)


__all__ = ["format_design_system_ascii_box", "DEFAULT_CHECKLIST_ITEMS"]
