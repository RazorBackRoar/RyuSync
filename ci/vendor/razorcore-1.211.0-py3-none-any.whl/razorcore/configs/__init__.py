"""Razorcore Shared Configurations.

This module provides shared configuration files for all RazorBackRoar projects.
Instead of symlinks, use `razorcore sync-configs` to copy these to your projects.
"""

import importlib.resources
from pathlib import Path


def get_config_path(config_name: str) -> Path | None:
    """Get the path to a shared configuration file.

    Args:
        config_name: Name of the config file ('ruff.toml' or 'pyrightconfig.json')

    Returns:
        Path to the config file, or None if not found
    """
    try:
        with importlib.resources.as_file(
            importlib.resources.files(__package__).joinpath(config_name)
        ) as path:
            if path.exists():
                return path
    except TypeError, FileNotFoundError:
        pass

    # Fallback to package directory
    pkg_dir = Path(__file__).parent
    config_path = pkg_dir / config_name
    if config_path.exists():
        return config_path

    return None


def get_ruff_config() -> Path | None:
    """Get path to shared ruff.toml configuration."""
    return get_config_path("ruff.toml")


def get_pyrightconfig() -> Path | None:
    """Get path to shared pyrightconfig.json."""
    return get_config_path("pyrightconfig.json")


def get_vscode_tasks() -> Path | None:
    """Get path to shared VS Code tasks.json."""
    # VS Code tasks are in a subdirectory
    pkg_dir = Path(__file__).parent
    config_path = pkg_dir / "vscode" / "tasks.json"
    if config_path.exists():
        return config_path
    return None


def get_all_configs() -> dict[str, Path | None]:
    """Get all available configuration file paths."""
    return {
        "ruff.toml": get_ruff_config(),
        "pyrightconfig.json": get_pyrightconfig(),
        ".vscode/tasks.json": get_vscode_tasks(),
    }
