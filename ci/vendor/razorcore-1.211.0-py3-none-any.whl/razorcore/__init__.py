"""razorcore - Shared foundation library for RazorBackRoar's macOS Python applications.

This package provides common utilities, UI components, and build tools used across:
- 4Charm (4chan media downloader)
- Nexus (Safari URL automation)
- RyuSync (Switch file organizer)

Note: As of the Phase 2 audit (2026-07-04), no app currently imports razorcore
directly. All apps use local reimplementations. See Apps/Docs/razorcore-helper-audit.md.

Modules:
    config      - Project configuration and version management
    logging     - Unified logging setup
    threading   - Base QThread worker classes
    filesystem  - Safe file operations and hashing
    styling     - UI themes and styled widgets
    build       - DMG creation and build utilities
    configs     - Shared configuration files (pyproject.toml, pyrightconfig.json)
    cli         - Command-line tools (razorcore sync-configs, verify, commit-all)
    updates     - Update checking via GitHub Releases API
    appinfo     - Standardized app metadata, license display, About dialog
"""

__version__ = "1.211.0"
__author__ = "RazorBackRoar"
__license__ = "2025 RazorBackRoar"

from razorcore.ascii_box import format_design_system_ascii_box
from razorcore.config import ProjectConfig, get_version
from razorcore.filesystem import (
    check_disk_space,
    compute_file_hash,
    format_file_size,
    generate_unique_filename,
    sanitize_filename,
)
from razorcore.logging import get_logger, setup_logging
from razorcore.updates import (
    UpdateChecker,
    UpdateResult,
    check_for_updates,
    compare_versions,
    is_newer_version,
)


__all__ = [
    # Config
    "ProjectConfig",
    "get_version",
    # Logging
    "setup_logging",
    "get_logger",
    # Filesystem
    "sanitize_filename",
    "generate_unique_filename",
    "compute_file_hash",
    "check_disk_space",
    "format_file_size",
    # Updates
    "UpdateChecker",
    "UpdateResult",
    "check_for_updates",
    "compare_versions",
    "is_newer_version",
    # Formatting
    "format_design_system_ascii_box",
]
