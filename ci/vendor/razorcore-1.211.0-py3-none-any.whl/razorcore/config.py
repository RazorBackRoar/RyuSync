"""Project configuration and version management.

Provides utilities for reading project metadata from pyproject.toml
and managing application configuration.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


try:
    import tomllib
except ModuleNotFoundError:
    import tomli as tomllib  # type: ignore


@dataclass
class ProjectConfig:
    """Holds project configuration loaded from pyproject.toml.

    Usage:
        config = ProjectConfig.from_pyproject()
        print(config.name, config.version)
    """

    name: str = ""
    version: str = "0.0.0"
    description: str = ""
    authors: list = field(default_factory=list)
    requires_python: str = ">=3.10"

    # App-specific settings
    app_name: str = ""
    organization: str = ""
    domain: str = ""

    @classmethod
    def from_pyproject(
        cls, pyproject_path: Path | None = None, search_depth: int = 4
    ) -> ProjectConfig:
        """Load configuration from pyproject.toml.

        Args:
            pyproject_path: Direct path to pyproject.toml. If None, searches upward.
            search_depth: How many parent directories to search.

        Returns:
            ProjectConfig instance with loaded values.
        """
        if pyproject_path is None:
            pyproject_path = cls._find_pyproject(search_depth)

        if pyproject_path is None or not pyproject_path.exists():
            return cls()

        try:
            with open(pyproject_path, "rb") as f:
                data = tomllib.load(f)

            project = data.get("project", {})

            return cls(
                name=project.get("name", ""),
                version=project.get("version", "0.0.0"),
                description=project.get("description", ""),
                authors=project.get("authors", []),
                requires_python=project.get("requires-python", ">=3.10"),
                app_name=project.get("name", ""),
                organization=project.get("name", ""),
                domain=f"{project.get('name', 'app').lower()}.com",
            )
        except Exception:
            return cls()

    @staticmethod
    def _find_pyproject(search_depth: int = 4) -> Path | None:
        """Search for pyproject.toml in parent directories."""
        current = Path(__file__).resolve()

        for _ in range(search_depth):
            current = current.parent
            candidate = current / "pyproject.toml"
            if candidate.exists():
                return candidate

        return None


def _get_installed_version(package_names: list[str]) -> str | None:
    """Try to get version from installed package metadata."""
    if not package_names:
        return None
    try:
        from importlib.metadata import PackageNotFoundError
        from importlib.metadata import version as pkg_version

        for pkg_name in package_names:
            try:
                return pkg_version(pkg_name)
            except PackageNotFoundError:
                continue
    except ImportError:
        pass
    return None


def _package_name_candidates(package_name: str) -> list[str]:
    """Return likely distribution names for a display/package name."""
    normalized = package_name.strip()
    if not normalized:
        return []
    candidates = [
        normalized,
        normalized.lower(),
        normalized.replace("-", "_"),
        normalized.lower().replace("-", "_"),
    ]
    # Preserve order while dropping duplicates.
    return list(dict.fromkeys(candidates))


def _find_pyproject_path(
    search_depth: int = 5, start: Path | None = None
) -> Path | None:
    """Find pyproject.toml by searching upward from a start path."""
    if start is None:
        import inspect

        frame = inspect.currentframe()
        if frame and frame.f_back and frame.f_back.f_back:
            # Skip get_version frame; use its caller.
            caller_file = frame.f_back.f_back.f_globals.get("__file__")
            if caller_file:
                start = Path(caller_file).resolve().parent
        if start is None:
            return None

    start_path = start
    for _ in range(search_depth):
        candidate = start_path / "pyproject.toml"
        if candidate.exists():
            return candidate
        if start_path.parent == start_path:
            break
        start_path = start_path.parent
    return None


def _read_version_from_pyproject(pyproject_path: Path, default: str) -> str:
    """Read version from pyproject.toml file."""
    try:
        with open(pyproject_path, "rb") as f:
            data = tomllib.load(f)
        return data.get("project", {}).get("version", default)
    except Exception:
        pass
    return default


def _read_project_name(pyproject_path: Path) -> str | None:
    """Read [project].name from pyproject.toml when available."""
    try:
        with open(pyproject_path, "rb") as f:
            data = tomllib.load(f)
        name = data.get("project", {}).get("name")
        return str(name) if name else None
    except Exception:
        return None


def _read_version_with_regex(default: str) -> str:
    """Fallback: read version using regex from common locations."""
    try:
        for candidate in [
            Path.cwd() / "pyproject.toml",
            Path.cwd().parent / "pyproject.toml",
        ]:
            if candidate.exists():
                content = candidate.read_text(encoding="utf-8")
                match = re.search(r'version\s*=\s*"([^"]+)"', content)
                if match:
                    return match.group(1)
    except Exception:
        pass
    return default


def _version_from_pyproject_candidate(
    pyproject_path: Path | None,
    default: str,
    package_name: str | None,
) -> str | None:
    """Return version from a pyproject path when it matches the requested package."""
    if pyproject_path is None or not pyproject_path.exists():
        return None
    project_name = _read_project_name(pyproject_path)
    if package_name and project_name:
        allowed = {c.lower() for c in _package_name_candidates(package_name)}
        if project_name.lower() not in allowed:
            return None
    version = _read_version_from_pyproject(pyproject_path, default)
    if version != default:
        return version
    return None


def get_version(
    default: str = "0.0.0",
    pyproject_path: Path | None = None,
    search_depth: int = 5,
    package_name: str | None = None,
) -> str:
    """Get the consuming project's version (not razorcore's).

    Resolution order:
    1. Explicit ``pyproject_path``
    2. Installed distribution metadata for ``package_name`` (when provided)
    3. ``./pyproject.toml`` from the current working directory
    4. Caller-relative upward search (skips razorcore's manifest for app names)
    5. Regex fallback / ``default``

    Args:
        default: Fallback version if pyproject.toml cannot be read.
        pyproject_path: Direct path to pyproject.toml. If None, searches upward.
        search_depth: How many parent directories to search.
        package_name: App/distribution name (e.g. ``"Nexus"`` / ``"nexus"``).

    Returns:
        Version string (e.g., "1.2.3").

    Example:
        # In your main.py:
        from razorcore import get_version
        VERSION = get_version(default="1.0.0", package_name="Nexus")
    """
    if pyproject_path is not None:
        return _read_version_from_pyproject(pyproject_path, default)

    if package_name:
        installed = _get_installed_version(_package_name_candidates(package_name))
        if installed:
            return installed

    cwd_version = _version_from_pyproject_candidate(
        Path.cwd() / "pyproject.toml", default, package_name
    )
    if cwd_version:
        return cwd_version

    found = _find_pyproject_path(search_depth)
    found_version = _version_from_pyproject_candidate(found, default, package_name)
    if found_version:
        return found_version

    return _read_version_with_regex(default)


def get_pyproject_value(key: str, default: Any = None, section: str = "project") -> Any:
    """Get a specific value from pyproject.toml.

    Args:
        key: The key to look up (e.g., "name", "version").
        default: Default value if key not found.
        section: The TOML section (default: "project").

    Returns:
        The value from pyproject.toml or the default.
    """
    config = ProjectConfig.from_pyproject()
    return getattr(config, key, default)
